﻿-- ========================================== --
-- Command id: 1182
-- Description: ایجاد جدول Driver (اطلاعات پایه مالک/راننده و خودرو)
-- ========================================== --
CREATE TABLE Driver
(
    id INT IDENTITY(1,1) NOT NULL,
    DriverTitle NVARCHAR(MAX) NOT NULL,
    OwnerTitle NVARCHAR(MAX) NOT NULL,
    PlateNumber NVARCHAR(MAX) NOT NULL,
    DefaultCommissionPercent DECIMAL(5,2) NOT NULL,
    IsActive BIT NOT NULL,
    CONSTRAINT PK_Driver PRIMARY KEY CLUSTERED (id)
);

-- ========================================== --
-- Command id: 1183
-- Description: ایجاد جدول DriverStatement (سربرگ صورت‌وضعیت رانندگان). StatementDate تاریخ دستی صورت‌وضعیت است
-- ========================================== --
CREATE TABLE DriverStatement
(
    id INT IDENTITY(1,1) NOT NULL,
    StatementDate INT NOT NULL,
    Userid INT NOT NULL,
    CONSTRAINT PK_DriverStatement PRIMARY KEY CLUSTERED (id),
    CONSTRAINT FK_DriverStatement_User FOREIGN KEY (Userid) REFERENCES [User] (id)
);

-- ========================================== --
-- Command id: 1184
-- Description: یکتایی تاریخ صورت‌وضعیت
-- ========================================== --
CREATE UNIQUE INDEX UX_DriverStatement_StatementDate ON DriverStatement (StatementDate);

-- ========================================== --
-- Command id: 1185
-- Description: ایجاد جدول DriverStatementDe (ردیف هر راننده در صورت‌وضعیت)
-- ========================================== --
CREATE TABLE DriverStatementDe
(
    id INT IDENTITY(1,1) NOT NULL,
    DriverStatementid INT NOT NULL,
    Driverid INT NOT NULL,
    NetAmount BIGINT NOT NULL,
    CommissionPercent DECIMAL(5,2) NOT NULL,
    CommissionAmount BIGINT NOT NULL,
    WaybillAmount BIGINT NOT NULL,
    OtherDeduction BIGINT NOT NULL,
    OtherDeductionDesc NVARCHAR(MAX) NULL,
    PrevMonthWaybill BIGINT NOT NULL,
    DebtPaymentAmount BIGINT NOT NULL,
    PayableAmount BIGINT NOT NULL,
    CompanyDebtBalance BIGINT NOT NULL,
    Note NVARCHAR(MAX) NULL,
    IsFinalConfirmed BIT NOT NULL,
    CONSTRAINT PK_DriverStatementDe PRIMARY KEY CLUSTERED (id),
    CONSTRAINT FK_DriverStatementDe_DriverStatement FOREIGN KEY (DriverStatementid) REFERENCES DriverStatement (id),
    CONSTRAINT FK_DriverStatementDe_Driver FOREIGN KEY (Driverid) REFERENCES Driver (id)
);

-- ========================================== --
-- Command id: 1186
-- Description: یکتایی راننده در هر صورت‌وضعیت
-- ========================================== --
CREATE UNIQUE INDEX UX_DriverStatementDe_Statement_Driver ON DriverStatementDe (DriverStatementid, Driverid);
