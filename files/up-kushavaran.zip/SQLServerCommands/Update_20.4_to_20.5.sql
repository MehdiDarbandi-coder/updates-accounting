﻿-- ========================================== --
-- Command id: 1036
-- Description: 
-- ========================================== --
DELETE FROM aBrushHeader
WHERE id =50;
-- ========================================== --
-- Command id: 1037
-- Description: اضافه کردن یک آیتم به هیدر رنگها
-- ========================================== --
SET IDENTITY_INSERT [dbo].[aBrushHeader] ON;

    INSERT INTO [dbo].[aBrushHeader] ([id], [RowNumber], [Title], [IsMainView])
    SELECT 49, 1002.00, N'دکمه های انتخاب منوی سمت راست', 1;

 SET IDENTITY_INSERT [dbo].[aBrushHeader] OFF;
 
-- ========================================== --
-- Command id: 1038
-- Description: اضافه کردن اقلام آیتم اضافه شده در هیدر رنگها
-- ========================================== --

 INSERT INTO [dbo].[aBrush] ([Headerid], [BrushKey], [ControlDescription], [RowNumber], [BrushDescription], [Color]) VALUES
(49, 'ForegRadioBtnRight', N'دکمه های انتخاب', 16, N'فونت وضعیت عادی', 'White'),
(49, 'BackgRadioBtnRightMOver', N'دکمه های انتخاب', 17, N'زمینه حرکت موس', '#FFD378FA'),
(49, 'ForegRadioBtnRightMOver', N'دکمه های انتخاب', 18, N'فونت حرکت موس', '#FF000000'),
(49, 'BackgRadioBtnRightChecked', N'دکمه های انتخاب', 19, N'زمینه انتخاب', 'White'),
(49, 'ForegRadioBtnRightChecked', N'دکمه های انتخاب', 20, N'فونت انتخاب', 'Black');
 
 -- ========================================== --
-- Command id: 1039
-- Description: 
-- ========================================== --

-- ========================================== --
-- Command id: 1040
-- Description: اضافه کردن رکوردهای جدید به UserBrushThemDe برای هر UserBrushThem
-- ========================================== --
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color])
SELECT 
    ubt.id AS BrushThemid,
    ab.id AS Brushid,
    ab.Color
FROM [dbo].[UserBrushThem] ubt
CROSS JOIN [dbo].[aBrush] ab
WHERE ab.Headerid = 49  -- فقط رکوردهای جدید اضافه شده با Headerid = 49
;

-- ========================================== --
-- Command id: 1041
-- Description: به‌روزرسانی جداول aBrushHeader و aBrush
-- ========================================== --
-- 1. به‌روزرسانی Title مشخصه 49 در جدول aBrushHeader
UPDATE [dbo].[aBrushHeader] 
SET [Title] = N'نوار سمت راست'
WHERE [id] = 49;

-- 2. حذف رکورد BackgHomeTabItem از جدول aBrush
DELETE FROM [dbo].[aBrush] 
WHERE [BrushKey] = 'BackgHomeTabItem';

-- 3. به‌روزرسانی Headerid موارد مشخص شده در جدول aBrush
UPDATE [dbo].[aBrush] 
SET [Headerid] = 49
WHERE [BrushKey] IN (
    'BackgMainRight',
    'ForegPathMainRight',
    'ForegPathMainRightMOver',
    'ForegPathMainRightPressed',
    'FillPathHomeTabItem',
    'BackgHomeTabItemMOver'
);

-- 4. به‌روزرسانی ControlDescription آیتم‌های FillPathHomeTabItem و BackgHomeTabItemMOver
UPDATE [dbo].[aBrush] 
SET [ControlDescription] = N'زبانه خانه'
WHERE [BrushKey] IN ('FillPathHomeTabItem', 'BackgHomeTabItemMOver');


UPDATE [dbo].[aBrush] 
SET [ControlDescription] = N'دکمه تنظیمات و ورود مجدد',
    [BrushDescription] = N'وضعیت عادی'
WHERE [BrushKey] = 'ForegPathMainRight';

UPDATE [dbo].[aBrush] 
SET [ControlDescription] = N'دکمه تنظیمات و ورود مجدد',
    [BrushDescription] = N'حرکت موس'
WHERE [BrushKey] = 'ForegPathMainRightMOver';

UPDATE [dbo].[aBrush] 
SET [ControlDescription] = N'دکمه تنظیمات و ورود مجدد',
    [BrushDescription] = N'کلیک'
WHERE [BrushKey] = 'ForegPathMainRightPressed';
-- ========================================== --
-- Command id: 1042
-- Description: بابت ادغام برخی آیتمهای پنجره صفحه اول در بخش نوار سمت راست
-- ========================================== --
DELETE FROM [dbo].[aBrushHeader] WHERE [id] = 53;
-- ========================================== --
-- Command id: 1043
-- Description: به‌روزرسانی RowNumber برای رکوردهای Headerid = 49 در جدول aBrush
-- ========================================== --

WITH RankedRows AS (
    SELECT 
        [id],
        ROW_NUMBER() OVER (
            ORDER BY 
                CASE 
                    WHEN [ControlDescription] = N'نوار راست' THEN 1
                    WHEN [ControlDescription] = N'زبانه خانه' THEN 2
                    WHEN [ControlDescription] = N'دکمه های انتخاب' THEN 3
                    WHEN [ControlDescription] = N'دکمه تنظیمات و ورود مجدد' THEN 4
                    ELSE 5
                END,
                [RowNumber], 
                [id]
        ) AS NewRowNumber
    FROM [dbo].[aBrush]
    WHERE [Headerid] = 49
)
UPDATE [dbo].[aBrush]
SET [RowNumber] = RankedRows.NewRowNumber
FROM [dbo].[aBrush]
INNER JOIN RankedRows ON [dbo].[aBrush].[id] = RankedRows.[id];


-- ========================================== --
-- Command id: 1044
-- Description: به‌روزرسانی رکوردهای ساعت در جدول aBrush
-- ========================================== --

-- 1. تغییر ControlDescription برای رکوردهای Headerid = 52
UPDATE [dbo].[aBrush] 
SET [ControlDescription] = N'ساعت'
WHERE [Headerid] = 52;

-- 2. حذف رکورد با BrushKey = 'ForegClockDDate'
DELETE FROM [dbo].[aBrush] 
WHERE [BrushKey] = 'ForegClockDDate';

-- 3. تغییر BrushKey: FillClockACentrePoint به FillClockCentrePoint
UPDATE [dbo].[aBrush] 
SET [BrushKey] = 'FillClockCentrePoint'
WHERE [BrushKey] = 'FillClockACentrePoint';

-- 4. تغییر BrushKey: FillClockAHour به FillClockHour
UPDATE [dbo].[aBrush] 
SET [BrushKey] = 'FillClockHour'
WHERE [BrushKey] = 'FillClockAHour';

-- 5. تغییر BrushKey: FillClockAMinute به FillClockMinute
UPDATE [dbo].[aBrush] 
SET [BrushKey] = 'FillClockMinute'
WHERE [BrushKey] = 'FillClockAMinute';

-- 6. تغییر BrushKey: FillClockASecond به FillClockSecond
UPDATE [dbo].[aBrush] 
SET [BrushKey] = 'FillClockSecond'
WHERE [BrushKey] = 'FillClockASecond';

-- 7. تغییر BrushKey: StrokeClockAMinutes به StrokeClockMinutes
UPDATE [dbo].[aBrush] 
SET [BrushKey] = 'StrokeClockMinutes',
    [BrushDescription] = N'نقاط دقیقه'
WHERE [BrushKey] = 'StrokeClockAMinutes';

-- 8. تغییر BrushKey و BrushDescription: ForegClockD به ForegClock
UPDATE [dbo].[aBrush] 
SET [BrushKey] = 'ForegClock',
    [BrushDescription] = N'فونت تاریخ و روز'
WHERE [BrushKey] = 'ForegClockD';

-- 9. تغییر BrushKey و BrushDescription: StrokeClockAHour به BackgClock
UPDATE [dbo].[aBrush] 
SET [BrushKey] = 'BackgClock',
    [BrushDescription] = N'زمینه'
WHERE [BrushKey] = 'StrokeClockAHour';


-- ========================================== --
-- Command id: 1045
-- Description: حذف رکوردهای تکراری در جدول UserBrushThemDe (نگه داشتن آخرین رکورد)
-- ========================================== --

WITH DuplicateRecords AS (
    SELECT 
        [id],
        [BrushThemid],
        [Brushid],
        ROW_NUMBER() OVER (
            PARTITION BY [BrushThemid], [Brushid] 
            ORDER BY [id] DESC
        ) AS rn
    FROM [dbo].[UserBrushThemDe]
)
DELETE FROM [dbo].[UserBrushThemDe]
WHERE [id] IN (
    SELECT [id] 
    FROM DuplicateRecords 
    WHERE rn > 1
);

-- ========================================== --
-- Command id: 1046
-- Description: به‌روزرسانی رنگ BackgClock بر اساس BackgMainMenu
-- ========================================== --

-- 1. به‌روزرسانی Color در جدول aBrush
UPDATE aBrush 
SET Color = '#00FFFFFF'
WHERE BrushKey = 'BackgClock';

-- 2. به‌روزرسانی Color در جدول UserBrushThemDe
UPDATE UserBrushThemDe 
SET Color = '#00FFFFFF'
WHERE Brushid = (
    SELECT id 
    FROM aBrush 
    WHERE BrushKey = 'BackgClock'
);
