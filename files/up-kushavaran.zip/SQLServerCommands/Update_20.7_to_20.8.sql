﻿-- ========================================== --
-- Command id: 1049
-- Description: 
-- ========================================== --
UPDATE EntryTypeDe
SET Side = 'ShipProductDeb'
WHERE Side = 'ShipShipProductDeb';

UPDATE EntryTypeDe
SET Side = 'ShipProductCrd'
WHERE Side = 'ShipShipProductCrd';
