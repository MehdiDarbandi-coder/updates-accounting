﻿-- ========================================== --
-- Command id: 1062
-- Description: 
-- ========================================== --
IF OBJECT_ID('Transportation', 'U') IS NOT NULL
    DROP TABLE Transportation;
-- ========================================== --
-- Command id: 1062
-- Description: 
-- ========================================== --
CREATE TABLE [Transportation] (
	[id]	INT NOT NULL IDENTITY(1,1),
	[Storageid]	INT NOT NULL,
	[DriverFullName]	NVARCHAR(MAX),
	[DriverNationalCode]	NVARCHAR(MAX),
	[DriverPhoneNumber]	NVARCHAR(MAX),	
	[VehicleNumber]	NVARCHAR(MAX),
	[VehicleType]	NVARCHAR(MAX),
	[ReceiverFullName]	NVARCHAR(MAX),
	[DeliveryAddress]	NVARCHAR(MAX),
	[DeliveryPostalCode]	NVARCHAR(MAX),
	[WaybillNumber]	NVARCHAR(MAX),
	[WaybillIssuerCompany]	NVARCHAR(MAX),
	[TransportationDate]	INT,
	[TransportDescription]	NVARCHAR(MAX),
	CONSTRAINT [PK_Transportation] PRIMARY KEY CLUSTERED ([id] ASC),
	CONSTRAINT [FK_Transportation_Storage] FOREIGN KEY([Storageid]) 
		REFERENCES [Storage]([id]) ON DELETE CASCADE
);
-- ========================================== --
-- Command id: 1063
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT * FROM sys.columns 
               WHERE object_id = OBJECT_ID('KalaPrice') 
               AND name = 'PriceVersionNumber')
BEGIN
    ALTER TABLE KalaPrice 
    ADD PriceVersionNumber INT NULL;
END
-- ========================================== --
-- Command id: 1064
-- Description: 
-- ========================================== --
WITH Ordered AS (
    SELECT 
        id,
        CAST(LEFT(StartDate, 4) AS INT) AS Year4,
        ROW_NUMBER() OVER (
            PARTITION BY LEFT(StartDate, 4)
            ORDER BY StartDate
        ) AS rn
    FROM KalaPrice
)
UPDATE k
SET PriceVersionNumber = o.Year4 * 1000 + o.rn
FROM KalaPrice k
JOIN Ordered o ON k.id = o.id;
