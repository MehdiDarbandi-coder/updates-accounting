﻿-- ========================================== --
-- Command id: 1052 
-- Description: 
-- ========================================== --
-- اضافه کردن ستون فقط در صورتی که وجود نداشته باشد
IF NOT EXISTS (SELECT * FROM sys.columns 
               WHERE object_id = OBJECT_ID('CheckTransfer') 
               AND name = 'NewLFiveid')
BEGIN
    ALTER TABLE CheckTransfer
    ADD NewLFiveid INT NULL;
END

-- اضافه کردن Foreign Key فقط در صورتی که وجود نداشته باشد
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_CheckTransfer_LFive')
BEGIN
    ALTER TABLE CheckTransfer
    ADD CONSTRAINT FK_CheckTransfer_LFive
    FOREIGN KEY (NewLFiveid) REFERENCES LF(id);
END
-- ========================================== --
-- Command id: 1053
-- Description: 
-- ========================================== --
-- اضافه کردن ستون
IF NOT EXISTS (SELECT * FROM sys.columns 
               WHERE object_id = OBJECT_ID('StorageRate') 
               AND name = 'StorageRateNumber')
BEGIN
    ALTER TABLE StorageRate
    ADD StorageRateNumber INT NULL;
END
-- ========================================== --
-- Command id: 1054
-- Description: 
-- ========================================== --
-- مقداردهی ستون فقط برای رکوردهایی که مقدار NULL دارند
IF EXISTS (SELECT * FROM sys.columns 
           WHERE object_id = OBJECT_ID('StorageRate') 
           AND name = 'StorageRateNumber')
BEGIN
    UPDATE StorageRate
    SET StorageRateNumber = (
        SELECT COUNT(*) + 10000
        FROM StorageRate AS SR2
        WHERE SR2.id <= StorageRate.id
    )
    WHERE StorageRateNumber IS NULL;
END
-- ========================================== --
-- Command id: 1055
-- Description: 
-- ========================================== --
-- حذف ستون فقط در صورتی که وجود داشته باشد
IF EXISTS (SELECT * FROM sys.columns 
           WHERE object_id = OBJECT_ID('StorageRate') 
           AND name = 'ConfirmDate')
BEGIN
    ALTER TABLE StorageRate
    DROP COLUMN ConfirmDate;
END
