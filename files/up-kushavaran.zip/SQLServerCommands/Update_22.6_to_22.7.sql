﻿-- ========================================= --
-- Command id: 1189
-- Description: ستون هش کلمه عبور کاربران (قالب Salt:Hash)
-- ========================================= --
ALTER TABLE [User] ADD PasswordHash NVARCHAR(MAX) NULL;
-- ========================================= --
-- Command id: 1190
-- Description: الزام کاربر به تغییر کلمه عبور در اولین ورود (پیش‌فرض ۱ برای همه کاربران موجود)
-- ========================================= --
ALTER TABLE [User] ADD MustChangePassword BIT NOT NULL DEFAULT 1;
-- ========================================= --
-- Command id: 1191
-- Description: پیام‌های پشتیبانی: حذف جدول قدیمی (در دریافت بعدی از اینترنت از نو ساخته می‌شود)
-- ========================================= --
IF OBJECT_ID(N'DashAnnouncement', N'U') IS NOT NULL DROP TABLE DashAnnouncement;
-- ========================================= --
-- Command id: 1192
-- Description: پیام‌های پشتیبانی: ساخت جدول
-- ========================================= --
CREATE TABLE DashAnnouncement (
    id INT IDENTITY(1,1) NOT NULL PRIMARY KEY NONCLUSTERED,
    FeedKey VARCHAR(64) NOT NULL,
    Revision INT NOT NULL DEFAULT 1,
    Body NVARCHAR(MAX) NOT NULL DEFAULT N'',
    PublishedDate INT NOT NULL,
    UpdatedDate INT NOT NULL DEFAULT 0
);
-- ========================================= --
-- Command id: 1193
-- Description: پیام‌های پشتیبانی: ایندکس یکتای کلید فید
-- ========================================= --
CREATE UNIQUE INDEX UQ_DashAnnouncement_FeedKey ON DashAnnouncement (FeedKey);
-- ========================================= --
-- Command id: 1194
-- Description: پیام‌های پشتیبانی: ایندکس تاریخ انتشار
-- ========================================= --
CREATE CLUSTERED INDEX IX_DashAnnouncement_PublishedDate ON DashAnnouncement (PublishedDate);
-- ========================================= --
-- Command id: 1195
-- Description: پیام‌های پشتیبانی: پاک کردن وضعیت دریافت تا همه‌ی پیام‌ها از نو دریافت شوند
-- ========================================= --
DELETE FROM DashAnnouncementSync;
-- ========================================= --
-- Command id: 1196
-- Description: خوانده‌شدن پیام‌های پشتیبانی برای هر کاربر: ساخت جدول
-- ========================================= --
CREATE TABLE DashAnnouncementUserState (
    id INT IDENTITY(1,1) NOT NULL PRIMARY KEY NONCLUSTERED,
    AnnouncementId INT NOT NULL,
    UserId INT NOT NULL,
    IsRead BIT NOT NULL DEFAULT 0,
    ReadDate INT NOT NULL DEFAULT 0
);
-- ========================================= --
-- Command id: 1197
-- Description: خوانده‌شدن پیام‌های پشتیبانی برای هر کاربر: ایندکس یکتا
-- ========================================= --
CREATE UNIQUE INDEX UQ_DashAnnouncementUserState ON DashAnnouncementUserState (UserId, AnnouncementId);
-- ========================================= --
-- Command id: 1198
-- Description: پیام کاربر به کاربر: ساخت جدول
-- ========================================= --
CREATE TABLE UserMessage (
    id INT IDENTITY(1,1) NOT NULL PRIMARY KEY NONCLUSTERED,
    FromUserId INT NOT NULL,
    ToUserId INT NOT NULL,
    Body NVARCHAR(MAX) NOT NULL,
    SentDate INT NOT NULL,
    SentTime INT NOT NULL DEFAULT 0,
    IsUrgent BIT NOT NULL DEFAULT 0,
    IsRead BIT NOT NULL DEFAULT 0,
    ReadDate INT NOT NULL DEFAULT 0,
    ReadTime INT NOT NULL DEFAULT 0
);
-- ========================================= --
-- Command id: 1199
-- Description: پیام کاربر به کاربر: ایندکس گیرنده و وضعیت خواندن
-- ========================================= --
CREATE INDEX IX_UserMessage_ToUserId_IsRead ON UserMessage (ToUserId, IsRead);
-- ========================================= --
-- Command id: 1200
-- Description: پیام کاربر به کاربر: ایندکس فرستنده
-- ========================================= --
CREATE INDEX IX_UserMessage_FromUserId ON UserMessage (FromUserId);
-- ========================================= --
-- Command id: 1201
-- Description: حضور کاربران (ورود، خروج، آنلاین): ساخت جدول
-- ========================================= --
CREATE TABLE UserPresence (
    id INT IDENTITY(1,1) NOT NULL PRIMARY KEY NONCLUSTERED,
    UserId INT NOT NULL,
    IsOnline BIT NOT NULL DEFAULT 0,
    LoginDate INT NOT NULL DEFAULT 0,
    LoginTime INT NOT NULL DEFAULT 0,
    LogoutDate INT NOT NULL DEFAULT 0,
    LogoutTime INT NOT NULL DEFAULT 0,
    LastSeenDate INT NOT NULL DEFAULT 0,
    LastSeenTime INT NOT NULL DEFAULT 0,
    Beat INT NOT NULL DEFAULT 0
);
-- ========================================= --
-- Command id: 1202
-- Description: حضور کاربران: ایندکس یکتای کاربر
-- ========================================= --
CREATE UNIQUE INDEX UQ_UserPresence_UserId ON UserPresence (UserId);
-- ========================================= --
-- Command id: 1203
-- Description: حضور کاربران: ایندکس یکتای کاربر
-- ========================================= --
UPDATE d
SET d.Color = v.NewColor
FROM dbo.UserBrushThemDe d
INNER JOIN (VALUES
    (3,  '#B3CFDB'),
    (5,  '#FF9ED8BA'),
    (6,  '#FFBF9DD1'),
    (7,  '#FFD1AF9D'),
    (8,  '#FF3A6E94'),
    (9,  '#FF3A9462'),
    (10, '#FF7A3A94'),
    (11, '#FF3A5C94'),
    (12, '#8A8873'),
    (13, '#FF9DBCD1')
) AS v(BrushThemid, NewColor)
    ON v.BrushThemid = d.BrushThemid
WHERE d.Brushid = 2024;

UPDATE dbo.UserBrushThemDe
SET Color = '#13232B'
WHERE BrushThemid = 3 AND Brushid = 2025;

-- ========================================= --
-- Command id: 1204
-- Description: 
-- ========================================= --
ALTER TABLE Company ADD StampImage NVARCHAR(MAX) NULL;

