﻿-- ========================================== --
-- Command id: 1083
-- Description: ایجاد جدول مرجع واحد سنجش (Unit)
-- ========================================== --
CREATE TABLE [dbo].[Unit](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NOT NULL,
	[TaxCode] [varchar](10) NULL,
	[DecimalCount] [tinyint] NOT NULL CONSTRAINT [DF_Unit_DecimalCount] DEFAULT (0),
 CONSTRAINT [PK_Unit] PRIMARY KEY CLUSTERED ([id] ASC)
);
CREATE UNIQUE INDEX [UX_Unit_Title] ON [dbo].[Unit]([Title]);


-- ========================================== --
-- Command id: 1084
-- Description: پر کردن Unit از عناوین موجود در Kala
-- ========================================== --
INSERT INTO dbo.Unit (Title, TaxCode)
SELECT
	LTRIM(RTRIM(UnitMain)) AS Title,
	MAX(NULLIF(LTRIM(RTRIM(UnitMainid)), '')) AS TaxCode
FROM dbo.Kala
WHERE UnitMain IS NOT NULL AND LTRIM(RTRIM(UnitMain)) <> ''
GROUP BY LTRIM(RTRIM(UnitMain));


-- ========================================== --
-- Command id: 1085
-- Description: اضافه‌کردن ستون‌های واحد سنجش به Kala
-- ========================================== --
ALTER TABLE dbo.Kala ADD [Unitid] [int] NULL;
ALTER TABLE dbo.Kala ADD [SubUnitid] [int] NULL;
ALTER TABLE dbo.Kala ADD [ConversionFactor] [decimal](18, 3) NULL;


-- ========================================== --
-- Command id: 1086
-- Description: ست کردن Unitid کالاها بر اساس عنوان قبلی
-- ========================================== --
UPDATE k
SET k.Unitid = u.id
FROM dbo.Kala k
INNER JOIN dbo.Unit u ON LTRIM(RTRIM(k.UnitMain)) = u.Title;

-- ========================================== --
-- Command id: 1086
-- Description: ایجاد واحد پیش‌فرض «نامشخص» و نسبت‌دادن به کالاهایی که Unitid ندارن
-- ========================================== --

IF NOT EXISTS (SELECT 1 FROM dbo.Unit WHERE Title = N'نامشخص')
BEGIN
    INSERT INTO dbo.Unit (Title, TaxCode) VALUES (N'نامشخص', NULL);
END

UPDATE k
SET k.Unitid = (SELECT id FROM dbo.Unit WHERE Title = N'نامشخص')
FROM dbo.Kala k
WHERE k.Unitid IS NULL;
-- ========================================== --
-- Command id: 1087
-- Description: NOT NULL کردن Unitid و اضافه‌کردن کلید خارجی‌ها
-- ========================================== --
ALTER TABLE dbo.Kala ALTER COLUMN [Unitid] [int] NOT NULL;
ALTER TABLE dbo.Kala WITH CHECK ADD CONSTRAINT [FK_Kala_Unit] FOREIGN KEY([Unitid]) REFERENCES dbo.Unit([id]);
ALTER TABLE dbo.Kala CHECK CONSTRAINT [FK_Kala_Unit];
ALTER TABLE dbo.Kala WITH CHECK ADD CONSTRAINT [FK_Kala_SubUnit] FOREIGN KEY([SubUnitid]) REFERENCES dbo.Unit([id]);
ALTER TABLE dbo.Kala CHECK CONSTRAINT [FK_Kala_SubUnit];

-- ========================================== --
-- Command id: 1088
-- Description: حذف ستون‌های قدیمی واحد سنجش
-- ========================================== --
ALTER TABLE dbo.Kala DROP COLUMN UnitMain;
ALTER TABLE dbo.Kala DROP COLUMN UnitMainid;
-- ========================================== --
-- Command id: 1090
-- Description: افزودن ستون Scope به UserBrushThem
-- ========================================== --
ALTER TABLE [dbo].[UserBrushThem]
    ADD [Scope] TINYINT NOT NULL CONSTRAINT DF_UserBrushThem_Scope DEFAULT (2);


-- ========================================== --
-- Command id: 1091
-- Description: افزودن ستون موقت MigrationSourceId
-- ========================================== --
ALTER TABLE [dbo].[UserBrushThem] ADD [MigrationSourceId] INT NULL;


-- ========================================== --
-- Command id: 1092
-- Description: ساخت تم‌های جدید Shell از روی تم‌های قدیمی
-- ========================================== --
INSERT INTO [dbo].[UserBrushThem] (Userid, Title, Scope, MigrationSourceId)
SELECT t.Userid, t.Title + N' (صفحه اول)', 1, t.id
FROM [dbo].[UserBrushThem] t
WHERE t.MigrationSourceId IS NULL
  AND EXISTS (
        SELECT 1
        FROM [dbo].[UserBrushThemDe] de
        JOIN [dbo].[aBrush] b ON b.id = de.Brushid
        JOIN [dbo].[aBrushHeader] h ON h.id = b.Headerid
        WHERE de.BrushThemid = t.id AND h.IsMainView = 1
  );


-- ========================================== --
-- Command id: 1093
-- Description: انتقال رکوردهای Shell به تم جدید
-- ========================================== --
UPDATE de
SET de.BrushThemid = nt.id
FROM [dbo].[UserBrushThemDe] de
JOIN [dbo].[UserBrushThem] nt ON nt.MigrationSourceId = de.BrushThemid
JOIN [dbo].[aBrush] b ON b.id = de.Brushid
JOIN [dbo].[aBrushHeader] h ON h.id = b.Headerid
WHERE h.IsMainView = 1;


-- ========================================== --
-- Command id: 1094
-- Description: حذف ستون موقت MigrationSourceId
-- ========================================== --
ALTER TABLE [dbo].[UserBrushThem] DROP COLUMN [MigrationSourceId];

-- ========================================== --
-- Command id: 1095
-- Description: حذف FK وابسته به aBrush
-- ========================================== --
ALTER TABLE [dbo].[UserBrushThemDe] DROP CONSTRAINT [FK_UserBrushThemDe_aBrush];

-- ========================================== --
-- Command id: 1096
-- Description: حذف جدول aBrush
-- ========================================== --
DROP TABLE [dbo].[aBrush];

-- ========================================== --
-- Command id: 1097
-- Description: حذف جدول aBrushHeader
-- ========================================== --
DROP TABLE [dbo].[aBrushHeader];
-- ========================================== --
-- Command id: 1098
-- Description: 
-- ========================================== --
DELETE FROM [dbo].[UserBrushThem]
WHERE [Userid] = 1;
-- ========================================== --
-- Command id: 1099
-- Description: تمهای رنگی 
-- ========================================== --
DECLARE @NewBrushThemId INT;
INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope]) VALUES (1, N'ذغالی مینیمال و پلاتین', 1);
SET @NewBrushThemId = SCOPE_IDENTITY();
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color]) VALUES
(@NewBrushThemId, 154, '#15191F'),
(@NewBrushThemId, 155, '#9AA7B4'),
(@NewBrushThemId, 156, 'Red'),
(@NewBrushThemId, 157, 'Black'),
(@NewBrushThemId, 158, '#FFF86060'),
(@NewBrushThemId, 159, '#FFADDE2A'),
(@NewBrushThemId, 160, 'Black'),
(@NewBrushThemId, 161, '#FFE7F019'),
(@NewBrushThemId, 162, '#1D2430'),
(@NewBrushThemId, 163, '#1B2029'),
(@NewBrushThemId, 164, '#8A96A3'),
(@NewBrushThemId, 165, '#9AA7B4'),
(@NewBrushThemId, 169, '#222933'),
(@NewBrushThemId, 172, '#9AA7B4'),
(@NewBrushThemId, 173, '#A7B2BE'),
(@NewBrushThemId, 174, '#FF4CDCBC'),
(@NewBrushThemId, 175, '#FF526C7B'),
(@NewBrushThemId, 176, '#323B4C'),
(@NewBrushThemId, 220, 'Gray'),
(@NewBrushThemId, 189, '#FFB24EAB'),
(@NewBrushThemId, 190, '#FF979899'),
(@NewBrushThemId, 191, '#FFB7BBBF'),
(@NewBrushThemId, 194, '#FF666464'),
(@NewBrushThemId, 195, '#FF8E8AC7'),
(@NewBrushThemId, 196, '#15191F'),
(@NewBrushThemId, 197, '#9AA7B4'),
(@NewBrushThemId, 198, '#9E3B3B'),
(@NewBrushThemId, 199, '#9AA7B4'),
(@NewBrushThemId, 200, '#C3CCD6'),
(@NewBrushThemId, 201, '#9AA7B4'),
(@NewBrushThemId, 205, '#9AA7B4'),
(@NewBrushThemId, 206, '#C3CCD6'),
(@NewBrushThemId, 209, '#2A3140'),
(@NewBrushThemId, 211, '#9AA7B4'),
(@NewBrushThemId, 212, '#15191F'),
(@NewBrushThemId, 213, '#15191F'),
(@NewBrushThemId, 214, '#9E3B3B'),
(@NewBrushThemId, 215, '#FFFFFF'),
(@NewBrushThemId, 216, '#762B2B'),
(@NewBrushThemId, 218, '#FF13BEBE'),
(@NewBrushThemId, 219, 'Black'),
(@NewBrushThemId, 221, '#9AA7B4'),
(@NewBrushThemId, 224, '#FFFF0000'),
(@NewBrushThemId, 236, '#B7C0CA'),
(@NewBrushThemId, 237, '#2A3140'),
(@NewBrushThemId, 238, '#E7EBEF'),
(@NewBrushThemId, 239, '#9AA7B4'),
(@NewBrushThemId, 240, '#15191F'),
(@NewBrushThemId, 166, '#76828F'),
(@NewBrushThemId, 202, '#E7EBEF'),
(@NewBrushThemId, 226, '#15191F'),
(@NewBrushThemId, 228, '#313A47'),
(@NewBrushThemId, 227, '#E7EBEF'),
(@NewBrushThemId, 231, '#9AA7B4'),
(@NewBrushThemId, 233, '#C3CCD6'),
(@NewBrushThemId, 229, '#8A96A3'),
(@NewBrushThemId, 230, '#8A96A3'),
(@NewBrushThemId, 234, '#A7B2BE'),
(@NewBrushThemId, 235, '#FFCDD9E9'),
(@NewBrushThemId, 177, '#E7EBEF'),
(@NewBrushThemId, 208, '#E7EBEF'),
(@NewBrushThemId, 210, '#F8F9FA');
-- ========================================== --
-- Command id: 10100
-- Description:  
-- ========================================== --
DECLARE @NewBrushThemId INT;
INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope]) VALUES (1, N'زیتونی خاکستری و برنز مات', 1);
SET @NewBrushThemId = SCOPE_IDENTITY();
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color]) VALUES
(@NewBrushThemId, 154, '#B7B6A6'),
(@NewBrushThemId, 155, '#7A5C3E'),
(@NewBrushThemId, 162, '#B0AF9D'),
(@NewBrushThemId, 175, '#FF526C7B'),
(@NewBrushThemId, 225, 'White'),
(@NewBrushThemId, 189, '#FFB24EAB'),
(@NewBrushThemId, 191, '#FFB7BBBF'),
(@NewBrushThemId, 220, 'Gray'),
(@NewBrushThemId, 218, '#FF13BEBE'),
(@NewBrushThemId, 194, '#FF666464'),
(@NewBrushThemId, 219, 'Black'),
(@NewBrushThemId, 195, '#FF8E8AC7'),
(@NewBrushThemId, 190, '#FF979899'),
(@NewBrushThemId, 224, '#FFFF0000'),
(@NewBrushThemId, 163, '#A9A897'),
(@NewBrushThemId, 164, '#4A4636'),
(@NewBrushThemId, 165, '#7A5C3E'),
(@NewBrushThemId, 166, '#5C4630'),
(@NewBrushThemId, 205, '#7A5C3E'),
(@NewBrushThemId, 206, '#97754F'),
(@NewBrushThemId, 236, '#2E2A1F'),
(@NewBrushThemId, 237, '#9E9C89'),
(@NewBrushThemId, 238, '#1A170F'),
(@NewBrushThemId, 239, '#7A5C3E'),
(@NewBrushThemId, 240, '#F5F1E8'),
(@NewBrushThemId, 169, '#C4C3B4'),
(@NewBrushThemId, 172, '#7A5C3E'),
(@NewBrushThemId, 173, '#2E2A1F'),
(@NewBrushThemId, 174, '#B4B3A1'),
(@NewBrushThemId, 176, '#B4B3A1'),
(@NewBrushThemId, 177, '#1A170F'),
(@NewBrushThemId, 226, '#B7B6A6'),
(@NewBrushThemId, 227, '#1A170F'),
(@NewBrushThemId, 228, '#93927F'),
(@NewBrushThemId, 229, '#4A4636'),
(@NewBrushThemId, 232, '#7A5C3E'),
(@NewBrushThemId, 233, '#97754F'),
(@NewBrushThemId, 234, '#2E2A1F'),
(@NewBrushThemId, 235, '#7A5C3E'),
(@NewBrushThemId, 196, '#B7B6A6'),
(@NewBrushThemId, 197, '#7A5C3E'),
(@NewBrushThemId, 198, '#8C2E28'),
(@NewBrushThemId, 199, '#7A5C3E'),
(@NewBrushThemId, 200, '#97754F'),
(@NewBrushThemId, 201, '#7A5C3E'),
(@NewBrushThemId, 202, '#1A170F'),
(@NewBrushThemId, 208, '#4A4636'),
(@NewBrushThemId, 209, '#9E9C89'),
(@NewBrushThemId, 210, '#1A170F'),
(@NewBrushThemId, 211, '#7A5C3E'),
(@NewBrushThemId, 212, '#F5F1E8'),
(@NewBrushThemId, 221, '#7A5C3E'),
(@NewBrushThemId, 213, '#F5F1E8'),
(@NewBrushThemId, 214, '#8C2E28'),
(@NewBrushThemId, 215, '#FFFFFF'),
(@NewBrushThemId, 216, '#6B211C'),
(@NewBrushThemId, 156, '#8C2E28'),
(@NewBrushThemId, 157, '#FFFFFF'),
(@NewBrushThemId, 158, '#6B211C'),
(@NewBrushThemId, 159, '#9E9C89'),
(@NewBrushThemId, 160, '#1A170F'),
(@NewBrushThemId, 161, '#B0AF9D');

-- ========================================== --
-- Command id: 1101
-- Description:  
-- ========================================== --
DECLARE @NewBrushThemId INT;
INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope]) VALUES (1, N'سرمه‌ای و طلایی', 1);
SET @NewBrushThemId = SCOPE_IDENTITY();
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color]) VALUES
(@NewBrushThemId, 154, '#0F1E33'),
(@NewBrushThemId, 155, '#D4AF37'),
(@NewBrushThemId, 162, '#16314F'),
(@NewBrushThemId, 174, '#FF4CDCBC'),
(@NewBrushThemId, 175, '#FF526C7B'),
(@NewBrushThemId, 220, 'Gray'),
(@NewBrushThemId, 189, '#FFB24EAB'),
(@NewBrushThemId, 190, '#FF979899'),
(@NewBrushThemId, 191, '#FFB7BBBF'),
(@NewBrushThemId, 194, '#FF666464'),
(@NewBrushThemId, 195, '#FF8E8AC7'),
(@NewBrushThemId, 218, '#FF13BEBE'),
(@NewBrushThemId, 219, 'Black'),
(@NewBrushThemId, 224, '#FFFF0000'),
(@NewBrushThemId, 163, '#122840'),
(@NewBrushThemId, 164, '#9FB3C8'),
(@NewBrushThemId, 165, '#D4AF37'),
(@NewBrushThemId, 166, '#B8901F'),
(@NewBrushThemId, 205, '#D4AF37'),
(@NewBrushThemId, 206, '#E8C468'),
(@NewBrushThemId, 236, '#C7CED8'),
(@NewBrushThemId, 237, '#1E3B5C'),
(@NewBrushThemId, 238, '#F0E6C8'),
(@NewBrushThemId, 239, '#D4AF37'),
(@NewBrushThemId, 240, '#0F1E33'),
(@NewBrushThemId, 156, '#B3282D'),
(@NewBrushThemId, 157, '#FFFFFF'),
(@NewBrushThemId, 158, '#8C1F22'),
(@NewBrushThemId, 159, '#1E3B5C'),
(@NewBrushThemId, 160, '#F0E6C8'),
(@NewBrushThemId, 161, '#16314F'),
(@NewBrushThemId, 169, '#1B3A5C'),
(@NewBrushThemId, 172, '#D4AF37'),
(@NewBrushThemId, 173, '#B8C4D4'),
(@NewBrushThemId, 176, '#284D73'),
(@NewBrushThemId, 177, '#F0E6C8'),
(@NewBrushThemId, 196, '#0F1E33'),
(@NewBrushThemId, 197, '#D4AF37'),
(@NewBrushThemId, 198, '#B3282D'),
(@NewBrushThemId, 199, '#D4AF37'),
(@NewBrushThemId, 200, '#E8C468'),
(@NewBrushThemId, 201, '#D4AF37'),
(@NewBrushThemId, 202, '#F0E6C8'),
(@NewBrushThemId, 208, '#9FB3C8'),
(@NewBrushThemId, 209, '#1E3B5C'),
(@NewBrushThemId, 210, '#F0E6C8'),
(@NewBrushThemId, 211, '#D4AF37'),
(@NewBrushThemId, 212, '#0F1E33'),
(@NewBrushThemId, 213, '#0F1E33'),
(@NewBrushThemId, 214, '#B3282D'),
(@NewBrushThemId, 215, '#FFFFFF'),
(@NewBrushThemId, 216, '#8C1F22'),
(@NewBrushThemId, 221, '#D4AF37'),
(@NewBrushThemId, 226, '#0F1E33'),
(@NewBrushThemId, 228, '#2C4A6E'),
(@NewBrushThemId, 227, '#F0E6C8'),
(@NewBrushThemId, 229, '#9FB3C8'),
(@NewBrushThemId, 230, '#9FB3C8'),
(@NewBrushThemId, 231, '#D4AF37'),
(@NewBrushThemId, 234, '#C7CED8'),
(@NewBrushThemId, 235, '#D4AF37');

-- ========================================== --
-- Command id: 1102
-- Description:  
-- ========================================== --
DECLARE @NewBrushThemId INT;
INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope]) VALUES (1, N'اسپرسو و مسی', 1);
SET @NewBrushThemId = SCOPE_IDENTITY();
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color]) VALUES
(@NewBrushThemId, 154, '#231712'),
(@NewBrushThemId, 155, '#C97A4A'),
(@NewBrushThemId, 156, '#A6392E'),
(@NewBrushThemId, 157, '#FFFFFF'),
(@NewBrushThemId, 158, '#7C2A21'),
(@NewBrushThemId, 159, '#FFADDE2A'),
(@NewBrushThemId, 160, 'Black'),
(@NewBrushThemId, 161, '#FFE7F019'),
(@NewBrushThemId, 162, '#140C08'),
(@NewBrushThemId, 163, '#2B1D16'),
(@NewBrushThemId, 164, '#B08D77'),
(@NewBrushThemId, 165, '#C97A4A'),
(@NewBrushThemId, 166, '#A15E33'),
(@NewBrushThemId, 169, '#34241B'),
(@NewBrushThemId, 172, '#C97A4A'),
(@NewBrushThemId, 173, '#C7AE9C'),
(@NewBrushThemId, 174, '#FF4CDCBC'),
(@NewBrushThemId, 175, '#FF526C7B'),
(@NewBrushThemId, 176, '#4A3427'),
(@NewBrushThemId, 177, '#EEDFC9'),
(@NewBrushThemId, 220, 'Gray'),
(@NewBrushThemId, 189, '#FFB24EAB'),
(@NewBrushThemId, 190, '#FF979899'),
(@NewBrushThemId, 191, '#FFB7BBBF'),
(@NewBrushThemId, 194, '#FF666464'),
(@NewBrushThemId, 195, '#FF8E8AC7'),
(@NewBrushThemId, 196, '#231712'),
(@NewBrushThemId, 197, '#C97A4A'),
(@NewBrushThemId, 198, '#A6392E'),
(@NewBrushThemId, 199, '#C97A4A'),
(@NewBrushThemId, 200, '#E0A272'),
(@NewBrushThemId, 201, '#C97A4A'),
(@NewBrushThemId, 202, '#EEDFC9'),
(@NewBrushThemId, 205, '#C97A4A'),
(@NewBrushThemId, 206, '#E0A272'),
(@NewBrushThemId, 209, '#3E2B20'),
(@NewBrushThemId, 211, '#C97A4A'),
(@NewBrushThemId, 212, '#231712'),
(@NewBrushThemId, 213, '#231712'),
(@NewBrushThemId, 214, '#A6392E'),
(@NewBrushThemId, 215, '#FFFFFF'),
(@NewBrushThemId, 216, '#7C2A21'),
(@NewBrushThemId, 218, '#FF13BEBE'),
(@NewBrushThemId, 219, 'Black'),
(@NewBrushThemId, 221, '#C97A4A'),
(@NewBrushThemId, 224, '#FFFF0000'),
(@NewBrushThemId, 236, '#D9C6B8'),
(@NewBrushThemId, 237, '#3E2B20'),
(@NewBrushThemId, 238, '#EEDFC9'),
(@NewBrushThemId, 239, '#C97A4A'),
(@NewBrushThemId, 240, '#231712'),
(@NewBrushThemId, 226, '#231712'),
(@NewBrushThemId, 228, '#4A3425'),
(@NewBrushThemId, 227, '#EEDFC9'),
(@NewBrushThemId, 233, '#E0A272'),
(@NewBrushThemId, 234, '#C7AE9C'),
(@NewBrushThemId, 235, '#C97A4A'),
(@NewBrushThemId, 229, '#B08D77'),
(@NewBrushThemId, 230, '#B08D77'),
(@NewBrushThemId, 208, '#EEDFC9'),
(@NewBrushThemId, 210, '#FAF5EF');

-- ========================================== --
-- Command id: 1103
-- Description:  
-- ========================================== --
DECLARE @NewBrushThemId INT;
INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope]) VALUES (1, N'آبی آسمانی و نقره‌ای', 1);
SET @NewBrushThemId = SCOPE_IDENTITY();
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color]) VALUES
(@NewBrushThemId, 154, '#E3EBF0'),
(@NewBrushThemId, 155, '#3E6D8E'),
(@NewBrushThemId, 163, '#D3E0E8'),
(@NewBrushThemId, 174, '#FF4CDCBC'),
(@NewBrushThemId, 175, '#FF526C7B'),
(@NewBrushThemId, 177, '#FF000000'),
(@NewBrushThemId, 225, 'White'),
(@NewBrushThemId, 189, '#FFB24EAB'),
(@NewBrushThemId, 191, '#FFB7BBBF'),
(@NewBrushThemId, 220, 'Gray'),
(@NewBrushThemId, 218, '#FF13BEBE'),
(@NewBrushThemId, 194, '#FF666464'),
(@NewBrushThemId, 219, 'Black'),
(@NewBrushThemId, 195, '#FF8E8AC7'),
(@NewBrushThemId, 190, '#FF979899'),
(@NewBrushThemId, 224, '#FFFF0000'),
(@NewBrushThemId, 202, '#FF62115D'),
(@NewBrushThemId, 205, '#3E6D8E'),
(@NewBrushThemId, 206, '#5A8CAE'),
(@NewBrushThemId, 236, '#2E4756'),
(@NewBrushThemId, 237, '#C4D8E2'),
(@NewBrushThemId, 238, '#13232B'),
(@NewBrushThemId, 239, '#3E6D8E'),
(@NewBrushThemId, 240, '#3E6D8E'),
(@NewBrushThemId, 162, '#DCE7EC'),
(@NewBrushThemId, 169, '#EAF1F5'),
(@NewBrushThemId, 172, '#3E6D8E'),
(@NewBrushThemId, 173, '#284350'),
(@NewBrushThemId, 176, '#DCE8ED'),
(@NewBrushThemId, 156, '#A6332E'),
(@NewBrushThemId, 157, '#FFFFFF'),
(@NewBrushThemId, 158, '#7C2320'),
(@NewBrushThemId, 159, '#C4D8E2'),
(@NewBrushThemId, 160, '#13232B'),
(@NewBrushThemId, 161, '#DCE7EC'),
(@NewBrushThemId, 164, '#5A7280'),
(@NewBrushThemId, 165, '#3E6D8E'),
(@NewBrushThemId, 166, '#2B4E68'),
(@NewBrushThemId, 196, '#E3EBF0'),
(@NewBrushThemId, 197, '#3E6D8E'),
(@NewBrushThemId, 198, '#A6332E'),
(@NewBrushThemId, 199, '#3E6D8E'),
(@NewBrushThemId, 200, '#5A8CAE'),
(@NewBrushThemId, 201, '#3E6D8E'),
(@NewBrushThemId, 208, '#5A7280'),
(@NewBrushThemId, 209, '#C4D8E2'),
(@NewBrushThemId, 210, '#13232B'),
(@NewBrushThemId, 211, '#3E6D8E'),
(@NewBrushThemId, 212, '#F5FAFC'),
(@NewBrushThemId, 221, '#F5FAFC'),
(@NewBrushThemId, 213, '#F5FAFC'),
(@NewBrushThemId, 214, '#A6332E'),
(@NewBrushThemId, 215, '#FFFFFF'),
(@NewBrushThemId, 216, '#7C2320'),
(@NewBrushThemId, 226, '#E3EBF0'),
(@NewBrushThemId, 227, '#13232B'),
(@NewBrushThemId, 229, '#5A7280'),
(@NewBrushThemId, 228, '#B9CBD6'),
(@NewBrushThemId, 233, '#5A8CAE'),
(@NewBrushThemId, 231, '#3E6D8E'),
(@NewBrushThemId, 232, '#3E6D8E'),
(@NewBrushThemId, 234, '#2E4756'),
(@NewBrushThemId, 235, '#3E6D8E');
-- ========================================== --
-- Command id: 1104
-- Description:  
-- ========================================== --
DECLARE @NewBrushThemId INT;
INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope]) VALUES (1, N'یشمی و نقره ای پلاتینی', 1);
SET @NewBrushThemId = SCOPE_IDENTITY();
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color]) VALUES
(@NewBrushThemId, 154, '#0B2A2E'),
(@NewBrushThemId, 155, '#D6DEE0'),
(@NewBrushThemId, 162, '#123C40'),
(@NewBrushThemId, 163, '#0E3438'),
(@NewBrushThemId, 174, '#FF4CDCBC'),
(@NewBrushThemId, 175, '#FF526C7B'),
(@NewBrushThemId, 225, 'White'),
(@NewBrushThemId, 189, '#FFB24EAB'),
(@NewBrushThemId, 191, '#FFB7BBBF'),
(@NewBrushThemId, 220, 'Gray'),
(@NewBrushThemId, 218, '#FF13BEBE'),
(@NewBrushThemId, 194, '#FF666464'),
(@NewBrushThemId, 219, 'Black'),
(@NewBrushThemId, 195, '#FF8E8AC7'),
(@NewBrushThemId, 190, '#FF979899'),
(@NewBrushThemId, 224, '#FFFF0000'),
(@NewBrushThemId, 205, '#D6DEE0'),
(@NewBrushThemId, 236, '#BFD3D2'),
(@NewBrushThemId, 237, '#1B4E53'),
(@NewBrushThemId, 238, '#E9F1EF'),
(@NewBrushThemId, 239, '#D6DEE0'),
(@NewBrushThemId, 240, '#0B2A2E'),
(@NewBrushThemId, 164, '#86ADA9'),
(@NewBrushThemId, 165, '#D6DEE0'),
(@NewBrushThemId, 166, '#A9B4B7'),
(@NewBrushThemId, 169, '#134045'),
(@NewBrushThemId, 196, '#0B2A2E'),
(@NewBrushThemId, 197, '#D6DEE0'),
(@NewBrushThemId, 199, '#D6DEE0'),
(@NewBrushThemId, 200, '#EDF2F3'),
(@NewBrushThemId, 201, '#D6DEE0'),
(@NewBrushThemId, 202, '#E9F1EF'),
(@NewBrushThemId, 209, '#1B4E53'),
(@NewBrushThemId, 211, '#D6DEE0'),
(@NewBrushThemId, 212, '#0B2A2E'),
(@NewBrushThemId, 221, '#D6DEE0'),
(@NewBrushThemId, 214, '#B1403C'),
(@NewBrushThemId, 172, '#D6DEE0'),
(@NewBrushThemId, 173, '#A8C4C1'),
(@NewBrushThemId, 176, '#235F64'),
(@NewBrushThemId, 177, '#E9F1EF'),
(@NewBrushThemId, 198, '#FFFF0000'),
(@NewBrushThemId, 206, '#1B4E53'),
(@NewBrushThemId, 232, '#D6DEE0'),
(@NewBrushThemId, 226, '#0B2A2E'),
(@NewBrushThemId, 228, '#1F565C'),
(@NewBrushThemId, 233, '#EDF2F3'),
(@NewBrushThemId, 231, '#D6DEE0'),
(@NewBrushThemId, 229, '#86ADA9'),
(@NewBrushThemId, 227, '#E9F1EF'),
(@NewBrushThemId, 234, '#A8C4C1'),
(@NewBrushThemId, 235, '#D6DEE0'),
(@NewBrushThemId, 230, '#86ADA9'),
(@NewBrushThemId, 156, '#B1403C'),
(@NewBrushThemId, 157, '#FFFFFF'),
(@NewBrushThemId, 158, '#8A2E2B'),
(@NewBrushThemId, 159, '#1B4E53'),
(@NewBrushThemId, 160, '#E9F1EF'),
(@NewBrushThemId, 161, '#123C40'),
(@NewBrushThemId, 216, '#8A2E2B'),
(@NewBrushThemId, 208, '#E9F1EF'),
(@NewBrushThemId, 210, '#F8FBFA'),
(@NewBrushThemId, 213, '#0B2A2E'),
(@NewBrushThemId, 215, '#FFFFFF');

-- ========================================== --
-- Command id: 1105
-- Description:  
-- ========================================== --
DECLARE @NewBrushThemId INT;
INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope]) VALUES (1, N'بژ صورتی و رزگلد کمرنگ', 1);
SET @NewBrushThemId = SCOPE_IDENTITY();
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color]) VALUES
(@NewBrushThemId, 154, '#F3E9E4'),
(@NewBrushThemId, 155, '#B8756A'),
(@NewBrushThemId, 156, 'Red'),
(@NewBrushThemId, 157, 'Black'),
(@NewBrushThemId, 158, '#FFF86060'),
(@NewBrushThemId, 159, '#FFADDE2A'),
(@NewBrushThemId, 160, 'Black'),
(@NewBrushThemId, 161, '#FFE7F019'),
(@NewBrushThemId, 162, '#EFE1D9'),
(@NewBrushThemId, 163, '#EDDBD3'),
(@NewBrushThemId, 164, '#9C7A70'),
(@NewBrushThemId, 165, '#B8756A'),
(@NewBrushThemId, 166, '#8F584F'),
(@NewBrushThemId, 169, '#F7EEE9'),
(@NewBrushThemId, 172, '#B8756A'),
(@NewBrushThemId, 173, '#5C3F38'),
(@NewBrushThemId, 174, '#F0DED4'),
(@NewBrushThemId, 175, '#FF526C7B'),
(@NewBrushThemId, 176, '#F0DED4'),
(@NewBrushThemId, 177, '#3D2620'),
(@NewBrushThemId, 225, 'White'),
(@NewBrushThemId, 189, '#FFB24EAB'),
(@NewBrushThemId, 191, '#FFB7BBBF'),
(@NewBrushThemId, 220, 'Gray'),
(@NewBrushThemId, 218, '#FF13BEBE'),
(@NewBrushThemId, 194, '#FF666464'),
(@NewBrushThemId, 219, 'Black'),
(@NewBrushThemId, 195, '#FF8E8AC7'),
(@NewBrushThemId, 190, '#FF979899'),
(@NewBrushThemId, 224, '#FFFF0000'),
(@NewBrushThemId, 205, '#B8756A'),
(@NewBrushThemId, 206, '#D29B8E'),
(@NewBrushThemId, 236, '#6B4B44'),
(@NewBrushThemId, 237, '#E6CCC0'),
(@NewBrushThemId, 238, '#3D2620'),
(@NewBrushThemId, 239, '#B8756A'),
(@NewBrushThemId, 240, '#FBF3EF'),
(@NewBrushThemId, 226, '#F3E9E4'),
(@NewBrushThemId, 227, '#3D2620'),
(@NewBrushThemId, 228, '#DFC3B8'),
(@NewBrushThemId, 229, '#9C7A70'),
(@NewBrushThemId, 231, '#B8756A'),
(@NewBrushThemId, 232, '#B8756A'),
(@NewBrushThemId, 234, '#6B4B44'),
(@NewBrushThemId, 235, '#B8756A'),
(@NewBrushThemId, 233, '#D29B8E'),
(@NewBrushThemId, 196, '#F3E9E4'),
(@NewBrushThemId, 197, '#B8756A'),
(@NewBrushThemId, 198, '#A6332E'),
(@NewBrushThemId, 199, '#B8756A'),
(@NewBrushThemId, 200, '#D29B8E'),
(@NewBrushThemId, 201, '#B8756A'),
(@NewBrushThemId, 202, '#3D2620'),
(@NewBrushThemId, 208, '#9C7A70'),
(@NewBrushThemId, 209, '#E6CCC0'),
(@NewBrushThemId, 210, '#3D2620'),
(@NewBrushThemId, 211, '#B8756A'),
(@NewBrushThemId, 212, '#FBF3EF'),
(@NewBrushThemId, 221, '#FBF3EF'),
(@NewBrushThemId, 213, '#FBF3EF'),
(@NewBrushThemId, 214, '#A6332E'),
(@NewBrushThemId, 215, '#FFFFFF'),
(@NewBrushThemId, 216, '#7C2320');
-- ========================================== --
-- Command id: 1106
-- Description:  
-- ========================================== --
DECLARE @NewBrushThemId INT;
INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope]) VALUES (1, N'کرم طلایی روشن', 1);
SET @NewBrushThemId = SCOPE_IDENTITY();
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color]) VALUES
(@NewBrushThemId, 154, '#F5F1E6'),
(@NewBrushThemId, 155, '#B8860B'),
(@NewBrushThemId, 156, 'Red'),
(@NewBrushThemId, 157, 'Black'),
(@NewBrushThemId, 158, '#FFF86060'),
(@NewBrushThemId, 159, '#FFADDE2A'),
(@NewBrushThemId, 160, 'Black'),
(@NewBrushThemId, 161, '#FFE7F019'),
(@NewBrushThemId, 162, '#F0E9D5'),
(@NewBrushThemId, 163, '#EFE8D6'),
(@NewBrushThemId, 164, '#8A7550'),
(@NewBrushThemId, 165, '#B8860B'),
(@NewBrushThemId, 166, '#8C6A08'),
(@NewBrushThemId, 169, '#F8F4EA'),
(@NewBrushThemId, 172, '#B8860B'),
(@NewBrushThemId, 173, '#5A4B2E'),
(@NewBrushThemId, 174, '#EFE2BE'),
(@NewBrushThemId, 175, '#FF526C7B'),
(@NewBrushThemId, 176, '#EFE2BE'),
(@NewBrushThemId, 177, '#3A2F1D'),
(@NewBrushThemId, 225, 'White'),
(@NewBrushThemId, 189, '#FFB24EAB'),
(@NewBrushThemId, 191, '#FFB7BBBF'),
(@NewBrushThemId, 220, 'Gray'),
(@NewBrushThemId, 218, '#FF13BEBE'),
(@NewBrushThemId, 194, '#FF666464'),
(@NewBrushThemId, 219, 'Black'),
(@NewBrushThemId, 195, '#FF8E8AC7'),
(@NewBrushThemId, 190, '#FF979899'),
(@NewBrushThemId, 224, '#FFFF0000'),
(@NewBrushThemId, 205, '#B8860B'),
(@NewBrushThemId, 206, '#9C92A5'),
(@NewBrushThemId, 236, '#6B5D3E'),
(@NewBrushThemId, 237, '#E6DAB8'),
(@NewBrushThemId, 238, '#3A2F1D'),
(@NewBrushThemId, 239, '#B8860B'),
(@NewBrushThemId, 240, '#FDFBF3'),
(@NewBrushThemId, 208, '#8A7550'),
(@NewBrushThemId, 209, '#E6DAB8'),
(@NewBrushThemId, 210, '#3A2F1D'),
(@NewBrushThemId, 211, '#B8860B'),
(@NewBrushThemId, 212, '#FDFBF3'),
(@NewBrushThemId, 221, '#FDFBF3'),
(@NewBrushThemId, 213, '#FDFBF3'),
(@NewBrushThemId, 214, '#A6332E'),
(@NewBrushThemId, 215, '#FFFFFF'),
(@NewBrushThemId, 216, '#7C2320'),
(@NewBrushThemId, 196, '#F5F1E6'),
(@NewBrushThemId, 197, '#B8860B'),
(@NewBrushThemId, 198, '#A6332E'),
(@NewBrushThemId, 199, '#B8860B'),
(@NewBrushThemId, 200, '#D4AF37'),
(@NewBrushThemId, 201, '#B8860B'),
(@NewBrushThemId, 202, '#3A2F1D'),
(@NewBrushThemId, 226, '#F5F1E6'),
(@NewBrushThemId, 227, '#3A2F1D'),
(@NewBrushThemId, 228, '#DCCE9E'),
(@NewBrushThemId, 229, '#8A7550'),
(@NewBrushThemId, 231, '#B8860B'),
(@NewBrushThemId, 233, '#D4AF37'),
(@NewBrushThemId, 232, '#B8860B'),
(@NewBrushThemId, 234, '#6B5D3E'),
(@NewBrushThemId, 235, '#B8860B');


-- ========================================== --
-- Command id: 1107
-- Description:  
-- ========================================== --
DECLARE @NewBrushThemId INT;
INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope]) VALUES (1, N'زمردی و برنز', 1);
SET @NewBrushThemId = SCOPE_IDENTITY();
INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color]) VALUES
(@NewBrushThemId, 154, '#0D2B24'),
(@NewBrushThemId, 155, '#C08A3E'),
(@NewBrushThemId, 162, '#154A3C'),
(@NewBrushThemId, 174, '#FF4CDCBC'),
(@NewBrushThemId, 175, '#FF526C7B'),
(@NewBrushThemId, 220, 'Gray'),
(@NewBrushThemId, 189, '#FFB24EAB'),
(@NewBrushThemId, 190, '#FF979899'),
(@NewBrushThemId, 191, '#FFB7BBBF'),
(@NewBrushThemId, 194, '#FF666464'),
(@NewBrushThemId, 195, '#FF8E8AC7'),
(@NewBrushThemId, 218, '#FF13BEBE'),
(@NewBrushThemId, 219, 'Black'),
(@NewBrushThemId, 224, '#FFFF0000'),
(@NewBrushThemId, 163, '#0F3A30'),
(@NewBrushThemId, 164, '#8FB3A5'),
(@NewBrushThemId, 165, '#C08A3E'),
(@NewBrushThemId, 166, '#9C6B27'),
(@NewBrushThemId, 205, '#C08A3E'),
(@NewBrushThemId, 206, '#D9AE6B'),
(@NewBrushThemId, 236, '#C9D9D1'),
(@NewBrushThemId, 237, '#1C5645'),
(@NewBrushThemId, 238, '#EDE0C8'),
(@NewBrushThemId, 239, '#C08A3E'),
(@NewBrushThemId, 240, '#0D2B24'),
(@NewBrushThemId, 169, '#15493C'),
(@NewBrushThemId, 172, '#C08A3E'),
(@NewBrushThemId, 173, '#A9C7BA'),
(@NewBrushThemId, 176, '#296B55'),
(@NewBrushThemId, 177, '#EDE0C8'),
(@NewBrushThemId, 196, '#0D2B24'),
(@NewBrushThemId, 197, '#C08A3E'),
(@NewBrushThemId, 198, '#A6332E'),
(@NewBrushThemId, 199, '#C08A3E'),
(@NewBrushThemId, 200, '#D9AE6B'),
(@NewBrushThemId, 201, '#C08A3E'),
(@NewBrushThemId, 202, '#EDE0C8'),
(@NewBrushThemId, 226, '#0D2B24'),
(@NewBrushThemId, 227, '#EDE0C8'),
(@NewBrushThemId, 229, '#8FB3A5'),
(@NewBrushThemId, 228, '#24604F'),
(@NewBrushThemId, 231, '#C08A3E'),
(@NewBrushThemId, 232, '#C08A3E'),
(@NewBrushThemId, 230, '#8FB3A5'),
(@NewBrushThemId, 234, '#C9D9D1'),
(@NewBrushThemId, 235, '#C08A3E'),
(@NewBrushThemId, 233, '#D9AE6B'),
(@NewBrushThemId, 208, '#8FB3A5'),
(@NewBrushThemId, 209, '#1C5645'),
(@NewBrushThemId, 210, '#EDE0C8'),
(@NewBrushThemId, 211, '#C08A3E'),
(@NewBrushThemId, 212, '#0D2B24'),
(@NewBrushThemId, 213, '#0D2B24'),
(@NewBrushThemId, 214, '#A6332E'),
(@NewBrushThemId, 215, '#FFFFFF'),
(@NewBrushThemId, 216, '#7C2320'),
(@NewBrushThemId, 221, '#0D2B24'),
(@NewBrushThemId, 156, '#A6332E'),
(@NewBrushThemId, 157, '#FFFFFF'),
(@NewBrushThemId, 158, '#7C2320'),
(@NewBrushThemId, 159, '#1C5645'),
(@NewBrushThemId, 160, '#EDE0C8'),
(@NewBrushThemId, 161, '#154A3C');
-- ========================================== --
-- Command id: 1108
-- Description: تم پیش فرض
-- ========================================== --
DECLARE @NewBrushThemId INT;

INSERT INTO [dbo].[UserBrushThem] ([Userid], [Title], [Scope])
VALUES (1, N'تم پیش فرض روشن', 2);

SET @NewBrushThemId = SCOPE_IDENTITY();

INSERT INTO [dbo].[UserBrushThemDe] ([BrushThemid], [Brushid], [Color])
VALUES
(@NewBrushThemId, 1,   '#FFF3F3F3'),
(@NewBrushThemId, 2,   '#FFE0D9D9'),
(@NewBrushThemId, 3,   '#FF000000'),
(@NewBrushThemId, 4,   '#FFF8FAFE'),
(@NewBrushThemId, 5,   '#FF333333'),
(@NewBrushThemId, 6,   '#FF399A39'),
(@NewBrushThemId, 7,   '#FF399A39'),
(@NewBrushThemId, 8,   '#FF000000'),
(@NewBrushThemId, 9,   '#FF399A39'),
(@NewBrushThemId, 10,  '#FF399A39'),
(@NewBrushThemId, 11,  '#FF4169E1'),
(@NewBrushThemId, 12,  '#FFB8860B'),
(@NewBrushThemId, 13,  'Black'),
(@NewBrushThemId, 14,  '#FF399A39'),
(@NewBrushThemId, 15,  '#FF399A39'),
(@NewBrushThemId, 16,  '#FFDD2C2C'),
(@NewBrushThemId, 17,  '#FFDD2C2C'),
(@NewBrushThemId, 18,  '#FFE1A07F'),
(@NewBrushThemId, 19,  '#FF399A39'),
(@NewBrushThemId, 20,  '#FF399A39'),
(@NewBrushThemId, 21,  '#FF399A39'),
(@NewBrushThemId, 22,  '#FF399A39'),
(@NewBrushThemId, 23,  '#FFD7ECF7'),
(@NewBrushThemId, 24,  '#FFC71585'),
(@NewBrushThemId, 25,  '#FFC4E6F7'),
(@NewBrushThemId, 26,  '#FF0000FF'),
(@NewBrushThemId, 27,  '#FFEFEFF2'),
(@NewBrushThemId, 28,  '#444'),
(@NewBrushThemId, 29,  'LightGreen'),
(@NewBrushThemId, 30,  '#FFF8EFB3'),
(@NewBrushThemId, 31,  '#FF343738'),
(@NewBrushThemId, 32,  '#FFFFFFFF'),
(@NewBrushThemId, 33,  '#FF07078C'),
(@NewBrushThemId, 34,  '#97a8ac'),
(@NewBrushThemId, 35,  '#FF13BEBE'),
(@NewBrushThemId, 36,  '#FFE9F4FB'),
(@NewBrushThemId, 37,  '#FF0000FF'),
(@NewBrushThemId, 217, 'Red'),
(@NewBrushThemId, 38,  '#EEE'),
(@NewBrushThemId, 39,  '#ddeaff'),
(@NewBrushThemId, 40,  '#FF0000FF'),
(@NewBrushThemId, 41,  '#FFF4F4F4'),
(@NewBrushThemId, 42,  'Blue'),
(@NewBrushThemId, 43,  '#97a8ac'),
(@NewBrushThemId, 44,  '#FFD7E9C1'),
(@NewBrushThemId, 45,  '#444'),
(@NewBrushThemId, 46,  '#FFF'),
(@NewBrushThemId, 47,  '#97a8ac'),
(@NewBrushThemId, 48,  'Blue'),
(@NewBrushThemId, 49,  '#FFC8E0AE'),
(@NewBrushThemId, 50,  '#FFE4EED7'),
(@NewBrushThemId, 51,  '#ACACAC'),
(@NewBrushThemId, 52,  '#FFDFE3E9'),
(@NewBrushThemId, 53,  '#FFC1D6DB'),
(@NewBrushThemId, 54,  '#FF464242'),
(@NewBrushThemId, 55,  '#FFFDD1FF'),
(@NewBrushThemId, 56,  '#FF80397B'),
(@NewBrushThemId, 57,  '#FF666666'),
(@NewBrushThemId, 58,  '#FFC1C1C1'),
(@NewBrushThemId, 59,  '#FF8B008B'),
(@NewBrushThemId, 60,  '#FFFFFFFF'),
(@NewBrushThemId, 61,  '#FFF'),
(@NewBrushThemId, 62,  '#FFB0C4DE'),
(@NewBrushThemId, 63,  '#FF0000FF'),
(@NewBrushThemId, 64,  '#FFE5F3F7'),
(@NewBrushThemId, 65,  '#FFE4EED7'),
(@NewBrushThemId, 66,  '#ACACAC'),
(@NewBrushThemId, 67,  '#FFDFE3E9'),
(@NewBrushThemId, 68,  '#FF0000FF'),
(@NewBrushThemId, 69,  '#FFD8D5D5'),
(@NewBrushThemId, 70,  '#FFACACAC'),
(@NewBrushThemId, 71,  '#FF257F8F'),
(@NewBrushThemId, 72,  'White'),
(@NewBrushThemId, 73,  '#FF4F4F4F'),
(@NewBrushThemId, 74,  '#FF3FAEC2'),
(@NewBrushThemId, 75,  '#FF000000'),
(@NewBrushThemId, 76,  '#FF808080'),
(@NewBrushThemId, 77,  '#FF69A2DE'),
(@NewBrushThemId, 78,  '#FFDFE3E9'),
(@NewBrushThemId, 79,  '#FFFF8C00'),
(@NewBrushThemId, 80,  '#FF00008B'),
(@NewBrushThemId, 81,  '#FF4169E1'),
(@NewBrushThemId, 82,  '#FFF9F9F9'),
(@NewBrushThemId, 83,  '#FF4682B4'),
(@NewBrushThemId, 84,  '#FFA0CBDE'),
(@NewBrushThemId, 85,  '#FFA0CBDE'),
(@NewBrushThemId, 86,  '#FFC8E2EA'),
(@NewBrushThemId, 87,  '#FF00008B'),
(@NewBrushThemId, 88,  '#FFA0CBDE'),
(@NewBrushThemId, 89,  '#FF000080'),
(@NewBrushThemId, 90,  '#FF81C8DE'),
(@NewBrushThemId, 91,  '#FFC8E2EA'),
(@NewBrushThemId, 92,  '#FF00008B'),
(@NewBrushThemId, 93,  '#FFA0CBDE'),
(@NewBrushThemId, 94,  '#FFFCEEE9'),
(@NewBrushThemId, 95,  '#FF000000'),
(@NewBrushThemId, 96,  '#FFFFFFFF'),
(@NewBrushThemId, 97,  '#FFF2FBFF'),
(@NewBrushThemId, 98,  '#FFE8E0B4'),
(@NewBrushThemId, 99,  '#FFAFEEEE'),
(@NewBrushThemId, 100, '#FF000000'),
(@NewBrushThemId, 101, 'Black'),
(@NewBrushThemId, 102, '#FF0000FF'),
(@NewBrushThemId, 103, 'White'),
(@NewBrushThemId, 104, '#FFFFFFE1'),
(@NewBrushThemId, 105, 'Black'),
(@NewBrushThemId, 106, '#FF8E8E90'),
(@NewBrushThemId, 107, '#FF000000'),
(@NewBrushThemId, 108, '#FFE8ECEE'),
(@NewBrushThemId, 109, '#FFA0CBDE'),
(@NewBrushThemId, 110, '#00FFFFFF'),
(@NewBrushThemId, 111, '#FFA0CBDE'),
(@NewBrushThemId, 112, '#FFFFFFFF'),
(@NewBrushThemId, 113, '#FFF2FBFF'),
(@NewBrushThemId, 114, 'Black'),
(@NewBrushThemId, 115, '#FFAFEEEE'),
(@NewBrushThemId, 116, 'Black'),
(@NewBrushThemId, 117, '#FF0000CB'),
(@NewBrushThemId, 118, '#FF8D0000'),
(@NewBrushThemId, 119, '#FF0000CB'),
(@NewBrushThemId, 120, '#FF8D0000'),
(@NewBrushThemId, 121, '#FF416384'),
(@NewBrushThemId, 122, '#FF000000'),
(@NewBrushThemId, 123, '#FF0000FF'),
(@NewBrushThemId, 124, '#FFA9CBD6'),
(@NewBrushThemId, 125, '#FFD94242'),
(@NewBrushThemId, 126, '#F0F0F0'),
(@NewBrushThemId, 127, '#FFACC2C8'),
(@NewBrushThemId, 128, '#FF5F6B6F'),
(@NewBrushThemId, 129, '#FF000000'),
(@NewBrushThemId, 130, '#FFF0FFFF'),
(@NewBrushThemId, 131, '#FF000000'),
(@NewBrushThemId, 132, '#FFCEDDE1'),
(@NewBrushThemId, 133, '#FFCEDDE1'),
(@NewBrushThemId, 134, 'White'),
(@NewBrushThemId, 135, '#FFDBE2E5'),
(@NewBrushThemId, 136, '#FF8B008B'),
(@NewBrushThemId, 137, '#FFFFFFFF'),
(@NewBrushThemId, 138, '#FFFFFFFF'),
(@NewBrushThemId, 139, 'Black'),
(@NewBrushThemId, 140, '#FFFF00FF'),
(@NewBrushThemId, 141, '#FFD884D3'),
(@NewBrushThemId, 142, 'White'),
(@NewBrushThemId, 143, '#FFFFD700'),
(@NewBrushThemId, 144, '#FFE8BFF9'),
(@NewBrushThemId, 145, '#FFB24EAB'),
(@NewBrushThemId, 146, '#FFFFFFFF'),
(@NewBrushThemId, 147, '#EEE'),
(@NewBrushThemId, 148, '#888'),
(@NewBrushThemId, 149, '#FFBAC6DA'),
(@NewBrushThemId, 150, '#888'),
(@NewBrushThemId, 151, '#EEE'),
(@NewBrushThemId, 152, '#FFA1A1A1'),
(@NewBrushThemId, 153, '#AAA');

-- ========================================== --
-- Command id: 1109
-- Description:  
-- ========================================== --
DECLARE @ThemeValue VARCHAR(MAX);

SELECT @ThemeValue = CAST([id] AS VARCHAR(MAX))
FROM [dbo].[UserBrushThem]
WHERE [Title] = N'تم پیش فرض روشن';

IF @ThemeValue IS NULL
BEGIN
    SELECT @ThemeValue = CAST(MAX([id]) AS VARCHAR(MAX))
    FROM [dbo].[UserBrushThem]
    WHERE [Scope] = 2;
END

INSERT INTO [dbo].[UserSetting] ([Userid], [Settingid], [KeyValue], [Value])
SELECT
    u.[id],
    'CurrentFormTheme',
    NULL,
    @ThemeValue
FROM [dbo].[User] u;
-- ========================================== --
-- Command id: 1110
-- Description:  
-- ========================================== --
DECLARE @ThemeValue VARCHAR(MAX);

SELECT @ThemeValue = CAST([id] AS VARCHAR(MAX))
FROM [dbo].[UserBrushThem]
WHERE [Title] = N'سرمه‌ای و طلایی';

IF @ThemeValue IS NULL
BEGIN
    SELECT @ThemeValue = CAST(MAX([id]) AS VARCHAR(MAX))
    FROM [dbo].[UserBrushThem]
    WHERE [Scope] = 1;
END
INSERT INTO [dbo].[UserSetting] ([Userid], [Settingid], [KeyValue], [Value])
SELECT
    u.[id],
    'CurrentShellTheme',
    NULL,
    @ThemeValue
FROM [dbo].[User] u;
-- ========================================== --
-- Command id: 1111
-- Description:  
-- ========================================== --
DELETE FROM [dbo].[UserSetting]
WHERE [Settingid] = 'CurrentBrushThem';
-- ========================================== --
-- Command id: 1112
-- Description:  
-- ========================================== --
UPDATE r
SET r.Status = CASE
    WHEN EXISTS (
        SELECT 1 FROM KalaReceiptDe d
        WHERE d.Receiptid = r.id AND d.StatusDe = 0 -- Temporary
    ) THEN 0 -- Temporary
    WHEN NOT EXISTS (
        SELECT 1 FROM KalaReceiptDe d
        WHERE d.Receiptid = r.id AND d.StatusDe <> 2 -- هر قلمی غیر از Ebtal
    ) THEN 2 -- همه‌ی اقلام Ebtal هستند
    ELSE 1 -- Daem (ترکیبی از Storage و Ebtal، بدون هیچ Temporary)
END
FROM KalaReceipt r
WHERE EXISTS (SELECT 1 FROM KalaReceiptDe d WHERE d.Receiptid = r.id);