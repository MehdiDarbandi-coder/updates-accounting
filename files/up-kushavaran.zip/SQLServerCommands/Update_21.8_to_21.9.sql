﻿-- ========================================== --
-- Command id: 1143
-- Description: 
-- ========================================== --
DELETE FROM UserBrushThemDe
WHERE Brushid IN (1211, 1212, 1217, 1218, 1223, 1224, 1234);
-- ========================================== --
-- Command id: 1144
-- Description: 
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) VALUES
(14, 1236, '#FFD0D0D0'), (14, 1237, '#FF0078D4'),
(15, 1236, '#FFC5CDD3'), (15, 1237, '#FF2976AE'),
(16, 1236, '#FFC5D3CC'), (16, 1237, '#FF29AE6B'),
(17, 1236, '#FFCAC6D2'), (17, 1237, '#FF5B2FA7'),
(18, 1236, '#FFD3C9C5'), (18, 1237, '#FFAE5129'),
(19, 1236, '#FFCACCCE'), (19, 1237, '#FF566A80'),
(20, 1236, '#FFC5D3D2'), (20, 1237, '#FF29AEA9'),
(21, 1236, '#FF49535B'), (21, 1237, '#FF64A8D8'),
(22, 1236, '#FF4E5155'), (22, 1237, '#FF889AB4');
-- ========================================== --
-- Command id: 1145
-- Description: 
-- ========================================== --
UPDATE UserBrushThemDe SET Color = '#FFB2D7F2' WHERE BrushThemid = 14 AND Brushid = 1194;
UPDATE UserBrushThemDe SET Color = '#FFBAD4E6' WHERE BrushThemid = 15 AND Brushid = 1194;
UPDATE UserBrushThemDe SET Color = '#FFBAE6CF' WHERE BrushThemid = 16 AND Brushid = 1194;
UPDATE UserBrushThemDe SET Color = '#FFCABCE3' WHERE BrushThemid = 17 AND Brushid = 1194;
UPDATE UserBrushThemDe SET Color = '#FFE6C7BA' WHERE BrushThemid = 18 AND Brushid = 1194;
UPDATE UserBrushThemDe SET Color = '#FFC9CED7' WHERE BrushThemid = 19 AND Brushid = 1194;
UPDATE UserBrushThemDe SET Color = '#FFBAE6E3' WHERE BrushThemid = 20 AND Brushid = 1194;
UPDATE UserBrushThemDe SET Color = '#FF6C90AA' WHERE BrushThemid = 21 AND Brushid = 1194;
UPDATE UserBrushThemDe SET Color = '#FF7F8897' WHERE BrushThemid = 22 AND Brushid = 1194;
-- ========================================== --
-- Command id: 1146
-- Description: 
-- ========================================== --
UPDATE UserBrushThemDe SET Color = '#FFBDDEFF' WHERE BrushThemid = 14 AND Brushid = 1225;
UPDATE UserBrushThemDe SET Color = '#FFBCD2E2' WHERE BrushThemid = 15 AND Brushid = 1225;
UPDATE UserBrushThemDe SET Color = '#FFBCE2CF' WHERE BrushThemid = 16 AND Brushid = 1225;
UPDATE UserBrushThemDe SET Color = '#FFCABEE0' WHERE BrushThemid = 17 AND Brushid = 1225;
UPDATE UserBrushThemDe SET Color = '#FFE2C7BC' WHERE BrushThemid = 18 AND Brushid = 1225;
UPDATE UserBrushThemDe SET Color = '#FFC9CFD5' WHERE BrushThemid = 19 AND Brushid = 1225;
UPDATE UserBrushThemDe SET Color = '#FFBCE2E0' WHERE BrushThemid = 20 AND Brushid = 1225;
UPDATE UserBrushThemDe SET Color = '#FFBBD0DF' WHERE BrushThemid = 21 AND Brushid = 1225;
UPDATE UserBrushThemDe SET Color = '#FFC6CCD4' WHERE BrushThemid = 22 AND Brushid = 1225;
-- ========================================== --
-- Command id: 1147
-- Description: 
-- ========================================== --
UPDATE UserBrushThemDe SET Color = '#FF1E1E1E' WHERE BrushThemid = 14 AND Brushid = 1226;
UPDATE UserBrushThemDe SET Color = '#FF1E1E1E' WHERE BrushThemid = 15 AND Brushid = 1226;
UPDATE UserBrushThemDe SET Color = '#FF1E1E1E' WHERE BrushThemid = 16 AND Brushid = 1226;
UPDATE UserBrushThemDe SET Color = '#FF1E1E1E' WHERE BrushThemid = 17 AND Brushid = 1226;
UPDATE UserBrushThemDe SET Color = '#FF1E1E1E' WHERE BrushThemid = 18 AND Brushid = 1226;
UPDATE UserBrushThemDe SET Color = '#FF1E1E1E' WHERE BrushThemid = 19 AND Brushid = 1226;
UPDATE UserBrushThemDe SET Color = '#FF1E1E1E' WHERE BrushThemid = 20 AND Brushid = 1226;
UPDATE UserBrushThemDe SET Color = '#FF1E1E1E' WHERE BrushThemid = 21 AND Brushid = 1226;
UPDATE UserBrushThemDe SET Color = '#FF1E1E1E' WHERE BrushThemid = 22 AND Brushid = 1226;