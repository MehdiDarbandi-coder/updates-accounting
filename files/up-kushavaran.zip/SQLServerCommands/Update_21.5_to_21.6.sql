﻿-- ========================================== --
-- Command id: 1110
-- Description: اگر ساختار جدید از قبل اعمال شده، فقط Company_Old باقی‌مانده را حذف کن و خارج شو
-- ========================================== --
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.Company') AND name = 'CompanyType')
BEGIN
	IF OBJECT_ID('dbo.Company_Old', 'U') IS NOT NULL
	BEGIN
		DROP TABLE dbo.Company_Old;
	END
END
-- ========================================== --
-- Command id: 1111
-- Description: پاک‌سازی وضعیت ناقص باقی‌مانده از اجراهای قبلی (اگر هم Company قدیمی و هم Company_Old هرکدام وجود دارند)
-- ========================================== --
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.Company') AND name = 'CompanyType')
AND OBJECT_ID('dbo.Company', 'U') IS NOT NULL
AND OBJECT_ID('dbo.Company_Old', 'U') IS NOT NULL
BEGIN
	DROP TABLE dbo.Company;
END
-- ========================================== --
-- Command id: 1112
-- Description: تغییر نام جدول قبلی Company به Company_Old
-- ========================================== --
IF OBJECT_ID('dbo.Company', 'U') IS NOT NULL AND OBJECT_ID('dbo.Company_Old', 'U') IS NULL
BEGIN
	EXEC sp_rename 'dbo.Company', 'Company_Old';
END
-- ========================================== --
-- Command id: 1113
-- Description: آزادسازی نام PK_Company (حذف و بازسازی Constraint قدیمی با نام PK_Company_Old)
-- ========================================== --
IF OBJECT_ID('dbo.Company_Old', 'U') IS NOT NULL
BEGIN
	DECLARE @pkName SYSNAME;

	SELECT @pkName = kc.name
	FROM sys.key_constraints kc
	WHERE kc.parent_object_id = OBJECT_ID('dbo.Company_Old')
	AND kc.type = 'PK';

	IF @pkName IS NOT NULL AND @pkName <> 'PK_Company_Old'
	BEGIN
		DECLARE @sql1 NVARCHAR(1000) = N'ALTER TABLE dbo.Company_Old DROP CONSTRAINT ' + QUOTENAME(@pkName) + N';';
		EXEC sp_executesql @sql1;

		DECLARE @sql2 NVARCHAR(1000) = N'ALTER TABLE dbo.Company_Old ADD CONSTRAINT PK_Company_Old PRIMARY KEY CLUSTERED ([id] ASC);';
		EXEC sp_executesql @sql2;
	END
END
-- ========================================== --
-- Command id: 1114
-- Description: پاک‌سازی احتیاطی هر Constraint باقی‌مانده با نام PK_Company
-- ========================================== --
IF EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = 'PK_Company')
BEGIN
	DECLARE @tbl SYSNAME;
	SELECT @tbl = OBJECT_SCHEMA_NAME(parent_object_id) + '.' + OBJECT_NAME(parent_object_id)
	FROM sys.key_constraints
	WHERE name = 'PK_Company';

	DECLARE @dropSql NVARCHAR(1000) = N'ALTER TABLE ' + @tbl + N' DROP CONSTRAINT PK_Company;';
	EXEC sp_executesql @dropSql;
END
-- ========================================== --
-- Command id: 1115
-- Description: ساخت جدول جدید Company (ادغام‌شده حسابداری + حقوق و دستمزد)
-- ========================================== --
IF OBJECT_ID('dbo.Company', 'U') IS NULL
BEGIN
	CREATE TABLE [dbo].[Company] (
		[id]	INT IDENTITY(1,1) NOT NULL,
		[CompanyName]	NVARCHAR(MAX) NOT NULL,
		[RealPerson]	TINYINT NOT NULL,
		[CompanyType]	NVARCHAR(MAX) NULL,
		[AgentFullName]	NVARCHAR(MAX) NULL,
		[idNumber]	NVARCHAR(MAX) NULL,
		[EconomicalNumber]	NVARCHAR(MAX) NULL,
		[Ostan]	NVARCHAR(MAX) NULL,
		[City]	NVARCHAR(MAX) NULL,
		[TaxId]	NVARCHAR(MAX) NULL,
		[TaxCaseNum]	NVARCHAR(MAX) NULL,
		[TaxUnitNum]	NVARCHAR(MAX) NULL,
		[TaxOfficNam]	NVARCHAR(MAX) NULL,
		[TaxBrnchNam]	NVARCHAR(MAX) NULL,
		[TaxBrnchNum]	NVARCHAR(MAX) NULL,
		[InsurWorkNam]	NVARCHAR(MAX) NULL,
		[InsurBrnchNam]	NVARCHAR(MAX) NULL,
		[InsurWorkNum]	NVARCHAR(MAX) NULL,
		[InsurBrnchCode]	NVARCHAR(MAX) NULL,
		[InsurContractRow]	NVARCHAR(MAX) NULL,
		[InsurRate]	INT NULL,
		[HardshipInsurRate]	INT NULL,
		[PkeyAddress]	NVARCHAR(MAX) NULL,
		[Address]	NVARCHAR(MAX) NULL,
		[PostalCode]	NVARCHAR(MAX) NULL,
		[TellNumber]	NVARCHAR(MAX) NULL,
		[FaxNumber]	NVARCHAR(MAX) NULL,
		[Logo]	NVARCHAR(MAX) NULL,
		[FirstInvoiceNumber]	INT NULL,
		[WebSite]	NVARCHAR(MAX) NULL,
		CONSTRAINT [PK_Company] PRIMARY KEY CLUSTERED ([id])
	);
END
-- ========================================== --
-- Command id: 1116
-- Description: فعال‌سازی IDENTITY_INSERT برای انتقال id های اصلی
-- ========================================== --
IF OBJECT_ID('dbo.Company_Old', 'U') IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Company)
BEGIN
	SET IDENTITY_INSERT dbo.Company ON;
	INSERT INTO dbo.Company (
		[id], [CompanyName], [RealPerson], [idNumber], [EconomicalNumber],
		[Ostan], [City], [TaxId], [PkeyAddress], [Address], [PostalCode],
		[TellNumber], [FaxNumber], [Logo], [FirstInvoiceNumber], [WebSite]
	)
	SELECT
		[id], [CompanyName], [RealPerson], [idNumber], [EconomicalNumber],
		[Ostan], [City], [TaxId], [PkeyAddress], [Address], [PostalCode],
		[TellNumber], [FaxNumber], [Logo], [FirstInvoiceNumber], [WebSite]
	FROM dbo.Company_Old;
	SET IDENTITY_INSERT dbo.Company OFF;
END
-- ========================================== --
-- Command id: 1117
-- Description: حذف نهایی جدول قدیمی Company_Old
-- ========================================== --
IF OBJECT_ID('dbo.Company_Old', 'U') IS NOT NULL
BEGIN
	DROP TABLE dbo.Company_Old;
END
-- ========================================== --
-- Command id: 1118
-- Description: ساخت جدول EmployerBank با ارتباط به LF
-- ========================================== --
CREATE TABLE [EmployerBank] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[BankTypeid]	TINYINT NULL,
	[AccountNumber]	NVARCHAR(MAX) NOT NULL,
	[ShebaNumber]	NVARCHAR(MAX) NULL,
	[IsActive]	BIT NOT NULL,
	[LFid]	INT NULL,
	CONSTRAINT [PK_EmployerBank] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_EmployerBank_LF] FOREIGN KEY([LFid]) REFERENCES [LF]([id])
);

-- ========================================== --
-- Command id: 1120
-- Description: ساخت جدول InsuranceJob
-- ========================================== --
CREATE TABLE [InsuranceJob] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Code]	NVARCHAR(MAX) NOT NULL,
	[Title]	NVARCHAR(MAX) NOT NULL,
	[IsActive]	BIT NOT NULL DEFAULT 1,
	CONSTRAINT [PK_InsurJob] PRIMARY KEY CLUSTERED ([id])
);

-- ========================================== --
-- Command id: 1122
-- Description: ساخت جدول TaxTable
-- ========================================== --
CREATE TABLE [TaxTable] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Year]	INT NOT NULL,
	[TaxableAmount0Percent]	BIGINT NOT NULL,
	[TaxableAmount10Percent]	BIGINT NOT NULL,
	[TaxableAmount15Percent]	BIGINT NOT NULL,
	[TaxableAmount20Percent]	BIGINT NOT NULL,
	[TaxableAmount25Percent]	BIGINT NULL,
	CONSTRAINT [PK_TaxTable] PRIMARY KEY CLUSTERED ([id])
);

-- ========================================== --
-- Command id: 1123
-- Description: ساخت جدول SalaryItemExecution
-- ========================================== --
CREATE TABLE [SalaryItemExecution] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Description]	NVARCHAR(MAX) NULL,
	[ExecutionDate]	INT NOT NULL,
	CONSTRAINT [PK_SalaryItemExecution] PRIMARY KEY CLUSTERED ([id])
);

-- ========================================== --
-- Command id: 1124
-- Description: ساخت جدول Personnel با ارتباط به LF
-- ========================================== --
CREATE TABLE [Personnel] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Code]	NVARCHAR(MAX) NOT NULL,
	[ClockCode]	NVARCHAR(MAX) NULL,
	[LastName]	NVARCHAR(MAX) NOT NULL,
	[FirstName]	NVARCHAR(MAX) NOT NULL,
	[FathrName]	NVARCHAR(MAX) NULL,
	[MelliNumber]	NVARCHAR(MAX) NULL,
	[Gender]	TINYINT NOT NULL,
	[Nationality]	TINYINT NOT NULL,
	[BirthCertificateNumber]	NVARCHAR(MAX) NULL,
	[BrthDate]	INT NULL,
	[BrthPlace]	NVARCHAR(MAX) NULL,
	[RegstPlace]	NVARCHAR(MAX) NULL,
	[BirthCertificateIssueDate]	INT NULL,
	[CitizenshipCountryCode]	NVARCHAR(MAX) NULL,
	[ResidenceCountryCode]	NVARCHAR(MAX) NULL,
	[EmploymentStartDate]	INT NULL,
	[EmploymentEndDate]	INT NULL,
	[RetirementDate]	INT NULL,
	[IsActive]	BIT NOT NULL,
	[PayIsActive]	BIT NOT NULL,
	[LFid]	INT NULL,
	CONSTRAINT [PK_Personnel] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_Personnel_LF] FOREIGN KEY([LFid]) REFERENCES [LF]([id])
);

-- ========================================== --
-- Command id: 1125
-- Description: ساخت جدول PersonnelBank
-- ========================================== --
CREATE TABLE [PersonnelBank] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Personnelid]	INT NOT NULL,
	[BankTypeid]	TINYINT NOT NULL,
	[AccountNumber]	NVARCHAR(MAX) NOT NULL,
	[ShebaNumber]	NVARCHAR(MAX) NULL,
	[Notes]	NVARCHAR(MAX) NULL,
	[IsActive]	BIT NOT NULL,
	CONSTRAINT [PK_PersonnelBank] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_PersonnelBank_Personnel] FOREIGN KEY([Personnelid]) REFERENCES [Personnel]([id]) ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 1126
-- Description: ساخت جدول Contract
-- ========================================== --
CREATE TABLE [Contract] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Personnelid]	INT NOT NULL,
	[ContractType]	TINYINT NOT NULL,
	[Bankid]	INT NULL,
	[ContractNumber]	INT NOT NULL,
	[CreationDate]	INT NOT NULL,
	[StartDate]	INT NOT NULL,
	[EndDate]	INT NULL,
	[TerminationDate]	INT NULL,
	[DailyBaseAmount]	BIGINT NOT NULL,
	[DailySanavatBaseAmount]	BIGINT NOT NULL,
	[MobileNumber]	NVARCHAR(MAX) NULL,
	[Address]	NVARCHAR(MAX) NULL,
	[PostalCode]	NVARCHAR(MAX) NULL,
	[InnerJobTitle]	NVARCHAR(MAX) NULL,
	[WorkPlace]	NVARCHAR(MAX) NULL,
	[Notes]	NVARCHAR(MAX) NULL,
	[InsurType]	TINYINT NULL,
	[InsurName]	NVARCHAR(MAX) NULL,
	[InsurNumber]	NVARCHAR(MAX) NULL,
	[InsuranceJobid]	INT NULL,
	[FreeTaxType]	TINYINT NULL,
	[JobCategory]	TINYINT NULL,
	[WorkPlaceStatus]	TINYINT NULL,
	[LastEducation]	TINYINT NULL,
	[BudgetLawException1403]	TINYINT NULL,
	[EmploymentType]	TINYINT NULL,
	[IsMarried]	BIT NOT NULL,
	[NumberOfChildren]	INT NOT NULL,
	[BaseChildAmount]	BIGINT NOT NULL,
	[BaseHousAmount]	BIGINT NOT NULL,
	[BaseMarryAmount]	BIGINT NOT NULL,
	[BaseFoodAmount]	BIGINT NOT NULL,
	[BaseWorkerBenAmount]	BIGINT NOT NULL,
	[IsTaxable]	BIT NOT NULL DEFAULT 0,
	[IsInsurable]	BIT NOT NULL DEFAULT 0,
	[IsBimeShodeAsli]	BIT NOT NULL DEFAULT 0,
	[IsUnempInsured]	BIT NOT NULL DEFAULT 0,
	[IsHardshipInsurable]	BIT NOT NULL DEFAULT 0,
	CONSTRAINT [PK_Contract] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_Contract_Personnel] FOREIGN KEY([Personnelid]) REFERENCES [Personnel]([id]) ON DELETE CASCADE,
	CONSTRAINT [FK_Contract_PersonnelBank] FOREIGN KEY([Bankid]) REFERENCES [PersonnelBank]([id]),
	CONSTRAINT [FK_Contract_InsuranceJob] FOREIGN KEY([InsuranceJobid]) REFERENCES [InsuranceJob]([id])
);

-- ========================================== --
-- Command id: 1127
-- Description: ساخت جدول Loan
-- ========================================== --
CREATE TABLE [Loan] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Personnelid]	INT NOT NULL,
	[Title]	NVARCHAR(MAX) NOT NULL,
	[LoanNumber]	INT NOT NULL,
	[InitialLoanBalanceAmount]	INT NOT NULL,
	[InstallmentAmount]	INT NOT NULL,
	[StartPeriod]	INT NOT NULL,
	[TotslInstallmentPaidAmount]	INT NOT NULL,
	[Description]	NVARCHAR(MAX) NULL,
	[AdjustmentStartPeriod]	INT NULL,
	[AdjustmentEndPeriod]	INT NULL,
	[AdjustmentAmount]	INT NULL,
	[FinalRepaymentPeriod]	INT NULL,
	CONSTRAINT [PK_Loan] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_Loan_Personnel] FOREIGN KEY([Personnelid]) REFERENCES [Personnel]([id])
);

-- ========================================== --
-- Command id: 1128
-- Description: ساخت جدول Period
-- ========================================== --
CREATE TABLE [Period] (
	[id]	INT NOT NULL,
	[ManagementMessageTitle]	NVARCHAR(MAX) NULL,
	[ManagementMessage]	NVARCHAR(MAX) NULL,
	[IsFinalized]	BIT NOT NULL,
	CONSTRAINT [PK_Period] PRIMARY KEY CLUSTERED ([id])
);

-- ========================================== --
-- Command id: 1129
-- Description: ساخت جدول LoanRepayment
-- ========================================== --
CREATE TABLE [LoanRepayment] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Loanid]	INT NOT NULL,
	[Periodid]	INT NOT NULL,
	[Personnelid]	INT NOT NULL,
	[InstallmentAmount]	INT NOT NULL,
	CONSTRAINT [PK_LoanRepayment] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_LoanRepayments_Loan] FOREIGN KEY([Loanid]) REFERENCES [Loan]([id]),
	CONSTRAINT [FK_LoanRepayment_Period] FOREIGN KEY([Periodid]) REFERENCES [Period]([id]) ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 113
-- Description: ساخت جدول Payment
-- ========================================== --
CREATE TABLE [Payment] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Periodid]	INT NOT NULL,
	[PaymentType]	TINYINT NOT NULL,
	[PaymentDate]	INT NULL,
	[PaymentNumber]	TINYINT NOT NULL,
	[EmployerBankid]	INT NOT NULL,
	[Description]	NVARCHAR(MAX) NULL,
	[IsFinalized]	BIT NOT NULL,
	CONSTRAINT [PK_Payment] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_Payment_EmployerBank] FOREIGN KEY([EmployerBankid]) REFERENCES [EmployerBank]([id]),
	CONSTRAINT [FK_Payment_Period] FOREIGN KEY([Periodid]) REFERENCES [Period]([id]) ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 1131
-- Description: ساخت جدول PaymentDe
-- ========================================== --
CREATE TABLE [PaymentDe] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Paymentid]	INT NOT NULL,
	[Personnelid]	INT NULL,
	[PersonnelBankid]	INT NULL,
	[Amount]	BIGINT NULL,
	CONSTRAINT [PK_PaymentDe] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_PaymentDe_Payment] FOREIGN KEY([Paymentid]) REFERENCES [Payment]([id]) ON DELETE CASCADE,
	CONSTRAINT [FK_PaymentDe_Personnel] FOREIGN KEY([Personnelid]) REFERENCES [Personnel]([id]),
	CONSTRAINT [FK_PaymentDe_PersonnelBank] FOREIGN KEY([PersonnelBankid]) REFERENCES [PersonnelBank]([id])
);

-- ========================================== --
-- Command id: 1132
-- Description: ساخت جدول SalaryItem
-- ========================================== --
CREATE TABLE [SalaryItem] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[SalaryItemExecutionid]	INT NOT NULL,
	[Itemid]	TINYINT NOT NULL,
	[RowNumber]	SMALLINT NOT NULL,
	[AllowSetIsActive]	BIT NOT NULL,
	[IsActive]	BIT NOT NULL,
	[IsAdding]	BIT NOT NULL,
	[AllowSetTitle]	BIT NOT NULL,
	[Title]	NVARCHAR(MAX) NOT NULL,
	[AllowSetFixed]	BIT NOT NULL,
	[IsFixed]	BIT NOT NULL,
	[AllowSetIsOnLegalList]	BIT NOT NULL,
	[IsOnLegalList]	BIT NOT NULL,
	[AllowSetIsTaxableOrIsInsurable]	BIT NOT NULL,
	[IsInsurable]	BIT NOT NULL,
	[TaxItemTypeid]	TINYINT NULL,
	[IsTenPercentTaxable]	BIT NULL,
	[AllowSetRedemptionable]	BIT NOT NULL,
	[IsLeavable]	BIT NOT NULL,
	[IsEidiable]	BIT NOT NULL,
	[IsSanavatable]	BIT NOT NULL,
	[AllowSetIsCopyOfPrevious]	BIT NOT NULL,
	[IsCopyOfPrevious]	BIT NOT NULL,
	[Description]	NVARCHAR(MAX) NULL,
	CONSTRAINT [PK_SalaryItem] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_SalaryItem_SalaryItemExecution] FOREIGN KEY([SalaryItemExecutionid]) REFERENCES [SalaryItemExecution]([id]) ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 1133
-- Description: ساخت جدول WorkPeriodic
-- ========================================== --
CREATE TABLE [WorkPeriodic] (
	[id]	INT IDENTITY(1,1) NOT NULL,
	[Periodid]	INT NOT NULL,
	[Personnelid]	INT NULL,
	[Contractid]	INT NOT NULL,
	[IsTaxable]	BIT NOT NULL,
	[IsInsurable]	BIT NOT NULL,
	[IsBimeShodeAsli]	BIT NOT NULL,
	[IsUnempInsured]	BIT NOT NULL,
	[IsHardshipInsurable]	BIT NOT NULL,
	[DailyBaseAmount]	BIGINT NOT NULL,
	[DailySanavatBaseAmount]	BIGINT NOT NULL,
	[BaseHousAmount]	BIGINT NOT NULL,
	[BaseMarryAmount]	BIGINT NOT NULL,
	[BaseWorkerBenAmount]	BIGINT NOT NULL,
	[BaseFoodAmount]	BIGINT NOT NULL,
	[BaseChildAmount]	BIGINT NOT NULL,
	[CostCenterid]	INT NOT NULL,
	[WorkDays]	INT NOT NULL,
	[ShiftDays]	INT NOT NULL,
	[ShiftPercentage]	INT NOT NULL,
	[NightWorkByMinutes]	INT NOT NULL,
	[OvertimeByMinutes]	INT NOT NULL,
	[FridayOvertimeByMinutes]	INT NOT NULL,
	[MissionDays]	DECIMAL(18,2) NOT NULL,
	[DeductedByMinutes]	INT NOT NULL,
	[LeaveDays]	INT NOT NULL,
	[LeaveByMinutes]	INT NOT NULL,
	[LeaveBalanceByMinutes]	INT NOT NULL,
	[AdjLeaveByMinutes]	INT NOT NULL,
	[SickLeaveDays]	INT NOT NULL,
	[RedemptionLeaveDailyBaseAmount]	BIGINT NOT NULL,
	[RedemptionEidiDailyBaseAmount]	BIGINT NOT NULL,
	[RedemptionSanavatDailyBaseAmount]	BIGINT NOT NULL,
	[MissionAmount]	BIGINT NOT NULL,
	[MissionExpenseAmount]	BIGINT NOT NULL,
	[BaseCustomAmount1]	BIGINT NOT NULL,
	[BaseCustomAmount2]	BIGINT NOT NULL,
	[BaseCustomAmount3]	BIGINT NOT NULL,
	[BaseCustomAmount4]	BIGINT NOT NULL,
	[BaseCustomAmount5]	BIGINT NOT NULL,
	[BaseCustomAmount6]	BIGINT NOT NULL,
	[BaseCustomAmount7]	BIGINT NOT NULL,
	[BaseCustomAmount8]	BIGINT NOT NULL,
	[BaseCustomAmount9]	BIGINT NOT NULL,
	[BaseCustomAmount10]	BIGINT NOT NULL,
	[OtherAmount]	BIGINT NOT NULL,
	[NonCashBenAmount]	BIGINT NOT NULL,
	[SalaryAdvanceAmount]	BIGINT NOT NULL,
	[ExtraInsAmount]	BIGINT NOT NULL,
	[CustomAdjAmount1]	BIGINT NOT NULL,
	[CustomAdjAmount2]	BIGINT NOT NULL,
	[CustomAdjAmount3]	BIGINT NOT NULL,
	[CustomAdjAmount4]	BIGINT NOT NULL,
	[CustomAdjAmount5]	BIGINT NOT NULL,
	[CustomAdjAmount6]	BIGINT NOT NULL,
	[CustomAdjAmount7]	BIGINT NOT NULL,
	[CustomAdjAmount8]	BIGINT NOT NULL,
	[LoanInstallAmount]	BIGINT NOT NULL,
	[TaxAmount]	BIGINT NOT NULL,
	[CustomTaxAmount]	BIGINT NULL,
	[RedemptionTaxAmount]	BIGINT NOT NULL,
	[PreviousDebtAmount]	BIGINT NOT NULL,
	[OtherAdjAmount]	BIGINT NOT NULL,
	[InsurableSalaryAndBenefitsAmount]	BIGINT NOT NULL,
	[TaxableSalaryAmount]	BIGINT NOT NULL,
	[SanavatBalanceByDays]	DECIMAL(18,2) NOT NULL,
	[AdjSanavatByDays]	DECIMAL(18,2) NOT NULL,
	[RedemptionSanavatByDays]	DECIMAL(18,2) NOT NULL,
	[EidiBalanceByDays]	DECIMAL(18,2) NOT NULL,
	[RedemptionEidiByDays]	DECIMAL(18,2) NOT NULL,
	[RedemptionCustomAmount1]	BIGINT NOT NULL,
	[RedemptionCustomAmount2]	BIGINT NOT NULL,
	[RedemptionCustomAdjAmount1]	BIGINT NOT NULL,
	[RedemptionLeaveByMinutes]	INT NOT NULL,
	[AdjEidiByDays]	DECIMAL(18,2) NOT NULL,
	[CustomAmount1]	BIGINT NOT NULL DEFAULT 0,
	[CustomAmount2]	BIGINT NOT NULL DEFAULT 0,
	[CustomAmount3]	BIGINT NOT NULL DEFAULT 0,
	[CustomAmount4]	BIGINT NOT NULL DEFAULT 0,
	[CustomAmount5]	BIGINT NOT NULL DEFAULT 0,
	[CustomAmount6]	BIGINT NOT NULL DEFAULT 0,
	[CustomAmount7]	BIGINT NOT NULL DEFAULT 0,
	[CustomAmount8]	BIGINT NOT NULL DEFAULT 0,
	[CustomAmount9]	BIGINT NOT NULL DEFAULT 0,
	[CustomAmount10]	BIGINT NOT NULL DEFAULT 0,
	CONSTRAINT [PK_WorkPeriodic] PRIMARY KEY CLUSTERED ([id]),
	CONSTRAINT [FK_WorkPeriodic_Period] FOREIGN KEY([Periodid]) REFERENCES [Period]([id]) ON DELETE CASCADE,
	CONSTRAINT [FK_WorkPeriodic_CostCenter] FOREIGN KEY([CostCenterid]) REFERENCES [CostCenter]([id]),
	CONSTRAINT [FK_WorkPeriodic_Contract] FOREIGN KEY([Contractid]) REFERENCES [Contract]([id]),
	CONSTRAINT [FK_WorkPeriodic_Personnel] FOREIGN KEY([Personnelid]) REFERENCES [Personnel]([id])
);
-- ========================================== --
-- Command id: 1134
-- Description: ایجاد اولین رکورد Period
-- ========================================== --
IF NOT EXISTS (SELECT 1 FROM dbo.Period WHERE [id] = 14050131)
BEGIN
	INSERT INTO dbo.Period ([id], [ManagementMessageTitle], [ManagementMessage], [IsFinalized])
	VALUES (14050131, NULL, NULL, 0);
END

-- ========================================== --
-- Command id: 1135
-- Description: ایجاد اولین رکورد SalaryItemExecution
-- ========================================== --
IF NOT EXISTS (SELECT 1 FROM dbo.SalaryItemExecution WHERE [id] = 1)
BEGIN
	SET IDENTITY_INSERT dbo.SalaryItemExecution ON;

	INSERT INTO dbo.SalaryItemExecution ([id], [Description], [ExecutionDate])
	VALUES (1, N'تنظیمات اولیه', 14050131);

	SET IDENTITY_INSERT dbo.SalaryItemExecution OFF;
END

-- ========================================== --
-- Command id: 1136
-- Description: ایجاد اولین رکوردهای SalaryItem
-- ========================================== --
IF NOT EXISTS (SELECT 1 FROM dbo.SalaryItem WHERE [id] = 1)
BEGIN
	SET IDENTITY_INSERT dbo.SalaryItem ON;

	INSERT INTO dbo.SalaryItem
		([id],[SalaryItemExecutionid],[Itemid],[RowNumber],[AllowSetIsActive],[IsActive],[IsAdding],[AllowSetTitle],[Title],[AllowSetFixed],[IsFixed],[AllowSetIsOnLegalList],[IsOnLegalList],[AllowSetIsTaxableOrIsInsurable],[IsInsurable],[TaxItemTypeid],[IsTenPercentTaxable],[AllowSetRedemptionable],[IsLeavable],[IsEidiable],[IsSanavatable],[AllowSetIsCopyOfPrevious],[IsCopyOfPrevious],[Description])
	VALUES
	(1,1,0,0,0,1,1,0,N'حقوق پایه',0,0,0,1,0,1,7,0,1,1,1,1,0,0,N'مبلغ آن در قرارداد پرسنلی بصورت روزانه تعیین می شود.'),
	(2,1,1,1,0,1,1,0,N'پایه سنواتی',0,0,0,1,0,1,7,0,1,1,1,1,0,0,N'مبلغ آن در قرارداد پرسنلی بصورت روزانه تعیین می شود.'),
	(3,1,2,2,1,1,1,0,N'نوبت#کاری',0,0,1,1,0,1,7,1,0,0,0,0,0,0,N'مبلغ نوبت‌کاری >>> (حقوق پایه روزانه + پایه سنواتی) × تعداد روزهای نوبت‌کاری × درصد نوبت‌کاری'),
	(4,1,3,3,1,0,1,0,N'شب#کاری',0,0,1,0,0,1,7,0,0,0,0,0,0,0,N'مبلغ شب‌کاری >>> (حقوق پایه روزانه + پایه سنواتی) ÷ 440 × مجموع دقایق شب کاری × 1.35'),
	(5,1,4,4,1,1,1,0,N'حق#ماموریت',0,0,1,1,0,0,19,1,0,0,0,0,0,0,N'مبلغ ماموریت >>> (حقوق پایه روزانه + پایه سنواتی) × تعداد روزهای ماموریت'),
	(6,1,5,5,1,0,1,0,N'هزینه#سفر',0,1,1,1,0,0,18,1,0,0,0,0,0,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(7,1,6,6,1,1,1,0,N'اضافه کار#عادی',0,0,1,1,0,1,17,1,0,0,0,0,0,0,N'مبلغ اضافه کار عادی >>> (حقوق پایه روزانه + پایه سنواتی) ÷ 440 × مجموع دقایق اضافه کار عادی × 1.4'),
	(8,1,7,7,1,1,1,0,N'اضافه کار#جمعه',0,0,1,1,0,1,17,1,0,0,0,0,0,0,N'مبلغ اضافه کار جمعه >>> (((حقوق پایه روزانه + پایه سنواتی) ÷ 440 ) × مجموع دقایق اضافه کار عادی) × ( 1 + (0.4 + 0.4 ))'),
	(9,1,8,8,0,1,1,0,N'بن#کارگری',0,0,1,1,0,1,38,1,1,0,0,0,0,0,N'مبلغ بن کارگری>>> ( مبلغ بن کارگری در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
	(10,1,9,9,0,1,1,0,N'حق#مسکن',0,0,1,1,0,1,38,1,1,0,0,0,0,0,N'مبلغ حق مسکن>>> ( مبلغ  حق مسکن در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
	(11,1,10,10,0,1,1,0,N'حق#تاهل',0,0,1,1,0,1,38,1,1,0,0,0,0,0,N'مبلغ حق تاهل>>> ( مبلغ  حق تاهل در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
	(12,1,11,11,0,1,1,0,N'حق#اولاد',0,0,1,1,0,0,38,1,1,0,0,0,0,0,N'مبلغ حق اولاد>>> ( مبلغ  حق اولاد در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
	(13,1,12,12,0,1,1,0,N'حق#خواروبار',0,0,1,1,0,1,38,1,1,0,0,0,0,0,N'مبلغ حق خواروبار>>> ( مبلغ  حق خواروبار در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
	(14,1,13,13,1,0,1,1,N'حق 1',1,0,1,0,1,0,38,1,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(15,1,14,14,1,0,1,1,N'حق 2',1,0,1,0,1,0,38,0,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(16,1,15,15,1,0,1,1,N'حق 3',1,0,1,0,1,0,38,1,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(17,1,16,16,1,0,1,1,N'حق 4',1,0,1,0,1,0,38,1,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(18,1,17,17,1,0,1,1,N'حق 5',1,0,1,0,1,0,38,1,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(19,1,18,18,1,0,1,1,N'حق 6',1,0,1,0,1,0,38,1,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(20,1,19,19,1,0,1,1,N'حق 7',1,0,1,0,1,0,38,1,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(21,1,20,20,1,0,1,1,N'حق 8',1,0,1,0,1,0,38,1,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(22,1,21,21,1,0,1,1,N'حق 9',1,0,1,0,1,0,38,1,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(23,1,22,22,1,0,1,1,N'حق10',1,0,1,0,1,0,38,1,1,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(24,1,23,23,1,1,1,0,N'بن غیر نقدی',0,1,1,1,0,0,31,0,0,0,0,0,0,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(25,1,24,24,1,1,1,0,N'سایر اضافات',0,1,1,1,1,0,38,0,0,0,0,0,0,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(26,1,25,25,0,1,0,0,N'مالیات#حقوق',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,N'مبلغ آن در کارکرد ماهیانه با توجه به جدول مالیاتی  و مالیات پذیری آیتمهای حقوقی ، توسط برنامه محاسبه می شود.'),
	(27,1,26,26,0,1,0,0,N'بیمه#سهم کارگر',0,1,0,0,0,1,33,0,0,0,0,0,0,0,N'مبلغ آن در کارکرد ماهیانه با توجه به بیمه پذیری آیتمهای حقوقی ، توسط برنامه محاسبه می شود.'),
	(28,1,27,27,1,1,0,0,N'قسط وام',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,N'مبلغ آن در کارکرد ماهیانه با توجه به جدول وام های پرسنلی ،توسط برنامه درج می گردد.'),
	(29,1,28,28,1,1,0,0,N'کسر کار',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,N'مبلغ کسرکار >>> (حقوق پایه روزانه + پایه سنواتی) ÷ 480 × مجموع دقایق کسرکار'),
	(30,1,29,29,1,1,0,0,N'مساعده',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(31,1,30,30,1,0,0,0,N'بیمه#تکمیلی',0,1,0,0,0,1,34,0,0,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(32,1,31,31,1,0,0,1,N'کسور 1',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(33,1,32,32,1,0,0,1,N'کسور 2',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(34,1,33,33,1,0,0,1,N'کسور 3',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(35,1,34,34,1,0,0,1,N'کسور 4',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(36,1,35,35,1,0,0,1,N'کسور 5',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(37,1,36,36,1,0,0,1,N'کسور 6',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(38,1,37,37,1,0,0,1,N'کسور 7',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(39,1,38,38,1,0,0,1,N'کسور 8',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(40,1,39,39,1,1,0,0,N'سایر کسور',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,N'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
	(41,1,40,40,0,1,1,0,N'عیدی',0,0,1,1,0,0,23,0,0,0,0,0,0,0,N'مقدار عیدی >>> (60 ÷ تعداد روزهای سال ) × (تعداد روزهای کارکرد + تعداد روزهای مرخصی استعلاجی)'),
	(42,1,41,41,0,1,1,0,N'بازخرید مرخصی',0,0,1,1,0,0,28,0,0,0,0,0,0,0,N'مقدار مانده مرخصی بر حسب دقیقه >>> (1200 ÷ تعداد روزهای ماه  ) × (تعداد روزهای کارکرد + تعداد روزهای مرخصی استعلاجی) + مانده مرخصی از قبل - مرخصی مصرفی در ماه جاری'),
	(43,1,42,42,0,1,1,0,N'بازخرید سنوات',0,0,1,1,0,0,27,0,0,0,0,0,0,0,N'مقدار سنوات >>> (30 ÷ تعداد روزهای سال) × (تعداد روزهای کارکرد + تعداد روزهای مرخصی استعلاجی) + مانده سنوات از قبل'),
	(44,1,43,43,1,1,1,1,N'سایر#اضافات#تسویه1',0,0,1,1,0,0,29,0,0,0,0,0,0,0,N'مقدار این ستون در فیش تسویه و بازخرید نمایش داده می شود.'),
	(45,1,44,44,1,1,1,1,N'سایر#اضافات#تسویه2',0,0,1,1,0,0,29,0,0,0,0,0,0,0,N'مقدار این ستون در فیش تسویه و بازخرید نمایش داده می شود.'),
	(46,1,45,45,1,0,0,1,N'سایر#کسورات#تسویه1',0,0,1,0,0,0,NULL,0,0,0,0,0,0,0,N'مقدار این ستون در فیش تسویه و بازخرید نمایش داده می شود.');

	SET IDENTITY_INSERT dbo.SalaryItem OFF;
END

-- ========================================== --
-- Command id: 1137
-- Description: ایجاد اولین رکورد TaxTable
-- ========================================== --
IF NOT EXISTS (SELECT 1 FROM dbo.TaxTable WHERE [id] = 1)
BEGIN
	SET IDENTITY_INSERT dbo.TaxTable ON;

	INSERT INTO dbo.TaxTable ([id], [Year], [TaxableAmount0Percent], [TaxableAmount10Percent], [TaxableAmount15Percent], [TaxableAmount20Percent], [TaxableAmount25Percent])
	VALUES (1, 1405, 4800000000, 9600000000, 12000000000, 14400000000, 16800000000);

	SET IDENTITY_INSERT dbo.TaxTable OFF;
END