﻿-- ========================================== --
-- Command id: 1046
-- Description: Insert only non-null, non-empty values
-- ========================================== --
INSERT INTO [dbo].[UserSetting] ([Userid], [Settingid], [KeyValue], [Value])
SELECT 
    [Userid],
    'DataGridColumnVisibility' AS [Settingid],
    [DataGridid] AS [KeyValue],
    [ColumnIndexArray] AS [Value]
FROM [dbo].[UserCustomColumn]
WHERE [Userid] IS NOT NULL 
    AND [DataGridid] IS NOT NULL 
    AND [DataGridid] != ''
    AND [ColumnIndexArray] IS NOT NULL 
    AND [ColumnIndexArray] != '';

INSERT INTO [dbo].[UserSetting] ([Userid], [Settingid], [KeyValue], [Value])
SELECT 
    [Userid],
    'SelectedExcelColumns' AS [Settingid],
    [Excelid] AS [KeyValue],
    [SelectedColumns] AS [Value]
FROM [dbo].[UserCustomExcelColumn]
WHERE [Userid] IS NOT NULL 
    AND [Excelid] IS NOT NULL 
    AND [Excelid] != ''
    AND [SelectedColumns] IS NOT NULL 
    AND [SelectedColumns] != '';

-- ========================================== --
-- Command id: 1047
-- Description: Drop tables
-- ========================================== --
-- حذف جدول
DROP TABLE [dbo].[UserCustomColumn];
DROP TABLE [dbo].[UserCustomExcelColumn];