﻿-- ========================================== --
-- Command id: 1077
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'CRMActivity' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE [dbo].[CRMActivity]
    (
        [id]                    INT IDENTITY(1,1) NOT NULL,
        [ActivityNumber]        INT NOT NULL,
        [Customerid]            INT NOT NULL,
        [ActivityTypeid]        INT NOT NULL,
        [Subject]               NVARCHAR(MAX) NOT NULL,
        [Description]           NVARCHAR(MAX) NULL,
        [ActivityDate]          INT NOT NULL,
        [ActivityTime]          VARCHAR(8) NULL,
        [FollowUpDate]          INT NULL,
        [FollowUpDescription]   NVARCHAR(MAX) NULL,
        [Statusid]              INT NOT NULL,
        [ActivityResultid]      INT NULL,
        [Priorityid]            INT NULL,
        [Userid]                INT NOT NULL,
        [CreatedDate]           INT NOT NULL,      
        [IsDeleted]             BIT NOT NULL
            CONSTRAINT [DF_CRMActivity_IsDeleted] DEFAULT ((0)),
        CONSTRAINT [PK_CRMActivity]
            PRIMARY KEY NONCLUSTERED ([id] ASC)
    )
    ON [PRIMARY]
    TEXTIMAGE_ON [PRIMARY];

    ALTER TABLE [dbo].[CRMActivity] WITH CHECK
    ADD CONSTRAINT [FK_CRMActivity_Customer]
    FOREIGN KEY ([Customerid])
    REFERENCES [dbo].[Customer]([id]);

    ALTER TABLE [dbo].[CRMActivity]
    CHECK CONSTRAINT [FK_CRMActivity_Customer];

    ALTER TABLE [dbo].[CRMActivity] WITH CHECK
    ADD CONSTRAINT [FK_CRMActivity_ActivityType]
    FOREIGN KEY ([ActivityTypeid])
    REFERENCES [dbo].[BatchDe]([id]);

    ALTER TABLE [dbo].[CRMActivity]
    CHECK CONSTRAINT [FK_CRMActivity_ActivityType];

    ALTER TABLE [dbo].[CRMActivity] WITH CHECK
    ADD CONSTRAINT [FK_CRMActivity_Status]
    FOREIGN KEY ([Statusid])
    REFERENCES [dbo].[BatchDe]([id]);

    ALTER TABLE [dbo].[CRMActivity]
    CHECK CONSTRAINT [FK_CRMActivity_Status];

    ALTER TABLE [dbo].[CRMActivity] WITH CHECK
    ADD CONSTRAINT [FK_CRMActivity_Result]
    FOREIGN KEY ([ActivityResultid])
    REFERENCES [dbo].[BatchDe]([id]);

    ALTER TABLE [dbo].[CRMActivity]
    CHECK CONSTRAINT [FK_CRMActivity_Result];

    ALTER TABLE [dbo].[CRMActivity] WITH CHECK
    ADD CONSTRAINT [FK_CRMActivity_Priority]
    FOREIGN KEY ([Priorityid])
    REFERENCES [dbo].[BatchDe]([id]);

    ALTER TABLE [dbo].[CRMActivity]
    CHECK CONSTRAINT [FK_CRMActivity_Priority];

    ALTER TABLE [dbo].[CRMActivity] WITH CHECK
    ADD CONSTRAINT [FK_CRMActivity_User]
    FOREIGN KEY ([Userid])
    REFERENCES [dbo].[User]([id]);

    ALTER TABLE [dbo].[CRMActivity]
    CHECK CONSTRAINT [FK_CRMActivity_User];

    CREATE UNIQUE CLUSTERED INDEX [IX_CRMActivity_ActivityNumber]
    ON [dbo].[CRMActivity] ([ActivityNumber] DESC, [ActivityDate] DESC);
END
-- ========================================== --
-- Command id: 1078
-- Description: حذف ارتباط FK جداول UserOperationPermission و UserOperationPermissionToOther با جدول حذف‌شده aOperation
-- ========================================== --
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_UserOperationPermission_aOperation')
    ALTER TABLE [dbo].[UserOperationPermission] DROP CONSTRAINT [FK_UserOperationPermission_aOperation];

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_UserOperationPermissionToOther_aOperation')
    ALTER TABLE [dbo].[UserOperationPermissionToOther] DROP CONSTRAINT [FK_UserOperationPermissionToOther_aOperation];

-- ========================================== --
-- Command id: 1079
-- Description: حذف جداول قدیمی aOperation، aOperationsHeaderDe و aOperationsHeader (جایگزین شده با OperationCatalog در کد)
-- ========================================== --
IF OBJECT_ID('dbo.aOperation', 'U') IS NOT NULL
    DROP TABLE [dbo].[aOperation];

IF OBJECT_ID('dbo.aOperationsHeaderDe', 'U') IS NOT NULL
    DROP TABLE [dbo].[aOperationsHeaderDe];

IF OBJECT_ID('dbo.aOperationsHeader', 'U') IS NOT NULL
    DROP TABLE [dbo].[aOperationsHeader];
	
-- ========================================== --
-- Command id: 1080
-- Description: اضافه نمودن ستون گروه بندی به جدول کالا
-- ========================================== --
ALTER TABLE [dbo].[Kala]
ADD [KalaGroupid] [int] NULL;

ALTER TABLE [dbo].[Kala] WITH CHECK ADD CONSTRAINT [FK_Kala_BatchDe1] FOREIGN KEY([KalaGroupid])
REFERENCES [dbo].[BatchDe] ([id]);

ALTER TABLE [dbo].[Kala] CHECK CONSTRAINT [FK_Kala_BatchDe1];
-- ========================================== --
-- Command id: 1081
-- Description: اضافه نمودن ستون گروه بندی به جدول کالا
-- ========================================== --
ALTER TABLE [dbo].[LFType]
ADD [Purpose] [tinyint] NOT NULL CONSTRAINT DF_LFType_Purpose DEFAULT 0;
-- ========================================== --
-- Command id: 1082
-- Description: 
-- ========================================== --
IF OBJECT_ID('dbo.Bank', 'U') IS NOT NULL
    DROP TABLE dbo.Bank;