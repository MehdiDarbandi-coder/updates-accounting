﻿-- ========================================== --
-- Command id: 1029
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT * FROM aOperation WHERE id = 5087)
BEGIN
    SET IDENTITY_INSERT aOperation ON;
   
    INSERT INTO aOperation (id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, Accounting, Salary, Sales, ARAP, Store, Asset, IsPermissionToOther, IsActive)
    VALUES     
    (5087, N'تعیین اقلام صورت وضعیت مالی', 'BalanceSheetSettings', 1, 8, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1);

    SET IDENTITY_INSERT aOperation OFF;
END

UPDATE aOperation
SET ModelView = 'IncomeStatementSettings'
WHERE ModelView = 'FinancialReportSettings';
-- ========================================== --
-- Command id: 1030
-- Description: 
-- ========================================== --

-- ایجاد هدر تنظیمات
INSERT INTO aOperationsHeader (id, Title)
VALUES (5, N'تنظیمات مدیریتی');

-- ایجاد جزئیات هدر
INSERT INTO aOperationsHeaderDe (id, Headerid, RowNumber, Title)
VALUES (22, 5, 1, N'تنظیمات مدیریتی');

-- به‌روزرسانی عملیات‌ها
UPDATE aOperation
SET OnlyAdmin = 0,
    HederDeid = 22
WHERE ModelView IN (
    'CheckStatusType',
    'AutoIssuanceGournalEntrySetting',
    'IncomeStatementSettings',
    'BalanceSheetSettings',
    'SettingView'
);

-- به‌روزرسانی مجوزهای کاربران
UPDATE UserOperationPermission
SET Userid = (
    SELECT TOP 1 Userid
    FROM UserOperationPermission
    WHERE Operationsid = 38
)
WHERE Operationsid IN (
    SELECT id
    FROM aOperation
    WHERE ModelView IN (
        'CheckStatusType',
        'AutoIssuanceGournalEntrySetting',
        'IncomeStatementSettings',
        'BalanceSheetSettings',
        'SettingView'
    )
);
-- ========================================== --
-- Command id: 1031
-- Description: دستور زیر باید اول و جدا از دستورات بعدی اجرا شود تا خطا ندهد
-- ========================================== --

EXEC sp_rename 'EntryType.IsMerge', 'IsMergeDebitSide', 'COLUMN';
-- ========================================== --
-- Command id: 1032
-- Description: 
-- ========================================== --
ALTER TABLE EntryType ADD IsMergeCreditSide bit;
-- ========================================== --
-- Command id: 1033
-- Description: دستور زیر باید اول و جدا از دستورات بعدی اجرا شود تا خطا ندهد
-- ========================================== --
ALTER TABLE EntryTypeDe ADD DescriptionMethod tinyint;
-- ========================================== --
-- Command id: 1034
-- Description: دستور زیر باید اول و جدا از دستورات بعدی اجرا شود تا خطا ندهد
-- ========================================== --
UPDATE EntryType 
SET IsMergeDebitSide = 0 
WHERE IsMergeDebitSide IS NULL;

UPDATE EntryType 
SET IsMergeCreditSide = 0 
WHERE IsMergeCreditSide IS NULL;

UPDATE EntryTypeDe 
SET DescriptionMethod = 1 
WHERE DescriptionMethod IS NULL;
-- ========================================== --
-- Command id: 1035
-- Description: این دستور در بروز رسانی قبلی هم بود ولی چون بعدا اضافه شد اینجا هم آمده
-- ========================================== --
UPDATE aOperation 
SET 
    Accounting = 1,
    Salary = 1,
    Sales = 1,
    ARAP = 1,
    Store = 1,
    Asset = 1
WHERE id IN (2, 73, 74, 5086, 5087);