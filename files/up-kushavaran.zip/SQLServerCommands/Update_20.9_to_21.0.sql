﻿-- ========================================== --
-- Command id: 1058
-- Description: 
-- ========================================== --
IF OBJECT_ID('TaxSystemTransactionHistory', 'U') IS NOT NULL
    DROP TABLE TaxSystemTransactionHistory;
-- ========================================== --
-- Command id: 1059
-- Description: 
-- ========================================== --
	IF OBJECT_ID('TaxElectronicLedger', 'U') IS NOT NULL
    DROP TABLE TaxElectronicLedger;
-- ========================================== --
-- Command id: 1059
-- Description: 
-- ========================================== --
CREATE TABLE TaxElectronicLedger (
    id INT IDENTITY(1,1) PRIMARY KEY,
    FiscalPeriodid INT NOT NULL,
    FromDate INT,
    ToDate INT,
    TransactionBy TINYINT NOT NULL,
    Status TINYINT NOT NULL,
    Description NVARCHAR(MAX),
    PeriodType TINYINT NOT NULL,       
    CONSTRAINT FK_TaxElectronicLedger_FiscalPeriod 
        FOREIGN KEY (FiscalPeriodid) REFERENCES FiscalPeriod(id) ON DELETE CASCADE
);
-- ========================================== --
-- Command id: 1060
-- Description: 
-- ========================================== --
UPDATE dbo.aOperation
SET Title = N'صورت سود و زیان'
WHERE Title = N'صورتحساب سود و زیان'