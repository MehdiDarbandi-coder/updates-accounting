﻿-- ========================================== --
-- Command id: 1075
-- Description: 
-- ========================================== --
ALTER TABLE Invoice
ALTER COLUMN InvoiceTime VARCHAR(8);