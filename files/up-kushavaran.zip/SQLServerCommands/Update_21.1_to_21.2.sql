﻿-- ========================================== --
-- Command id: 1065
-- Description: 
-- ========================================== --
UPDATE aOperation
SET ModelView = 'TrialBalanseReport', IsActive = 1
WHERE id = 60;
-- ========================================== --
-- Command id: 1066
-- Description: فقط برای اس کیو ال سرور
-- ========================================== --
ALTER TABLE [dbo].[BillOfLading]
ALTER COLUMN [CustomerRealPerson] tinyint NULL;

ALTER TABLE [dbo].[BillOfLading]
ALTER COLUMN [SendStatus] tinyint NULL;


ALTER TABLE [dbo].[BillOfLading]
ALTER COLUMN [Templateid] tinyint NULL;


ALTER TABLE [dbo].[BillOfLading]
ALTER COLUMN [InvoiceTypeid] tinyint NULL;


ALTER TABLE [dbo].[BillOfLading]
ALTER COLUMN [Subjectid] tinyint NULL;

ALTER TABLE [dbo].[BillOfLading]
ALTER COLUMN [CommissionAmount] bigint NOT NULL;
-- ========================================== --
-- Command id: 1067
-- Description: 
-- ========================================== --
UPDATE aOperation
SET Salary = 1, Sales = 1, ARAP=1, Store=1, Asset=1
WHERE id = 73;
-- ========================================== --
-- Command id: 1068
-- Description: 
-- ========================================== --
UPDATE aOperation
SET ARAP=1, Store=0
WHERE id = 2;
-- ========================================== --
-- Command id: 1069
-- Description: 
-- ========================================== --
CREATE TABLE AccountComparisonReport
(
    id INT IDENTITY(1,1) NOT NULL,

    RowNumber SMALLINT NOT NULL,
    Title NVARCHAR(MAX) NOT NULL	
     
    CONSTRAINT PK_AccountComparisonReport
        PRIMARY KEY NONCLUSTERED (id)
);
-- ========================================== --
-- Command id: 1070
-- Description: 
-- ========================================== --
CREATE CLUSTERED INDEX IX_AccountComparisonReport_RowNumber
ON AccountComparisonReport (RowNumber);
-- ========================================== --
-- Command id: 1071
-- Description: 
-- ========================================== --

CREATE TABLE AccountComparisonReportDe
(
    id INT IDENTITY(1,1) NOT NULL,

    AccountComparisonReportid INT NOT NULL,
    RowNumber SMALLINT NOT NULL,

    GLid INT NULL,
    LTid INT NULL,
    LFid INT NULL,
    LFiveid INT NULL,
    LSixid INT NULL,
    ComparisonFactor TINYINT NOT NULL DEFAULT 1,
	Caption NVARCHAR(MAX) ,
    CONSTRAINT PK_AccountComparisonReportDe
        PRIMARY KEY NONCLUSTERED (id),

    CONSTRAINT FK_AccountComparisonReportDe_Main
        FOREIGN KEY (AccountComparisonReportid)
        REFERENCES AccountComparisonReport(id)
        ON DELETE CASCADE
);
-- ========================================== --
-- Command id: 1072
-- Description: 
-- ========================================== --
CREATE CLUSTERED INDEX IX_AccountComparisonReportDe_RowNumber
ON AccountComparisonReportDe
(
    AccountComparisonReportid,
    RowNumber
);

-- ========================================== --
-- Command id: 1073
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT * FROM aOperation WHERE id = 5088)
BEGIN
    SET IDENTITY_INSERT aOperation ON;
   
    INSERT INTO aOperation (id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, Accounting, Salary, Sales, ARAP, Store, Asset, IsPermissionToOther, IsActive)
    VALUES     
    (5088, N'گزارش های مقایسه ای', 'AccountComparisonReport', 9, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1);

    SET IDENTITY_INSERT aOperation OFF;
END

-- ========================================== --
-- Command id: 1074
-- Description: یوزرهایی که دسترسی به مرور حسابها دارن به پایش هم دسترسی داشته باشن
-- ========================================== --

INSERT INTO UserOperationPermission (
    Userid,
    Operationsid,
    IsFavorite,
    BackgroundColor,
    ForegroundColor,
    ButtonStyle,
    LeftLocation,
    TopLocation
)
SELECT 
    Userid,
    OP.Operationsid,
    0 AS IsFavorite,
    BackgroundColor,
    ForegroundColor,
    ButtonStyle,
    NULL AS LeftLocation,
    NULL AS TopLocation
FROM UserOperationPermission
CROSS JOIN (SELECT 5088 AS Operationsid UNION ALL SELECT 60) OP
WHERE UserOperationPermission.Operationsid = 31
  AND NOT EXISTS (
      SELECT 1 
      FROM UserOperationPermission UOP 
      WHERE UOP.Userid = UserOperationPermission.Userid 
        AND UOP.Operationsid = OP.Operationsid
  );