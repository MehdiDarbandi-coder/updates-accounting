﻿-- ========================================== --
-- Command id: 1048
-- Description: 
-- ========================================== --

-- بررسی وجود جدول قبل از ایجاد
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TaxSystemTransactionHistory]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[TaxSystemTransactionHistory](
        [id] [int] IDENTITY(1,1) NOT NULL,
        [FiscalPeriodid] [int] NOT NULL,
        [FromDate] [int] NULL,
        [ToDate] [int] NULL,
        [TransactionBy] [tinyint] NOT NULL,
        [Status] [tinyint] NOT NULL,
        [Description] [nvarchar](max) NULL,
        [DateGrouping] [tinyint] NOT NULL DEFAULT 0,
    PRIMARY KEY CLUSTERED 
    (
        [id] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END

-- اضافه کردن Foreign Key Constraint در صورت عدم وجود
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TaxSystemTransactionHistory_FiscalPeriod]') AND parent_object_id = OBJECT_ID(N'[dbo].[TaxSystemTransactionHistory]'))
BEGIN
    ALTER TABLE [dbo].[TaxSystemTransactionHistory] WITH CHECK ADD CONSTRAINT [FK_TaxSystemTransactionHistory_FiscalPeriod] FOREIGN KEY([FiscalPeriodid])
    REFERENCES [dbo].[FiscalPeriod] ([id])
    
    ALTER TABLE [dbo].[TaxSystemTransactionHistory] CHECK CONSTRAINT [FK_TaxSystemTransactionHistory_FiscalPeriod]
END

-- نوت: ستون DateGrouping قبلاً در تعریف جدول با مقدار پیش‌فرض 0 اضافه شده است