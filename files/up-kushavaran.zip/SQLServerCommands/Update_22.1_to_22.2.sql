-- ========================================== --
-- Command id: 1170
-- Description: 
-- ========================================== --
ALTER TABLE dbo.Storage ADD IsOnHold bit NOT NULL DEFAULT 0;