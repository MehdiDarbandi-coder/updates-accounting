﻿-- ========================================== --
-- Command id: 1026
-- Description: 
-- ========================================== --
-- بررسی وجود رکورد با id مشخص و در صورت عدم وجود، درج آن
IF NOT EXISTS (SELECT 1 FROM aOperation WHERE id = 75)
BEGIN
    -- خاموش کردن خاصیت identity برای درج مقادیر خاص در ستون id
    SET IDENTITY_INSERT aOperation ON;

    INSERT INTO aOperation (
        id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, 
        IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, 
        Accounting, Salary, Sales, ARAP, Store, Asset, 
        IsPermissionToOther, IsActive
    )
    VALUES (
        75, N'سامانه دفاتر الکترونیکی', 'SendTransactionsToTaxSystem', 15, 8, 0, 
        0, 1, 0, 1, 
        1, 0, 0, 0, 0, 0, 
        0, 1
    );

    -- روشن کردن خاصیت identity برای ادامه عملیات بدون دستکاری id
    SET IDENTITY_INSERT aOperation OFF;
END;
-- ========================================== --
-- Command id: 1027
-- Description: یوزرهایی که دسترسی به سند حسابداری دارن به سامانه دفاتر الکترونیکی هم دسترسی داشته باشن
-- ========================================== --
INSERT INTO UserOperationPermission (
    Userid, Operationsid, IsFavorite, BackgroundColor, ForegroundColor, 
    ButtonStyle, LeftLocation, TopLocation
)
SELECT 
    Userid, 
    75 AS Operationsid, 
    IsFavorite, 
    BackgroundColor, 
    ForegroundColor, 
    ButtonStyle, 
    LeftLocation, 
    TopLocation
FROM UserOperationPermission
WHERE Operationsid = 22;

-- ========================================== --
-- Command id: 1028
-- Description: 
-- ========================================== --
CREATE TABLE TaxSystemTransactionHistory (
    id INT IDENTITY(1,1) PRIMARY KEY,
    FiscalPeriodid INT NOT NULL,
    FromDate INT NULL,
    ToDate INT NULL,
    TransactionBy TINYINT NOT NULL,
    Status TINYINT NOT NULL,
    Description NVARCHAR(MAX) NULL,
    CONSTRAINT FK_TaxSystemTransactionHistory_FiscalPeriod FOREIGN KEY (FiscalPeriodid)
        REFERENCES FiscalPeriod(id) 
);

