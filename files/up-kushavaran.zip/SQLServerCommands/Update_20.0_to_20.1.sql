﻿-- ========================================== --
-- Command id: 1001
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'Invoice' AND COLUMN_NAME = 'CustomerTitle')
BEGIN

    ALTER TABLE Invoice
    ADD CustomerTitle NVARCHAR(MAX) NULL; 

	ALTER TABLE Invoice
    ADD IsCreditTaxCustomer BIT NULL; 	
END
-- ========================================== --
-- Command id: 1002
-- Description: 
-- ========================================== --
UPDATE Invoice
	SET Invoice.CustomerTitle = Customer.Title
	FROM Invoice
	INNER JOIN Customer ON Invoice.CustomerId = Customer.id
	WHERE Invoice.CustomerTitle IS NULL;
-- ========================================== --
-- Command id: 1003
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'Customer' AND COLUMN_NAME = 'BranchCode')
BEGIN
    ALTER TABLE Customer
    ADD BranchCode VARCHAR(Max);
END
-- ========================================== --
-- Command id: 1004
-- Description: 
-- ========================================== --
IF Not EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_NAME = 'FK_StorageCanceled_Storage')
BEGIN
ALTER TABLE StorageCanceled
ADD CONSTRAINT FK_StorageCanceled_Storage
FOREIGN KEY (Storageid)
REFERENCES Storage(id);
END
-- ========================================== --
-- Command id: 1005
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'StorageDe' AND COLUMN_NAME = 'UnitPrice')
BEGIN
    ALTER TABLE StorageDe
    ADD UnitPrice bigint;
   
END
-- ========================================== --
-- Command id: 1006
-- Description: 
-- ========================================== --
UPDATE StorageDe
    SET UnitPrice = 0
    WHERE UnitPrice IS NULL; 
-- ========================================== --
-- Command id: 1007
-- Description: 
-- ========================================== --
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_NAME = 'FK_Invoice_InvoiceType')
BEGIN

ALTER TABLE Invoice
DROP CONSTRAINT FK_Invoice_InvoiceType;

SET IDENTITY_INSERT [dbo].[EntryType] ON;

    INSERT INTO [dbo].[EntryType] ([id], [Parentid], [RowNumber], [Title], [IsActive])
    SELECT 15, 7, 3, N'فروش داخلی', 1;

    SET IDENTITY_INSERT [dbo].[EntryType] OFF;

    INSERT INTO [dbo].[EntryTypeDe] ([EntryTypeid], [Description], [Side], [ChoiceCriteriaLT], [ChoiceCriteriaLF], [ChoiceCriteriaLFive], [LTid], [LFid], [LFiveid])
    SELECT 15, N'فروش داخلی', N'InvoiceCustomer', N'Fixed', N'CustomerLF', N'NotRel', NULL, NULL, NULL
    UNION ALL
    SELECT 15, N'فروش داخلی', N'InvoiceItem', N'SaleLTInKala', N'Fixed', N'NotRel', NULL, NULL, NULL
    UNION ALL
    SELECT 15, N'فروش داخلی', N'InvoiceTax', N'Fixed', N'Fixed', N'CustomerLF', NULL, NULL, NULL;

	UPDATE [dbo].[Invoice]   SET      [InnerInvoiceTypeid] =15

	DROP TABLE InvoiceType;

	ALTER TABLE Invoice
	ADD CONSTRAINT FK_Invoice_EntryType FOREIGN KEY (InnerInvoiceTypeid) REFERENCES EntryType(id);

END
-- ========================================== --
-- Command id: 1008
-- Description: 
-- ========================================== --
ALTER TABLE Invoice
DROP CONSTRAINT FK_Invoice_GournalEntry;

ALTER TABLE Invoice
ADD CONSTRAINT FK_Invoice_GournalEntry FOREIGN KEY (GournalEntryid)
REFERENCES GournalEntry(id)
ON DELETE SET NULL;
-- ========================================== --
-- Command id: 1009
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'EntryType' AND COLUMN_NAME = 'IsMerge')
BEGIN

    ALTER TABLE EntryType
    ADD IsMerge bit NULL; 
	
END
-- ========================================== --
-- Command id: 1010
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'Company' AND COLUMN_NAME = 'WebSite')
BEGIN

    ALTER TABLE Company
    ADD WebSite VARCHAR(MAX) NULL; 
	
END
-- ========================================== --
-- Command id: 1011
-- Description: 
-- ========================================== --
IF Not EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_NAME = 'FK_Storage_GournalEntry')
BEGIN

ALTER TABLE Storage   ADD GournalEntryid int NULL; 

ALTER TABLE StorageDe  ADD GournalEntryDate int NULL;
ALTER TABLE StorageDe  ADD Amount bigint NULL;

ALTER TABLE Storage
ADD CONSTRAINT FK_Storage_GournalEntry
FOREIGN KEY (GournalEntryid)
REFERENCES GournalEntry(id)
ON DELETE SET NULL;

END
-- ========================================== --
-- Command id: 1012
-- Description: 
-- ========================================== --
SET IDENTITY_INSERT aOperation ON -- خاموش کردن خاصیت identity
   UPDATE [dbo].[aOperation] SET [ModelView] = 'CheckStatusType'     WHERE ModelView='ApArSettingView';

   IF NOT EXISTS (SELECT 1 FROM aOperation WHERE id = 74)
BEGIN
    INSERT INTO aOperation (id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, Accounting, Salary, Sales, ARAP, Store, Asset, IsPermissionToOther, IsActive)
    VALUES (74, N'تنظیمات سند اتوماتیک', 'AutoIssuanceGournalEntrySetting', 1, 6, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1);
END;

IF NOT EXISTS (SELECT 1 FROM aOperation WHERE id = 3078)
BEGIN
    INSERT INTO aOperation (id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, Accounting, Salary, Sales, ARAP, Store, Asset, IsPermissionToOther, IsActive)
    VALUES (3078, N'دریافت از اکسل', 'ImportExcel', 2, 20, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1);
END;

IF NOT EXISTS (SELECT 1 FROM aOperation WHERE id = 3079)
BEGIN
    INSERT INTO aOperation (id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, Accounting, Salary, Sales, ARAP, Store, Asset, IsPermissionToOther, IsActive)
    VALUES (3079, N'تغییر گروهی آرتیکل اسناد', 'GournalEntryGroupUpdate', 6, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1);
END;


SET IDENTITY_INSERT aOperation OFF; -- روشن کردن خاصیت identity
-- ========================================== --
-- Command id: 1013
-- Description: 
-- ========================================== --
DELETE FROM aOperation
WHERE ModelView IN ('AutoIssuePurchaseInvoice', 'StorageRateConfirmation');
-- ========================================== --
-- Command id: 1014
-- Description: 
-- ========================================== --
IF Not EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_NAME = 'FK_CostCenter_LF')
BEGIN

ALTER TABLE CostCenter  ADD LFid int NULL;

ALTER TABLE CostCenter
ADD CONSTRAINT FK_CostCenter_LF
FOREIGN KEY (LFid)
REFERENCES LF(id);
END
-- ========================================== --
-- Command id: 1015
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Customer' AND COLUMN_NAME = 'AccountNumber')
BEGIN
    ALTER TABLE Customer
    ADD AccountNumber NVARCHAR(MAX);

     ALTER TABLE BatchDe
     ALTER COLUMN Itemid TINYINT;

END
-- ========================================== --
-- Command id: 1016
-- Description: از اینجا مال آبان 1403 است
-- ========================================== --

UPDATE aOperation SET Title = N'سایر تنظیمات' WHERE ModelView = 'SettingView';

-- دو جدول زیر ناچارا باید ابتدا حذف شوند چون در کد قبلی ستون شمارنده در نظر گرفته نشده بود
IF EXISTS (SELECT * FROM sysobjects WHERE name='FinancialReportSettingsDe' AND xtype='U')
BEGIN
    DROP TABLE FinancialReportSettingsDe;
END;


IF EXISTS (SELECT * FROM sysobjects WHERE name='FinancialReportSettings' AND xtype='U')
BEGIN
    DROP TABLE FinancialReportSettings;
END;


-- بررسی و ایجاد جدول FinancialReportSettings
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FinancialReportSettings' AND xtype='U')
BEGIN
    CREATE TABLE FinancialReportSettings (
        id INT IDENTITY(1,1) PRIMARY KEY,
        ReportType TINYINT NOT NULL,
        ItemType TINYINT NOT NULL,
        Title NVARCHAR(MAX) NOT NULL,
        NoteNumber NVARCHAR(MAX),
        RowNumber SMALLINT NOT NULL
    );
END;

-- بررسی و ایجاد جدول FinancialReportSettingsDe
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FinancialReportSettingsDe' AND xtype='U')
BEGIN
    CREATE TABLE FinancialReportSettingsDe (
        id INT IDENTITY(1,1) PRIMARY KEY,
        FinancialReportSettingsid INT NOT NULL,
        RowNumber SMALLINT,
        LTid INT,    
        GLid INT,   
        CONSTRAINT FK_FinancialReportSettingsDe_FinancialReportSettings 
            FOREIGN KEY (FinancialReportSettingsid) REFERENCES FinancialReportSettings(id) ON DELETE CASCADE,
        CONSTRAINT FK_FinancialReportSettingsDe_GL
            FOREIGN KEY (GLid) REFERENCES GL(id),
        CONSTRAINT FK_FinancialReportSettingsDe_LT
            FOREIGN KEY (LTid) REFERENCES LT(id) ON DELETE CASCADE
    );
END;

SET IDENTITY_INSERT [dbo].[FinancialReportSettings] ON;

INSERT INTO [dbo].[FinancialReportSettings] (id,ReportType, ItemType, Title, NoteNumber, RowNumber)
SELECT id,ReportType, ItemType, Title, NoteNumber, RowNumber
FROM (
    VALUES
   (1, 0, 0, N'عملیات در حال تداوم', NULL, 1),
(2, 0, 1, N'درآمدهای عملیاتی', 5, 2),
(3, 0, 1, N'بهای تمام شده درآمدهای عملیاتی', 7, 3),
(4, 0, 2, N'سود ناخالص', NULL, 4),
(5, 0, 1, N'هزینه‌های فروش، اداری و عمومی', 8, 5),
(6, 0, 1, N'زیان کاهش ارزش دریافتنی ها', 9, 6),
(7, 0, 1, N'سایر درآمدها', 10, 7),
(8, 0, 1, N'سایر هزینه‌ها', 11, 8),
(9, 0, 2, N'سود عملیاتی', NULL, 9),
(10, 0, 1, N'هزینه‌های مالی', 12, 10),
(11, 0, 1, N'سایر درآمدها و هزینه‌های غیرعملیاتی', 13, 11),
(12, 0, 2, N'سود عملیات در حال تداوم قبل از مالیات', NULL, 12),
(13, 0, 1, N'هزینه مالیات بر درآمد', NULL, 13),
(14, 0, 2, N'سود خالص عملیات در حال تداوم', NULL, 14),
(15, 0, 0, N'عملیات متوقف شده', NULL, 15),
(16, 0, 1, N'سود (زیان) خالص عملیات متوقف شده', 14, 16),
(17, 0, 2, N'سود خالص', NULL, 17),
(18, 0, 0, N'سود هر سهم', NULL, 18),
(19, 0, 0, N':سود پایه هر سهم', NULL, 19),
(20, 0, 3, N'عملیاتی (ریال)', NULL, 20),
(21, 0, 3, N'غیر عملیاتی (ریال)', NULL, 21),
(22, 0, 3, N'ناشی از عملیات در حال تداوم (ریال)', NULL, 22),
(23, 0, 3, N'ناشی از عملیات متوقف شده (ریال)', NULL, 23),
(24, 0, 2, N'سود پایه هر سهم (ریال)', 15, 24),
(50, 1, 0, N'دارایی ها', NULL, 1),
(51, 1, 0, N'دارایی های غیر جاری', NULL, 2),
(52, 1, 1, N'دارایی های ثابت مشهود', 16, 3),
(53, 1, 1, N'سرمایه گذاری در املاک', 17, 4),
(54, 1, 1, N'دارایی های نامشهود', 18, 5),
(55, 1, 1, N'سرمایه گذاری های بلندمدت', 19, 6),
(56, 1, 1, N'دریافتنی های بلندمدت', 20, 7),
(57, 1, 1, N'دارایی مالیات انتقالی', 35, 8),
(58, 1, 1, N'سایر دارایی ها', 21, 9),
(59, 1, 2, N'جمع دارایی های غیرجاری', NULL, 10),
(60, 1, 0, N'دارایی های جاری', NULL, 11),
(61, 1, 1, N'پیش پرداخت ها', 22, 12),
(62, 1, 1, N'موجودی مواد و کالا', 23, 13),
(63, 1, 1, N'دریافتنی های تجاری و سایر دریافتنی ها', 20, 14),
(64, 1, 1, N'سرمایه گذاری های کوتاه مدت', 24, 15),
(65, 1, 1, N'موجودی نقد', 25, 16),
(66, 1, 2, N'', NULL, 17),
(67, 1, 1, N'دارایی هی غیر جاری نگهداری شده برای فروش', 26, 18),
(68, 1, 2, N'جمع دارایی های جاری', NULL, 19),
(69, 1, 2, N'جمع دارایی ها', NULL, 20),
(70, 1, 0, N'حقوق مالکانه و بدهی ها', NULL, 21),
(71, 1, 0, N'حقوق مالکانه', NULL, 22),
(72, 1, 1, N'سرمایه', 27, 23),
(73, 1, 1, N'افزایش سرمایه در جریان', 28, 24),
(74, 1, 1, N'صرف سهام', 29, 25),
(75, 1, 1, N'صرف سهام خزانه', NULL, 26),
(76, 1, 1, N'اندوخته قانونی', 30, 27),
(77, 1, 1, N'سایر اندوخته ها', 31, 28),
(78, 1, 1, N'مازاد تجدید ارزیابی دارایی ها', NULL, 29),
(79, 1, 1, N'سود انباشته', NULL, 30),
(80, 1, 1, N'سهام خزانه', 32, 31),
(81, 1, 2, N'جمع حقوق مالکانه', NULL, 32),
(82, 1, 0, N'بدهی ها', NULL, 33),
(83, 1, 0, N'بدهی های غیر جاری', NULL, 34),
(84, 1, 1, N'پرداختنی های بلند مدت', 33, 35),
(85, 1, 1, N'تسهیلات مالی بلند مدت', 34, 36),
(86, 1, 1, N'بدهی مالیات انتقالی', 35, 37),
(87, 1, 1, N'ذخیره مزایای پایان خدمت کارکنان', 36, 38),
(88, 1, 2, N'جمع بدهی های غیر جاری', NULL, 39),
(89, 1, 0, N'بدهی های جاری', NULL, 40),
(90, 1, 1, N'پرداختنی های تجاری و سایر پرداختنی ها', 33, 41),
(91, 1, 1, N'مالیات پرداختنی ', 35, 42),
(92, 1, 1, N'سود سهام پرداختنی', 37, 43),
(93, 1, 1, N'تسهیلات مالی', 34, 44),
(94, 1, 1, N'دخایر', 38, 45),
(95, 1, 1, N'پیش دریافت ها', 39, 46),
(96, 1, 2, N'', NULL, 47),
(97, 1, 1, N'بدهی های مرتبط با دارایی هاز غیر جاری نگهداری شده برای فروش', 26, 48),
(98, 1, 2, N'جمع بدهی های جاری', NULL, 49),
(99, 1, 2, N'جمع بدهی ها', NULL, 50),
(100, 1, 2, N'جمع حقوق مالکانه و بدهی ها', NULL, 51)

) AS NewData (id,ReportType, ItemType, Title, NoteNumber, RowNumber)
WHERE NOT EXISTS (
    SELECT 1
    FROM [dbo].[FinancialReportSettings] AS ExistingData
   WHERE ExistingData.id = NewData.id
);

SET IDENTITY_INSERT [dbo].[FinancialReportSettings] OFF;

IF NOT EXISTS (SELECT * FROM aOperation WHERE id = 5086)
BEGIN
    SET IDENTITY_INSERT aOperation ON;
   
    INSERT INTO aOperation (id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, Accounting, Salary, Sales, ARAP, Store, Asset, IsPermissionToOther, IsActive)
    VALUES 
    (5086, N'تعیین اقلام صورت سود و زیان', 'IncomeStatementSettings', 1, 7, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1),
    (5087, N'تعیین اقلام صورت وضعیت مالی', 'BalanceSheetSettings', 1, 8, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1);

    SET IDENTITY_INSERT aOperation OFF;
END

--مرتب کردن شماره سطرها--
UPDATE dbo.aOperation
SET RowNumber = mapped.RowNumber
FROM dbo.aOperation AS op
JOIN (VALUES
    (1, 1), (3, 2), (5, 3), (6, 4), 
    (4, 5), (2, 6), (5086, 7), (5087, 8), 
    (74, 9), (73, 10)
) AS mapped (id, RowNumber)
ON op.id = mapped.id;


-- معادل دستور UPDATE دیگر در SQL Server
UPDATE aOperation SET ModelView = 'IncomeStatementReport', IsActive = 1 WHERE id = 50;
UPDATE aOperation SET ModelView = 'BalanceSheetReport', IsActive = 1 WHERE id = 51;

UPDATE [dbo].[aOperation] SET [Title] = N'سایر تنظیمات'     WHERE ModelView='SettingView';
-- ========================================== --
-- Command id: 1017
-- Description: 
-- ========================================== --
-- ایجاد دسترسی برای ادمین در صورت نبود و همچنین حذف سطرهای تکراری 
INSERT INTO UserOperationPermission (Userid, Operationsid, IsFavorite, BackgroundColor, ForegroundColor, ButtonStyle, LeftLocation, TopLocation)
SELECT 1 AS Userid, A.id AS Operationsid, 0 AS IsFavorite, NULL AS BackgroundColor, NULL AS ForegroundColor, NULL AS ButtonStyle, NULL AS LeftLocation, NULL AS TopLocation
FROM aOperation A
LEFT JOIN UserOperationPermission UOP ON A.id = UOP.Operationsid AND UOP.Userid = 1
WHERE A.OnlyAdmin = 1
AND UOP.Operationsid IS NULL;


WITH DuplicateRows AS (
    SELECT 
        *,
        ROW_NUMBER() OVER (PARTITION BY Userid, Operationsid ORDER BY (SELECT NULL)) AS RowNum
    FROM 
        UserOperationPermission
)
DELETE FROM UserOperationPermission
WHERE id IN (
    SELECT id
    FROM DuplicateRows
    WHERE RowNum > 1
);
