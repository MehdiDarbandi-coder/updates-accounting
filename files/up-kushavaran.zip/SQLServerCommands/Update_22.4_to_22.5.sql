﻿-- ========================================== --
-- Command id: 1182
-- Description: افزودن ستون‌های TaxExemptionTypeid (نوع معافیت مالیاتی) و AllowSetTaxExemptionType به جدول SalaryItem
-- ========================================== --
ALTER TABLE SalaryItem ADD TaxExemptionTypeid INT NOT NULL DEFAULT 0;
ALTER TABLE SalaryItem ADD AllowSetTaxExemptionType BIT NOT NULL DEFAULT 0;
-- ========================================== --
-- Command id: 1183
-- Description: مقداردهی ستون TaxExemptionTypeid بر اساس رفتار قبلی برنامه و بخشنامه جدید
-- ========================================== --
-- معاف کامل: ماموریت، هزینه ماموریت، بازخرید مرخصی، بازخرید سنوات (رفتار قبلی)
UPDATE SalaryItem SET TaxExemptionTypeid = 1 WHERE Itemid IN (4, 5, 41, 42);

-- معاف تا یک‌دوازدهم معافیت سالیانه: عیدی (رفتار قبلی)
UPDATE SalaryItem SET TaxExemptionTypeid = 2 WHERE Itemid = 40;

-- معاف تا دو برابر معافیت ماهیانه: مزایای غیرنقدی (رفتار قبلی، بر اساس نوع عامل در سامانه مالیات)
UPDATE SalaryItem SET TaxExemptionTypeid = 3
WHERE TaxItemTypeid IN (13, 31);

-- امکان تغییر نوع معافیت توسط کاربر برای آیتم‌های اضافات
UPDATE SalaryItem SET AllowSetTaxExemptionType = 1 WHERE IsAdding = 1;