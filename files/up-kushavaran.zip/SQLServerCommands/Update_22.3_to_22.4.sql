﻿-- ========================================== --
-- Command id: 1175
-- Description: 
-- ========================================== --
UPDATE Kala
SET IsShowInInvoice =
    CASE WHEN EXISTS (SELECT 1 FROM InvoiceDe d WHERE d.Kalaid = Kala.id)
          AND EXISTS (SELECT 1 FROM KalaPriceDe p WHERE p.Kalaid = Kala.id)
         THEN 1 ELSE 0 END;

-- ========================================== --
-- Command id: 1176
-- Description: حذف جدول KalaPriceBatch
-- ========================================== --
DROP TABLE KalaPriceBatch;

-- ========================================== --
-- Command id: 1177
-- Description: حذف ستون RowNumber از KalaPriceDe و بازسازی ایندکس کلاستر
-- ========================================== --
DROP INDEX IX_KalaPriceDe ON KalaPriceDe;
ALTER TABLE KalaPriceDe DROP COLUMN RowNumber;
CREATE CLUSTERED INDEX IX_KalaPriceDe ON KalaPriceDe (KalaPriceid DESC, Kalaid);

-- ========================================== --
-- Command id: 1178
-- Description: حذف ستون PriceVersionNumber از KalaPrice
-- ========================================== --
ALTER TABLE KalaPrice DROP COLUMN PriceVersionNumber;

-- ========================================== --
-- Command id: 1179
-- Description: افزودن ستون Insr (ماده 9) به جدول Invoice
-- ========================================== --
ALTER TABLE Invoice ADD Insr TINYINT NULL;

-- ========================================== --
-- Command id: 1180
-- Description: افزودن ستون SubjectDate (تاریخ موضوع آخرین ارسال موفق) به جدول Invoice
-- ========================================== --
ALTER TABLE Invoice ADD SubjectDate INT NULL;

-- ========================================== --
-- Command id: 1181
-- Description: افزودن ستون SubjectTime (ساعت موضوع آخرین ارسال موفق) به جدول Invoice
-- ========================================== --
ALTER TABLE Invoice ADD SubjectTime NVARCHAR(5) NULL;