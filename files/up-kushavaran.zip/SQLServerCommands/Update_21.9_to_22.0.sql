-- ========================================== --
-- Command id: 1148
-- Description: حذف ستون‌های رنگ از UserOperationPermission (همراه با حذف Default Constraint در صورت وجود)
-- ========================================== --
IF COL_LENGTH(N'dbo.UserOperationPermission', N'BackgroundColor') IS NOT NULL
BEGIN
    DECLARE @sql1 NVARCHAR(MAX) = N'';
    SELECT @sql1 = @sql1 + N'ALTER TABLE dbo.UserOperationPermission DROP CONSTRAINT ' + QUOTENAME(dc.name) + N';'
    FROM sys.default_constraints dc
    INNER JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'dbo.UserOperationPermission') AND c.name = N'BackgroundColor';
    IF LEN(@sql1) > 0 EXEC sp_executesql @sql1;
    ALTER TABLE dbo.UserOperationPermission DROP COLUMN BackgroundColor;
END

IF COL_LENGTH(N'dbo.UserOperationPermission', N'ForegroundColor') IS NOT NULL
BEGIN
    DECLARE @sql2 NVARCHAR(MAX) = N'';
    SELECT @sql2 = @sql2 + N'ALTER TABLE dbo.UserOperationPermission DROP CONSTRAINT ' + QUOTENAME(dc.name) + N';'
    FROM sys.default_constraints dc
    INNER JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'dbo.UserOperationPermission') AND c.name = N'ForegroundColor';
    IF LEN(@sql2) > 0 EXEC sp_executesql @sql2;
    ALTER TABLE dbo.UserOperationPermission DROP COLUMN ForegroundColor;
END

-- ========================================== --
-- Command id: 1149
-- Description: 
-- ========================================== --

DELETE FROM UserBrushThemDe WHERE Brushid = 53;

INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 1,  53, '#172840';     -- سرمه‌ای و طلایی
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 2,  53, '#2A1E19';     -- اسپرسو و مسی
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 3,  53, '#DAE2E6';     -- آبی آسمانی و نقره‌ای (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 4,  53, '#12343A';     -- یشمی و نقره‌ای پلاتینی
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 5,  53, '#FF1F7A4E';   -- زمرد درخشان (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 6,  53, '#FF5C1F7A';   -- ارکیده بنفش (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 7,  53, '#FF7A3F1F';   -- غروب زرین (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 8,  53, '#FF1B3649';   -- اعماق اقیانوس
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 9,  53, '#FF1B4933';   -- جنگل شبانه
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 10, 53, '#FF361B49';   -- بنفش شاهانه
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 11, 53, '#FF1B2B49';   -- دودی شبانه
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 12, 53, '#A9A897';     -- زیتونی خاکستری و برنز مات (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 13, 53, '#FF1F4F7A';   -- لاجورد اقیانوسی (تیره‌تر)

-- ========================================== --
-- Command id: 1150
-- Description: ایجاد جدول KalaStockLevel
-- ========================================== --
IF OBJECT_ID(N'dbo.KalaStockLevel', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[KalaStockLevel] (
        [id]                INT IDENTITY(1,1) NOT NULL,
        [Kalaid]            INT           NOT NULL,
        [Storeid]           INT           NULL,
        [MinQuantity]       FLOAT         NOT NULL CONSTRAINT [DF_KalaStockLevel_Min]        DEFAULT 0,
        [ReorderPoint]      FLOAT         NOT NULL CONSTRAINT [DF_KalaStockLevel_Reorder]    DEFAULT 0,
        [ReorderQuantity]   FLOAT         NOT NULL CONSTRAINT [DF_KalaStockLevel_ReorderQty] DEFAULT 0,
        [MaxQuantity]       FLOAT         NULL,
        [LeadTimeDays]      INT           NULL,
        [DefaultSupplierid] INT           NULL,
        [IsActive]          BIT           NOT NULL CONSTRAINT [DF_KalaStockLevel_IsActive]   DEFAULT 1,
        CONSTRAINT [PK_KalaStockLevel] PRIMARY KEY CLUSTERED ([id]),
        CONSTRAINT [FK_KalaStockLevel_Kala]     FOREIGN KEY ([Kalaid])            REFERENCES [dbo].[Kala]([id])     ON DELETE CASCADE,
        CONSTRAINT [FK_KalaStockLevel_Store]    FOREIGN KEY ([Storeid])           REFERENCES [dbo].[Store]([id])    ON DELETE CASCADE,
        CONSTRAINT [FK_KalaStockLevel_Supplier] FOREIGN KEY ([DefaultSupplierid]) REFERENCES [dbo].[Customer]([id]) ON DELETE SET NULL
    );
END

-- ========================================== --
-- Command id: 1151
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_KalaStockLevel_Kala_Store' AND object_id = OBJECT_ID(N'dbo.KalaStockLevel'))
BEGIN
    CREATE UNIQUE INDEX [UX_KalaStockLevel_Kala_Store]
        ON [dbo].[KalaStockLevel]([Kalaid], [Storeid])
        WHERE [Storeid] IS NOT NULL;
END

-- ========================================== --
-- Command id: 1152
-- Description: 
-- ========================================== --
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_KalaStockLevel_Kala_AllStores' AND object_id = OBJECT_ID(N'dbo.KalaStockLevel'))
BEGIN
    CREATE UNIQUE INDEX [UX_KalaStockLevel_Kala_AllStores]
        ON [dbo].[KalaStockLevel]([Kalaid])
        WHERE [Storeid] IS NULL;
END

-- ========================================== --
-- Command id: 1153
-- Description: با توجه به ایرادی که دستور زیر در نسخه های قبلی داشت
-- ========================================== --
IF COL_LENGTH(N'[dbo].[Kala]', N'ShowSubUnitInInvoice') IS NULL
BEGIN
    ALTER TABLE [dbo].[Kala]
    ADD [ShowSubUnitInInvoice] [bit] NOT NULL
        CONSTRAINT [DF_Kala_ShowSubUnitInInvoice] DEFAULT ((0));
END

-- ========================================== --
-- Command id: 1154
-- Description: ایجاد جدول اعلان‌های داشبورد (DashAnnouncement)
-- ========================================== --
IF OBJECT_ID(N'dbo.DashAnnouncement', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DashAnnouncement
    (
        id             INT IDENTITY(1,1) NOT NULL,
        FeedKey        VARCHAR(64)    NOT NULL,   -- شناسه‌ی یکتای آیتم در فید (فقط لاتین)
        Revision       INT            NOT NULL CONSTRAINT DF_DashAnnouncement_Revision DEFAULT (1),
        Category       VARCHAR(20)    NOT NULL,   -- Tip / Tutorial / News / Ad
        Title          NVARCHAR(300)  NOT NULL,
        Body           NVARCHAR(MAX)  NOT NULL CONSTRAINT DF_DashAnnouncement_Body DEFAULT (N''),
        LinkUrl        NVARCHAR(1000) NOT NULL CONSTRAINT DF_DashAnnouncement_LinkUrl DEFAULT (N''),
        ImageUrl       NVARCHAR(1000) NOT NULL CONSTRAINT DF_DashAnnouncement_ImageUrl DEFAULT (N''),
        Priority       INT            NOT NULL CONSTRAINT DF_DashAnnouncement_Priority DEFAULT (0),
        PublishedDate  INT            NOT NULL,   -- yyyymmdd شمسی
        ExpiresDate    INT            NOT NULL CONSTRAINT DF_DashAnnouncement_ExpiresDate DEFAULT (0),   -- 0 = بدون انقضا
        IsRead         BIT            NOT NULL CONSTRAINT DF_DashAnnouncement_IsRead DEFAULT (0),
        IsStarred      BIT            NOT NULL CONSTRAINT DF_DashAnnouncement_IsStarred DEFAULT (0),
        IsHidden       BIT            NOT NULL CONSTRAINT DF_DashAnnouncement_IsHidden DEFAULT (0),
        CONSTRAINT PK_DashAnnouncement PRIMARY KEY NONCLUSTERED (id)
    );

    CREATE CLUSTERED INDEX IX_DashAnnouncement_PublishedDate
        ON dbo.DashAnnouncement (PublishedDate);

    CREATE UNIQUE NONCLUSTERED INDEX UQ_DashAnnouncement_FeedKey
        ON dbo.DashAnnouncement (FeedKey);
END

-- ========================================== --
-- Command id: 1155
-- Description: ایجاد جدول همگام‌سازی اعلان‌های داشبورد (DashAnnouncementSync)
-- ========================================== --
IF OBJECT_ID(N'dbo.DashAnnouncementSync', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DashAnnouncementSync
    (
        id              INT IDENTITY(1,1) NOT NULL,
        ETag            VARCHAR(200) NOT NULL CONSTRAINT DF_DashAnnouncementSync_ETag DEFAULT (''),
        LastModified    VARCHAR(100) NOT NULL CONSTRAINT DF_DashAnnouncementSync_LastModified DEFAULT (''),
        LastSuccessDate INT          NOT NULL CONSTRAINT DF_DashAnnouncementSync_LastSuccessDate DEFAULT (0),   -- 0 = هنوز دریافت نشده
        CONSTRAINT PK_DashAnnouncementSync PRIMARY KEY NONCLUSTERED (id)
    );
END

-- ========================================== --
-- Command id: 1156
-- Description: پاکسازی رنگ‌های داشبورد و BackgMainTabHeaderStrip (قابل اجرای مجدد)
-- ========================================== --
DELETE FROM UserBrushThemDe WHERE Brushid BETWEEN 2000 AND 2099;
DELETE FROM UserBrushThemDe WHERE Brushid = 53;

-- ========================================== --
-- Command id: 1157
-- Description: BackgMainTabHeaderStrip (53) - فقط تم‌های Scope 1
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT v.ThemeId, 53, v.Color
FROM (
    SELECT 1 AS ThemeId, '#FF202E41' AS Color
    UNION ALL SELECT 2, '#FF322723'
    UNION ALL SELECT 3, '#FFD5DDE2'
    UNION ALL SELECT 4, '#FF1C393D'
    UNION ALL SELECT 5, '#FF328A5E'
    UNION ALL SELECT 6, '#FF6C328A'
    UNION ALL SELECT 7, '#FF8A4F32'
    UNION ALL SELECT 8, '#FF233C4C'
    UNION ALL SELECT 9, '#FF234C38'
    UNION ALL SELECT 10, '#FF3E234C'
    UNION ALL SELECT 11, '#FF23304C'
    UNION ALL SELECT 12, '#FFACAB9C'
    UNION ALL SELECT 13, '#FF32658A'
) v
INNER JOIN UserBrushThem t ON t.id = v.ThemeId
WHERE t.Scope = 1;

-- ========================================== --
-- Command id: 1158
-- Description: داشبورد - رنگ‌های هماهنگ با صفحه اول (کپی از کلیدهای پوسته همان تم)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT d.BrushThemid, m.DashId, d.Color
FROM UserBrushThemDe d
INNER JOIN UserBrushThem t ON t.id = d.BrushThemid AND t.Scope = 1
INNER JOIN (
    SELECT 2000 AS DashId, 44 AS SourceBrush
    UNION ALL SELECT 2001, 46
    UNION ALL SELECT 2002, 50
    UNION ALL SELECT 2003, 43
    UNION ALL SELECT 2004, 45
    UNION ALL SELECT 2005, 45
    UNION ALL SELECT 2006, 2
    UNION ALL SELECT 2010, 51
    UNION ALL SELECT 2011, 50
    UNION ALL SELECT 2012, 13
    UNION ALL SELECT 2013, 14
    UNION ALL SELECT 2014, 37
    UNION ALL SELECT 2015, 38
    UNION ALL SELECT 2020, 43
    UNION ALL SELECT 2021, 10
    UNION ALL SELECT 2022, 44
    UNION ALL SELECT 2023, 35
    UNION ALL SELECT 2024, 13
    UNION ALL SELECT 2025, 14
    UNION ALL SELECT 2026, 1
    UNION ALL SELECT 2027, 3
    UNION ALL SELECT 2028, 15
    UNION ALL SELECT 2029, 3
    UNION ALL SELECT 2030, 50
) m ON m.SourceBrush = d.Brushid
WHERE d.Brushid < 100;

-- ========================================== --
-- Command id: 1159
-- Description: داشبورد - رنگ‌های ثابت (بوم شفاف، سایه، نشانگر، براق) - تم‌های Scope 1
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2007 AS BrushId, '#00FFFFFF' AS Color
    UNION ALL SELECT 2008, '#FF000000'
    UNION ALL SELECT 2016, '#FFFFFFFF'
    UNION ALL SELECT 2070, '#30FFFFFF'
    UNION ALL SELECT 2071, '#00FFFFFF'
) k
WHERE t.Scope = 1;

-- ========================================== --
-- Command id: 1160
-- Description: داشبورد - کارت‌های معنایی در تم‌های روشن Scope 1 (3, 5, 6, 7, 12, 13)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2040 AS BrushId, '#FFDBEAFE' AS Color
    UNION ALL SELECT 2041, '#FF1D4ED8'
    UNION ALL SELECT 2042, '#FF93C5FD'
    UNION ALL SELECT 2043, '#FFD1FAE5'
    UNION ALL SELECT 2044, '#FF047857'
    UNION ALL SELECT 2045, '#FF6EE7B7'
    UNION ALL SELECT 2046, '#FFFEF3C7'
    UNION ALL SELECT 2047, '#FFB45309'
    UNION ALL SELECT 2048, '#FFFCD34D'
    UNION ALL SELECT 2049, '#FFFEE2E2'
    UNION ALL SELECT 2050, '#FFB91C1C'
    UNION ALL SELECT 2051, '#FFFCA5A5'
) k
WHERE t.Scope = 1 AND t.id IN (3, 5, 6, 7, 12, 13);

-- ========================================== --
-- Command id: 1161
-- Description: داشبورد - کارت‌های معنایی در تم‌های تیره Scope 1 (بقیه)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2040 AS BrushId, '#FF26475E' AS Color
    UNION ALL SELECT 2041, '#FF8DBFE2'
    UNION ALL SELECT 2042, '#FF2E5876'
    UNION ALL SELECT 2043, '#FF204630'
    UNION ALL SELECT 2044, '#FF59C084'
    UNION ALL SELECT 2045, '#FF3C865B'
    UNION ALL SELECT 2046, '#FF503E21'
    UNION ALL SELECT 2047, '#FFD6AD66'
    UNION ALL SELECT 2048, '#FF98773E'
    UNION ALL SELECT 2049, '#FF502124'
    UNION ALL SELECT 2050, '#FFD36972'
    UNION ALL SELECT 2051, '#FF983E46'
) k
WHERE t.Scope = 1 AND t.id NOT IN (3, 5, 6, 7, 12, 13);

-- ========================================== --
-- Command id: 1162
-- Description: داشبورد - رنگ نمودار (2060-2067) تم‌های روشن Scope 1
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2060 AS BrushId, '#FF3B82F6' AS Color
    UNION ALL SELECT 2061, '#FF10B981'
    UNION ALL SELECT 2062, '#FFF59E0B'
    UNION ALL SELECT 2063, '#FF8B5CF6'
    UNION ALL SELECT 2064, '#FF14B8A6'
    UNION ALL SELECT 2065, '#FFEC4899'
    UNION ALL SELECT 2066, '#FF6366F1'
    UNION ALL SELECT 2067, '#FF9CA3AF'
) k
WHERE t.Scope = 1 AND t.id IN (3, 5, 6, 7, 12, 13);

-- ========================================== --
-- Command id: 1163
-- Description: داشبورد - رنگ نمودار (2060-2067) تم‌های تیره Scope 1 (پالت روشن‌تر)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2060 AS BrushId, '#FF60A5FA' AS Color
    UNION ALL SELECT 2061, '#FF34D399'
    UNION ALL SELECT 2062, '#FFFBBF24'
    UNION ALL SELECT 2063, '#FFA78BFA'
    UNION ALL SELECT 2064, '#FF2DD4BF'
    UNION ALL SELECT 2065, '#FFF472B6'
    UNION ALL SELECT 2066, '#FF818CF8'
    UNION ALL SELECT 2067, '#FFD1D5DB'
) k
WHERE t.Scope = 1 AND t.id NOT IN (3, 5, 6, 7, 12, 13);

-- ========================================== --
-- Command id: 1164
-- Description: ForegDashCanvasText (2009) - متن روی بوم (2007 شفاف) بر اساس روشنایی زمینه‌ی صفحه (برش 2) همان تم
-- زمینه روشن -> متن تیره | زمینه تیره -> متن روشن
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT d.BrushThemid, 2009,
       CASE WHEN ( 0.299 * CONVERT(INT, CONVERT(VARBINARY(1), SUBSTRING(d.Color, x.o,     2), 2))
                 + 0.587 * CONVERT(INT, CONVERT(VARBINARY(1), SUBSTRING(d.Color, x.o + 2, 2), 2))
                 + 0.114 * CONVERT(INT, CONVERT(VARBINARY(1), SUBSTRING(d.Color, x.o + 4, 2), 2)) ) > 140
            THEN '#FF1F2937'
            ELSE '#FFF3F4F6'
       END
FROM UserBrushThemDe d
INNER JOIN UserBrushThem t ON t.id = d.BrushThemid AND t.Scope = 1
CROSS APPLY (SELECT CASE WHEN LEN(d.Color) = 9 THEN 4 ELSE 2 END AS o) x
WHERE d.Brushid = 2;
