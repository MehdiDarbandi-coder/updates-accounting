-- ========================================== --
-- Command id: 1165
-- Description: داشبورد - زمینه آیتم لیست حرکت موس (2017) هماهنگ با هاور سطر جدول (2023)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT d.BrushThemid, 2017, d.Color
FROM UserBrushThemDe d
INNER JOIN UserBrushThem t ON t.id = d.BrushThemid AND t.Scope = 1
WHERE d.Brushid = 2023;

-- ========================================== --
-- Command id: 1166
-- Description: داشبورد - زمینه آیتم انتخاب‌شده لیست (2018) هماهنگ با سطر انتخاب‌شده جدول (2024)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT d.BrushThemid, 2018, d.Color
FROM UserBrushThemDe d
INNER JOIN UserBrushThem t ON t.id = d.BrushThemid AND t.Scope = 1
WHERE d.Brushid = 2024;
-- ========================================== --
-- Command id: 1167
-- Description: 
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT d.BrushThemid, 2018, d.Color
FROM UserBrushThemDe d
INNER JOIN UserBrushThem t ON t.id = d.BrushThemid AND t.Scope = 1
WHERE d.Brushid = 2024;
INSERT INTO UserOperationPermission (Userid, Operationsid, IsFavorite, ButtonStyle, LeftLocation, TopLocation)
SELECT u.id, o.Operationsid, 0, 1, 0, 0
FROM "User" u
CROSS JOIN (
    SELECT 9001 AS Operationsid
    UNION ALL SELECT 9002
    UNION ALL SELECT 9003
    UNION ALL SELECT 9004
    UNION ALL SELECT 9005
) o
WHERE u.id <> 1
  AND NOT EXISTS (
      SELECT 1
      FROM UserOperationPermission p
      WHERE p.Userid = u.id
        AND p.Operationsid = o.Operationsid
  );
-- ========================================== --
-- Command id: 1168
-- Description: 
-- ========================================== --
DELETE FROM UserBrushThemDe
WHERE id NOT IN (
    SELECT MIN(id)
    FROM UserBrushThemDe
    GROUP BY BrushThemid, Brushid
);