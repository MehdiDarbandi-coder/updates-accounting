﻿-- ========================================== --
-- Command id: 1061
-- Description: 
-- ========================================== --
CREATE TABLE CashPayDeCheck_backup AS SELECT * FROM CashPayDeCheck;
DROP TABLE CashPayDeCheck;
CREATE TABLE "CashPayDeCheck" (
	"id"	INTEGER NOT NULL,
	"CashPayid"	INTEGER NOT NULL,
	"RowNumber"	INTEGER NOT NULL,
	"IsRecieptCheck"	INTEGER NOT NULL,
	"RecieptCheckid"	INTEGER,
	"Amount"	INTEGER NOT NULL,
	"CheckNumber"	TEXT NOT NULL,
	"TracingNumber"	TEXT,
	"DueDate"	INTEGER,
	"Bankid"	INTEGER,
	CONSTRAINT "PK_CashPayDeCheck" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_CashPayDeCheck_CashPay" FOREIGN KEY("CashPayid") REFERENCES "CashPay"("id") ON DELETE CASCADE,
	CONSTRAINT "FK_CashPayDeCheck_LF" FOREIGN KEY("Bankid") REFERENCES "LF"("id"),
	CONSTRAINT "FK_CashPayDeCheck_CheckTransfer" FOREIGN KEY("RecieptCheckid") REFERENCES "CheckTransfer"("id")
);
INSERT INTO CashPayDeCheck SELECT * FROM CashPayDeCheck_backup;
DROP TABLE CashPayDeCheck_backup;
-- ========================================== --
-- Command id: 1062
-- Description: 
-- ========================================== --
CREATE TABLE "Transportation" (
	"id"	INTEGER NOT NULL,
	"Storageid"	INTEGER NOT NULL,
	"DriverFullName"	TEXT,
	"DriverNationalCode"	TEXT,
	"DriverPhoneNumber"	TEXT,
	"VehicleNumber"	TEXT,
	"VehicleType"	TEXT,
	"ReceiverFullName"	TEXT,
	"DeliveryAddress"	TEXT,
	"DeliveryPostalCode"	TEXT,
	"WaybillNumber"	TEXT,
	"WaybillIssuerCompany"	TEXT,
	"TransportationDate"	INTEGER,
	"TransportDescription"	TEXT,
	CONSTRAINT "PK_Transportation" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_Transportation_Storage" FOREIGN KEY("Storageid") REFERENCES "Storage"("id") ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 1063
-- Description: 
-- ========================================== --
ALTER TABLE KalaPrice ADD COLUMN PriceVersionNumber INTEGER;
-- ========================================== --
-- Command id: 1064
-- Description: 
-- ========================================== --
WITH Ordered AS (
    SELECT 
        rowid AS rid,
        CAST(substr(StartDate, 1, 4) AS INTEGER) AS Year4,
        ROW_NUMBER() OVER (
            PARTITION BY substr(StartDate, 1, 4)
            ORDER BY StartDate
        ) AS rn
    FROM KalaPrice
)
UPDATE KalaPrice
SET PriceVersionNumber =
       (SELECT Year4 * 1000 + rn
        FROM Ordered o
        WHERE o.rid = KalaPrice.rowid);
