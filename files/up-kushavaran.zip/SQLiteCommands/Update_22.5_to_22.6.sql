﻿-- ========================================== --
-- Command id: 1184
-- Description: ایجاد جدول Driver (اطلاعات پایه مالک/راننده و خودرو)
-- ========================================== --
-- حذف موارد قبلی (اول فرزندها، بعد پدرها)
DROP INDEX IF EXISTS UX_DriverStatementDe_Statement_Driver;
DROP INDEX IF EXISTS UX_DriverStatement_StatementDate;
DROP TABLE IF EXISTS DriverStatementDe;
DROP TABLE IF EXISTS DriverStatement;
DROP TABLE IF EXISTS Driver;

CREATE TABLE Driver
(
    id INTEGER NOT NULL,
    DriverTitle TEXT NOT NULL,
    OwnerTitle TEXT NOT NULL,
    PlateNumber TEXT NOT NULL,
    DefaultCommissionPercent DECIMAL(5,2) NOT NULL,
    IsActive INTEGER NOT NULL,
    CONSTRAINT PK_Driver PRIMARY KEY (id AUTOINCREMENT)
);

-- ========================================== --
-- Command id: 1185
-- Description: ایجاد جدول DriverStatement (سربرگ صورت‌وضعیت رانندگان). StatementDate تاریخ دستی صورت‌وضعیت است
-- ========================================== --
CREATE TABLE DriverStatement
(
    id INTEGER NOT NULL,
    StatementDate INTEGER NOT NULL,
    Userid INTEGER NOT NULL,
    CONSTRAINT PK_DriverStatement PRIMARY KEY (id AUTOINCREMENT),
    CONSTRAINT FK_DriverStatement_User FOREIGN KEY (Userid) REFERENCES [User] (id)
);

-- ========================================== --
-- Command id: 1186
-- Description: یکتایی تاریخ صورت‌وضعیت
-- ========================================== --
CREATE UNIQUE INDEX UX_DriverStatement_StatementDate ON DriverStatement (StatementDate);

-- ========================================== --
-- Command id: 1187
-- Description: ایجاد جدول DriverStatementDe (ردیف هر راننده در صورت‌وضعیت)
-- ========================================== --
CREATE TABLE DriverStatementDe
(
    id INTEGER NOT NULL,
    DriverStatementid INTEGER NOT NULL,
    Driverid INTEGER NOT NULL,
    NetAmount INTEGER NOT NULL,
    CommissionPercent DECIMAL(5,2) NOT NULL,
    CommissionAmount INTEGER NOT NULL,
    WaybillAmount INTEGER NOT NULL,
    OtherDeduction INTEGER NOT NULL,
    OtherDeductionDesc TEXT NULL,
    PrevMonthWaybill INTEGER NOT NULL,
    DebtPaymentAmount INTEGER NOT NULL,
    PayableAmount INTEGER NOT NULL,
    CompanyDebtBalance INTEGER NOT NULL,
    Note TEXT NULL,
    IsFinalConfirmed INTEGER NOT NULL,
    CONSTRAINT PK_DriverStatementDe PRIMARY KEY (id AUTOINCREMENT),
    CONSTRAINT FK_DriverStatementDe_DriverStatement FOREIGN KEY (DriverStatementid) REFERENCES DriverStatement (id),
    CONSTRAINT FK_DriverStatementDe_Driver FOREIGN KEY (Driverid) REFERENCES Driver (id)
);

-- ========================================== --
-- Command id: 1188
-- Description: یکتایی راننده در هر صورت‌وضعیت
-- ========================================== --
CREATE UNIQUE INDEX UX_DriverStatementDe_Statement_Driver ON DriverStatementDe (DriverStatementid, Driverid);