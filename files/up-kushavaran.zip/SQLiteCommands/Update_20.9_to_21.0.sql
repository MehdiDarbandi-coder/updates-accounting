﻿-- ========================================== --
-- Command id: 1058
-- Description: 
-- ========================================== --
DROP TABLE IF EXISTS TaxSystemTransactionHistory;
-- ========================================== --
-- Command id: 1059
-- Description: 
-- ========================================== --
DROP TABLE IF EXISTS TaxSystemTransactionHistory;
CREATE TABLE TaxElectronicLedger (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    FiscalPeriodid INTEGER NOT NULL,
    FromDate INTEGER,
    ToDate INTEGER,
    TransactionBy INTEGER NOT NULL,
    Status INTEGER NOT NULL,
    Description TEXT,
    PeriodType INTEGER NOT NULL,       
    FOREIGN KEY (FiscalPeriodid) REFERENCES FiscalPeriod(id) ON DELETE CASCADE
);
-- ========================================== --
-- Command id: 1060
-- Description: 
-- ========================================== --
UPDATE aOperation
SET Title = 'صورت سود و زیان'
WHERE Title = 'صورتحساب سود و زیان';