﻿-- ========================================== --
-- Command id: 1029
-- Description: 
-- ========================================== --
-- ایجاد هدر تنظیمات
INSERT INTO "aOperationsHeader" ("id", "Title") 
VALUES (5, 'تنظیمات مدیریتی');

-- ایجاد جزئیات هدر
INSERT INTO "aOperationsHeaderDe" ("id", "Headerid", "RowNumber", "Title") 
VALUES (22, 5, 1, 'تنظیمات مدیریتی');

-- به‌روزرسانی عملیات‌ها
UPDATE aOperation 
SET OnlyAdmin = 0, 
    HederDeid = 22
WHERE ModelView IN (
    'CheckStatusType',
    'AutoIssuanceGournalEntrySetting',
    'IncomeStatementSettings',
    'BalanceSheetSettings',
    'SettingView'
);

-- به‌روزرسانی مجوزهای کاربران
UPDATE UserOperationPermission 
SET Userid = (
    SELECT DISTINCT Userid 
    FROM UserOperationPermission 
    WHERE Operationsid = 38 
    LIMIT 1
)
WHERE Operationsid IN (
    SELECT id 
    FROM aOperation 
    WHERE ModelView IN (
        'CheckStatusType',
        'AutoIssuanceGournalEntrySetting', 
        'IncomeStatementSettings',
        'BalanceSheetSettings',
        'SettingView'
    )
);
-- ========================================== --
-- Command id: 1030
-- Description: 
-- ========================================== --
ALTER TABLE "EntryType" RENAME COLUMN "IsMerge" TO "IsMergeDebitSide";
ALTER TABLE "EntryType" ADD COLUMN "IsMergeCreditSide" INTEGER;
ALTER TABLE "EntryTypeDe" ADD COLUMN "DescriptionMethod" INTEGER;

UPDATE EntryType 
SET IsMergeDebitSide = 0 
WHERE IsMergeDebitSide IS NULL;

UPDATE EntryType 
SET IsMergeCreditSide = 0 
WHERE IsMergeCreditSide IS NULL;

UPDATE EntryTypeDe 
SET DescriptionMethod = 1 
WHERE DescriptionMethod IS NULL;
-- ========================================== --
-- Command id: 1031
-- Description: 
-- ========================================== --
UPDATE aOperation 
SET 
    Accounting = 1,
    Salary = 1,
    Sales = 1,
    ARAP = 1,
    Store = 1,
    Asset = 1
WHERE id IN (2, 73, 74, 5086, 5087);