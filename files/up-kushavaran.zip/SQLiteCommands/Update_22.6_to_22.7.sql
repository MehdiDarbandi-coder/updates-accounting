﻿-- ========================================= --
-- Command id: 1189
-- Description: ستون هش کلمه عبور کاربران (قالب Salt:Hash)
-- ========================================= --
ALTER TABLE "User" ADD COLUMN PasswordHash TEXT NULL;
-- ========================================= --
-- Command id: 1190
-- Description: الزام کاربر به تغییر کلمه عبور در اولین ورود (پیش‌فرض ۱ برای همه کاربران موجود)
-- ========================================= --
ALTER TABLE "User" ADD COLUMN MustChangePassword INTEGER NOT NULL DEFAULT 1;
-- ========================================= --
-- Command id: 1191
-- Description: پیام‌های پشتیبانی: حذف جدول قدیمی (در دریافت بعدی از اینترنت از نو ساخته می‌شود)
-- ========================================= --
DROP TABLE IF EXISTS DashAnnouncement;
-- ========================================= --
-- Command id: 1192
-- Description: پیام‌های پشتیبانی: ساخت جدول
-- ========================================= --
CREATE TABLE DashAnnouncement (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    FeedKey TEXT NOT NULL,
    Revision INTEGER NOT NULL DEFAULT 1,
    Body TEXT NOT NULL DEFAULT '',
    PublishedDate INTEGER NOT NULL,
    UpdatedDate INTEGER NOT NULL DEFAULT 0
);
-- ========================================= --
-- Command id: 1193
-- Description: پیام‌های پشتیبانی: ایندکس یکتای کلید فید
-- ========================================= --
CREATE UNIQUE INDEX UQ_DashAnnouncement_FeedKey ON DashAnnouncement (FeedKey);
-- ========================================= --
-- Command id: 1194
-- Description: پیام‌های پشتیبانی: ایندکس تاریخ انتشار
-- ========================================= --
CREATE INDEX IX_DashAnnouncement_PublishedDate ON DashAnnouncement (PublishedDate);
-- ========================================= --
-- Command id: 1195
-- Description: پیام‌های پشتیبانی: پاک کردن وضعیت دریافت تا همه‌ی پیام‌ها از نو دریافت شوند
-- ========================================= --
DELETE FROM DashAnnouncementSync;
-- ========================================= --
-- Command id: 1196
-- Description: خوانده‌شدن پیام‌های پشتیبانی برای هر کاربر: ساخت جدول
-- ========================================= --
CREATE TABLE DashAnnouncementUserState (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    AnnouncementId INTEGER NOT NULL,
    UserId INTEGER NOT NULL,
    IsRead INTEGER NOT NULL DEFAULT 0,
    ReadDate INTEGER NOT NULL DEFAULT 0
);
-- ========================================= --
-- Command id: 1197
-- Description: خوانده‌شدن پیام‌های پشتیبانی برای هر کاربر: ایندکس یکتا
-- ========================================= --
CREATE UNIQUE INDEX UQ_DashAnnouncementUserState ON DashAnnouncementUserState (UserId, AnnouncementId);
-- ========================================= --
-- Command id: 1198
-- Description: پیام کاربر به کاربر: ساخت جدول
-- ========================================= --
CREATE TABLE UserMessage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    FromUserId INTEGER NOT NULL,
    ToUserId INTEGER NOT NULL,
    Body TEXT NOT NULL,
    SentDate INTEGER NOT NULL,
    SentTime INTEGER NOT NULL DEFAULT 0,
    IsUrgent INTEGER NOT NULL DEFAULT 0,
    IsRead INTEGER NOT NULL DEFAULT 0,
    ReadDate INTEGER NOT NULL DEFAULT 0,
    ReadTime INTEGER NOT NULL DEFAULT 0
);
-- ========================================= --
-- Command id: 1199
-- Description: پیام کاربر به کاربر: ایندکس گیرنده و وضعیت خواندن
-- ========================================= --
CREATE INDEX IX_UserMessage_ToUserId_IsRead ON UserMessage (ToUserId, IsRead);
-- ========================================= --
-- Command id: 1200
-- Description: پیام کاربر به کاربر: ایندکس فرستنده
-- ========================================= --
CREATE INDEX IX_UserMessage_FromUserId ON UserMessage (FromUserId);
-- ========================================= --
-- Command id: 1201
-- Description: حضور کاربران (ورود، خروج، آنلاین): ساخت جدول
-- ========================================= --
CREATE TABLE UserPresence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    UserId INTEGER NOT NULL,
    IsOnline INTEGER NOT NULL DEFAULT 0,
    LoginDate INTEGER NOT NULL DEFAULT 0,
    LoginTime INTEGER NOT NULL DEFAULT 0,
    LogoutDate INTEGER NOT NULL DEFAULT 0,
    LogoutTime INTEGER NOT NULL DEFAULT 0,
    LastSeenDate INTEGER NOT NULL DEFAULT 0,
    LastSeenTime INTEGER NOT NULL DEFAULT 0,
    Beat INTEGER NOT NULL DEFAULT 0
);
-- ========================================= --
-- Command id: 1202
-- Description: حضور کاربران: ایندکس یکتای کاربر
-- ========================================= --
CREATE UNIQUE INDEX UQ_UserPresence_UserId ON UserPresence (UserId);
-- ========================================= --
-- Command id: 1203
-- Description: حضور کاربران: ایندکس یکتای کاربر
-- ========================================= --
UPDATE UserBrushThemDe
SET Color = CASE BrushThemid
    WHEN 3  THEN '#B3CFDB'
    WHEN 5  THEN '#FF9ED8BA'
    WHEN 6  THEN '#FFBF9DD1'
    WHEN 7  THEN '#FFD1AF9D'
    WHEN 8  THEN '#FF3A6E94'
    WHEN 9  THEN '#FF3A9462'
    WHEN 10 THEN '#FF7A3A94'
    WHEN 11 THEN '#FF3A5C94'
    WHEN 12 THEN '#8A8873'
    WHEN 13 THEN '#FF9DBCD1'
END
WHERE Brushid = 2024
  AND BrushThemid IN (3, 5, 6, 7, 8, 9, 10, 11, 12, 13);

UPDATE UserBrushThemDe
SET Color = '#13232B'
WHERE BrushThemid = 3 AND Brushid = 2025;
-- ========================================= --
-- Command id: 1204
-- Description: 
-- ========================================= --
ALTER TABLE "Company" ADD COLUMN StampImage TEXT NULL;