﻿-- ========================================== --
-- Command id: 1052
-- Description: 
-- ========================================== --
PRAGMA foreign_keys=off;

-- تغییر نام جدول اصلی به موقت
ALTER TABLE CheckTransfer RENAME TO CheckTransfer_old;

-- ایجاد جدول جدید با ستون NewLFiveid و تمام روابط
CREATE TABLE CheckTransfer (
    id               INTEGER PRIMARY KEY,
    Statusid         INTEGER NULL,
    Checkid          INTEGER NULL,
    PayCheckid       INTEGER NULL,
    LastStatusid     INTEGER NULL,
    TransferDate     INTEGER NOT NULL,
    NewLFid          INTEGER NULL,
    NewLFiveid       INTEGER NULL,
    GournalEntryid   INTEGER NULL,
    IsLast           BOOLEAN NOT NULL DEFAULT 0,

    FOREIGN KEY (Checkid) REFERENCES CashReceiptDeCheck(id) ON DELETE CASCADE,
    FOREIGN KEY (PayCheckid) REFERENCES CashPayDeCheck(id) ON DELETE CASCADE,
    FOREIGN KEY (GournalEntryid) REFERENCES GournalEntry(id) ON DELETE SET NULL,
    FOREIGN KEY (NewLFid) REFERENCES LF(id),
    FOREIGN KEY (NewLFiveid) REFERENCES LF(id),
    FOREIGN KEY (LastStatusid) REFERENCES CheckStatusType(id),
    FOREIGN KEY (Statusid) REFERENCES CheckStatusType(id)
);

-- برگرداندن داده‌های قدیمی
INSERT INTO CheckTransfer (
    id, Statusid, Checkid, PayCheckid, LastStatusid, 
    TransferDate, NewLFid, GournalEntryid, IsLast
)
SELECT 
    id, Statusid, Checkid, PayCheckid, LastStatusid, 
    TransferDate, NewLFid, GournalEntryid, IsLast
FROM CheckTransfer_old;

-- پاک کردن جدول موقت
DROP TABLE CheckTransfer_old;

PRAGMA foreign_keys=on;

-- ========================================== --
-- Command id: 1053
-- Description: 
-- ========================================== --
-- اضافه کردن ستون
ALTER TABLE StorageRate
ADD COLUMN StorageRateNumber INT NULL;
-- ========================================== --
-- Command id: 1054
-- Description: 
-- ========================================== --
-- مقداردهی ستون
UPDATE StorageRate
SET StorageRateNumber = (
    SELECT COUNT(*) + 10000
    FROM StorageRate AS SR2
    WHERE SR2.id <= StorageRate.id
);
-- ========================================== --
-- Command id: 1055
-- Description: 
-- ========================================== --
ALTER TABLE StorageRate DROP COLUMN ConfirmDate;
