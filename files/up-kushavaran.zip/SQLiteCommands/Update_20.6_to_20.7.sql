﻿-- ========================================== --
-- Command id: 1048
-- Description: Create TaxSystemTransactionHistory table with Foreign Key
-- ========================================== --
DROP TABLE IF EXISTS TaxSystemTransactionHistory;

-- ========================================== --
-- Command id: 1049
-- Description: Create TaxSystemTransactionHistory table with Foreign Key
-- ========================================== --
CREATE TABLE "TaxSystemTransactionHistory" (
	"id"	INTEGER,
	"FiscalPeriodid"	INTEGER NOT NULL,
	"FromDate"	INTEGER,
	"ToDate"	INTEGER,
	"TransactionBy"	INTEGER NOT NULL,
	"Status"	INTEGER NOT NULL,
	"Description"	TEXT,
	"DateGrouping"	INTEGER NOT NULL DEFAULT 0,
	FOREIGN KEY("FiscalPeriodid") REFERENCES "FiscalPeriod"("id"),
	PRIMARY KEY("id" AUTOINCREMENT)
);