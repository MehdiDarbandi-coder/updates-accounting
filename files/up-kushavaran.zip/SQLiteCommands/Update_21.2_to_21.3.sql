﻿-- ========================================== --
-- Command id: 1077
-- Description: 
-- ========================================== --
CREATE TABLE IF NOT EXISTS [CRMActivity]
(
    [id]                    INTEGER PRIMARY KEY AUTOINCREMENT,
    [ActivityNumber]        INTEGER NOT NULL,
    [Customerid]            INTEGER NOT NULL,
    [ActivityTypeid]        INTEGER NOT NULL,
    [Subject]               TEXT NOT NULL,
    [Description]           TEXT,
    [ActivityDate]          INTEGER NOT NULL,
    [ActivityTime]          TEXT,
    [FollowUpDate]          INTEGER,
    [FollowUpDescription]   TEXT,
    [Statusid]              INTEGER NOT NULL,
    [ActivityResultid]      INTEGER,
    [Priorityid]            INTEGER,
    [Userid]                INTEGER NOT NULL,
    [CreatedDate]           INTEGER NOT NULL,
    [IsDeleted]             INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT [FK_CRMActivity_Customer]
        FOREIGN KEY ([Customerid]) REFERENCES [Customer]([id]),

    CONSTRAINT [FK_CRMActivity_ActivityType]
        FOREIGN KEY ([ActivityTypeid]) REFERENCES [BatchDe]([id]),

    CONSTRAINT [FK_CRMActivity_Status]
        FOREIGN KEY ([Statusid]) REFERENCES [BatchDe]([id]),

    CONSTRAINT [FK_CRMActivity_Result]
        FOREIGN KEY ([ActivityResultid]) REFERENCES [BatchDe]([id]),

    CONSTRAINT [FK_CRMActivity_Priority]
        FOREIGN KEY ([Priorityid]) REFERENCES [BatchDe]([id]),

    CONSTRAINT [FK_CRMActivity_User]
        FOREIGN KEY ([Userid]) REFERENCES [User]([id])
);

CREATE UNIQUE INDEX IF NOT EXISTS [IX_CRMActivity_ActivityNumber]
ON [CRMActivity] ([ActivityNumber] DESC, [ActivityDate] DESC);
-- ========================================== --
-- Command id: 1078
-- Description: بازسازی جدول UserOperationPermission بدون FK به جدول حذف‌شده aOperation
-- ========================================== --
PRAGMA foreign_keys=off;

CREATE TABLE "UserOperationPermission_new" (
	"id"	INTEGER NOT NULL,
	"Userid"	INTEGER NOT NULL,
	"Operationsid"	INTEGER NOT NULL,
	"IsFavorite"	INTEGER NOT NULL,
	"BackgroundColor"	TEXT,
	"ForegroundColor"	TEXT,
	"ButtonStyle"	INTEGER,
	"LeftLocation"	REAL,
	"TopLocation"	REAL,
	CONSTRAINT "PK_UserOperationPermission" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_UserOperationPermission_User" FOREIGN KEY("Userid") REFERENCES "User"("id") ON DELETE CASCADE
);

INSERT INTO "UserOperationPermission_new" ("id", "Userid", "Operationsid", "IsFavorite", "BackgroundColor", "ForegroundColor", "ButtonStyle", "LeftLocation", "TopLocation")
SELECT "id", "Userid", "Operationsid", "IsFavorite", "BackgroundColor", "ForegroundColor", "ButtonStyle", "LeftLocation", "TopLocation"
FROM "UserOperationPermission";

DROP TABLE "UserOperationPermission";

ALTER TABLE "UserOperationPermission_new" RENAME TO "UserOperationPermission";

UPDATE sqlite_sequence SET name = 'UserOperationPermission' WHERE name = 'UserOperationPermission_new';

PRAGMA foreign_keys=on;

-- ========================================== --
-- Command id: 1079
-- Description: بازسازی جدول UserOperationPermissionToOther بدون FK به جدول حذف‌شده aOperation
-- ========================================== --
PRAGMA foreign_keys=off;

CREATE TABLE "UserOperationPermissionToOther_new" (
	"id"	INTEGER NOT NULL,
	"Userid"	INTEGER NOT NULL,
	"OtherUserid"	INTEGER NOT NULL,
	"Operationid"	INTEGER NOT NULL,
	"IsShow"	INTEGER NOT NULL,
	"IsEdite"	INTEGER NOT NULL,
	"IsDelete"	INTEGER NOT NULL,
	CONSTRAINT "FK_UserOperationPermissionToOther_User1" FOREIGN KEY("OtherUserid") REFERENCES "User"("id"),
	CONSTRAINT "FK_UserOperationPermissionToOther_User" FOREIGN KEY("Userid") REFERENCES "User"("id") ON DELETE CASCADE,
	CONSTRAINT "PK_UserOperationPermissionToOther" PRIMARY KEY("id" AUTOINCREMENT)
);

INSERT INTO "UserOperationPermissionToOther_new" ("id", "Userid", "OtherUserid", "Operationid", "IsShow", "IsEdite", "IsDelete")
SELECT "id", "Userid", "OtherUserid", "Operationid", "IsShow", "IsEdite", "IsDelete"
FROM "UserOperationPermissionToOther";

DROP TABLE "UserOperationPermissionToOther";

ALTER TABLE "UserOperationPermissionToOther_new" RENAME TO "UserOperationPermissionToOther";

UPDATE sqlite_sequence SET name = 'UserOperationPermissionToOther' WHERE name = 'UserOperationPermissionToOther_new';

PRAGMA foreign_keys=on;

-- ========================================== --
-- Command id: 1080
-- Description: حذف جداول قدیمی aOperation، aOperationsHeaderDe و aOperationsHeader (جایگزین شده با OperationCatalog در کد)
-- ========================================== --
PRAGMA foreign_keys=off;

DROP TABLE IF EXISTS "aOperation";
DROP TABLE IF EXISTS "aOperationsHeaderDe";
DROP TABLE IF EXISTS "aOperationsHeader";

PRAGMA foreign_keys=on;
-- ========================================== --
-- Command id: 1081
-- Description: اضافه نمودن ستون گروه بندی به جدول کالا
-- ========================================== --
ALTER TABLE "Kala" ADD COLUMN "KalaGroupid" INTEGER REFERENCES "BatchDe"("id");
-- ========================================== --
-- Command id: 1082
-- Description: اضافه نمودن ستون گروه بندی به جدول کالا
-- ========================================== --
ALTER TABLE "LFType" ADD COLUMN "Purpose" INTEGER NOT NULL DEFAULT 0;
-- ========================================== --
-- Command id: 1083
-- Description: 
-- ========================================== --
DROP TABLE IF EXISTS Bank;