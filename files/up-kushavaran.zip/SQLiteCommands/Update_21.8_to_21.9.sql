-- ========================================== --
-- Command id: 1148
-- Description: حذف ستون‌های رنگ از UserOperationPermission (نیاز به SQLite 3.35 به بالا)
-- ========================================== --
ALTER TABLE UserOperationPermission DROP COLUMN BackgroundColor;
ALTER TABLE UserOperationPermission DROP COLUMN ForegroundColor;

-- ========================================== --
-- Command id: 1149
-- Description: 
-- ========================================== --

DELETE FROM UserBrushThemDe WHERE Brushid = 53;

INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 1,  53, '#172840';     -- سرمه‌ای و طلایی
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 2,  53, '#2A1E19';     -- اسپرسو و مسی
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 3,  53, '#DAE2E6';     -- آبی آسمانی و نقره‌ای (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 4,  53, '#12343A';     -- یشمی و نقره‌ای پلاتینی
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 5,  53, '#FF1F7A4E';   -- زمرد درخشان (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 6,  53, '#FF5C1F7A';   -- ارکیده بنفش (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 7,  53, '#FF7A3F1F';   -- غروب زرین (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 8,  53, '#FF1B3649';   -- اعماق اقیانوس
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 9,  53, '#FF1B4933';   -- جنگل شبانه
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 10, 53, '#FF361B49';   -- بنفش شاهانه
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 11, 53, '#FF1B2B49';   -- دودی شبانه
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 12, 53, '#A9A897';     -- زیتونی خاکستری و برنز مات (تیره‌تر)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color) SELECT 13, 53, '#FF1F4F7A';   -- لاجورد اقیانوسی (تیره‌تر)

-- ========================================== --
-- Command id: 1150
-- Description: ایجاد جدول KalaStockLevel
-- ========================================== --
CREATE TABLE IF NOT EXISTS KalaStockLevel (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    Kalaid            INTEGER NOT NULL,
    Storeid           INTEGER NULL,
    MinQuantity       REAL    NOT NULL DEFAULT 0,
    ReorderPoint      REAL    NOT NULL DEFAULT 0,
    ReorderQuantity   REAL    NOT NULL DEFAULT 0,
    MaxQuantity       REAL    NULL,
    LeadTimeDays      INTEGER NULL,
    DefaultSupplierid INTEGER NULL,
    IsActive          INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT FK_KalaStockLevel_Kala     FOREIGN KEY (Kalaid)            REFERENCES Kala(id)     ON DELETE CASCADE,
    CONSTRAINT FK_KalaStockLevel_Store    FOREIGN KEY (Storeid)           REFERENCES Store(id)    ON DELETE CASCADE,
    CONSTRAINT FK_KalaStockLevel_Supplier FOREIGN KEY (DefaultSupplierid) REFERENCES Customer(id) ON DELETE SET NULL
);

-- ========================================== --
-- Command id: 1151
-- Description: 
-- ========================================== --
CREATE UNIQUE INDEX IF NOT EXISTS UX_KalaStockLevel_Kala_Store
    ON KalaStockLevel (Kalaid, Storeid)
    WHERE Storeid IS NOT NULL;

-- ========================================== --
-- Command id: 1152
-- Description: 
-- ========================================== --
CREATE UNIQUE INDEX IF NOT EXISTS UX_KalaStockLevel_Kala_AllStores
    ON KalaStockLevel (Kalaid)
    WHERE Storeid IS NULL;

-- ========================================== --
-- Command id: 1153
-- Description: (در SQLite بی‌اثر است؛ ستون ShowSubUnitInInvoice در Command 1165 تا 1168 تضمین می‌شود)
-- ========================================== --
SELECT 1;

-- ========================================== --
-- Command id: 1154
-- Description: ایجاد جدول اعلان‌های داشبورد (DashAnnouncement)
-- ========================================== --
CREATE TABLE IF NOT EXISTS DashAnnouncement
(
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    FeedKey        TEXT    NOT NULL,   -- شناسه‌ی یکتای آیتم در فید (فقط لاتین)
    Revision       INTEGER NOT NULL DEFAULT 1,
    Category       TEXT    NOT NULL,   -- Tip / Tutorial / News / Ad
    Title          TEXT    NOT NULL,
    Body           TEXT    NOT NULL DEFAULT '',
    LinkUrl        TEXT    NOT NULL DEFAULT '',
    ImageUrl       TEXT    NOT NULL DEFAULT '',
    Priority       INTEGER NOT NULL DEFAULT 0,
    PublishedDate  INTEGER NOT NULL,   -- yyyymmdd شمسی
    ExpiresDate    INTEGER NOT NULL DEFAULT 0,   -- 0 = بدون انقضا
    IsRead         INTEGER NOT NULL DEFAULT 0,
    IsStarred      INTEGER NOT NULL DEFAULT 0,
    IsHidden       INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS IX_DashAnnouncement_PublishedDate
    ON DashAnnouncement (PublishedDate);

CREATE UNIQUE INDEX IF NOT EXISTS UQ_DashAnnouncement_FeedKey
    ON DashAnnouncement (FeedKey);

-- ========================================== --
-- Command id: 1155
-- Description: ایجاد جدول همگام‌سازی اعلان‌های داشبورد (DashAnnouncementSync)
-- ========================================== --
CREATE TABLE IF NOT EXISTS DashAnnouncementSync
(
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ETag            TEXT    NOT NULL DEFAULT '',
    LastModified    TEXT    NOT NULL DEFAULT '',
    LastSuccessDate INTEGER NOT NULL DEFAULT 0   -- 0 = هنوز دریافت نشده
);

-- ========================================== --
-- Command id: 1156
-- Description: پاکسازی رنگ‌های داشبورد و BackgMainTabHeaderStrip (قابل اجرای مجدد)
-- ========================================== --
DELETE FROM UserBrushThemDe WHERE Brushid BETWEEN 2000 AND 2099;
DELETE FROM UserBrushThemDe WHERE Brushid = 53;

-- ========================================== --
-- Command id: 1157
-- Description: BackgMainTabHeaderStrip (53) - فقط تم‌های Scope 1
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT v.ThemeId, 53, v.Color
FROM (
    SELECT 1 AS ThemeId, '#FF202E41' AS Color
    UNION ALL SELECT 2, '#FF322723'
    UNION ALL SELECT 3, '#FFD5DDE2'
    UNION ALL SELECT 4, '#FF1C393D'
    UNION ALL SELECT 5, '#FF328A5E'
    UNION ALL SELECT 6, '#FF6C328A'
    UNION ALL SELECT 7, '#FF8A4F32'
    UNION ALL SELECT 8, '#FF233C4C'
    UNION ALL SELECT 9, '#FF234C38'
    UNION ALL SELECT 10, '#FF3E234C'
    UNION ALL SELECT 11, '#FF23304C'
    UNION ALL SELECT 12, '#FFACAB9C'
    UNION ALL SELECT 13, '#FF32658A'
) v
INNER JOIN UserBrushThem t ON t.id = v.ThemeId
WHERE t.Scope = 1;

-- ========================================== --
-- Command id: 1158
-- Description: داشبورد - رنگ‌های هماهنگ با صفحه اول (کپی از کلیدهای پوسته همان تم)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT d.BrushThemid, m.DashId, d.Color
FROM UserBrushThemDe d
INNER JOIN UserBrushThem t ON t.id = d.BrushThemid AND t.Scope = 1
INNER JOIN (
    SELECT 2000 AS DashId, 44 AS SourceBrush
    UNION ALL SELECT 2001, 46
    UNION ALL SELECT 2002, 50
    UNION ALL SELECT 2003, 43
    UNION ALL SELECT 2004, 45
    UNION ALL SELECT 2005, 45
    UNION ALL SELECT 2006, 2
    UNION ALL SELECT 2010, 51
    UNION ALL SELECT 2011, 50
    UNION ALL SELECT 2012, 13
    UNION ALL SELECT 2013, 14
    UNION ALL SELECT 2014, 37
    UNION ALL SELECT 2015, 38
    UNION ALL SELECT 2020, 43
    UNION ALL SELECT 2021, 10
    UNION ALL SELECT 2022, 44
    UNION ALL SELECT 2023, 35
    UNION ALL SELECT 2024, 13
    UNION ALL SELECT 2025, 14
    UNION ALL SELECT 2026, 1
    UNION ALL SELECT 2027, 3
    UNION ALL SELECT 2028, 15
    UNION ALL SELECT 2029, 3
    UNION ALL SELECT 2030, 50
) m ON m.SourceBrush = d.Brushid
WHERE d.Brushid < 100;

-- ========================================== --
-- Command id: 1159
-- Description: داشبورد - رنگ‌های ثابت (بوم شفاف، سایه، نشانگر، براق) - تم‌های Scope 1
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2007 AS BrushId, '#00FFFFFF' AS Color
    UNION ALL SELECT 2008, '#FF000000'
    UNION ALL SELECT 2016, '#FFFFFFFF'
    UNION ALL SELECT 2070, '#30FFFFFF'
    UNION ALL SELECT 2071, '#00FFFFFF'
) k
WHERE t.Scope = 1;

-- ========================================== --
-- Command id: 1160
-- Description: داشبورد - کارت‌های معنایی در تم‌های روشن Scope 1 (3, 5, 6, 7, 12, 13)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2040 AS BrushId, '#FFDBEAFE' AS Color
    UNION ALL SELECT 2041, '#FF1D4ED8'
    UNION ALL SELECT 2042, '#FF93C5FD'
    UNION ALL SELECT 2043, '#FFD1FAE5'
    UNION ALL SELECT 2044, '#FF047857'
    UNION ALL SELECT 2045, '#FF6EE7B7'
    UNION ALL SELECT 2046, '#FFFEF3C7'
    UNION ALL SELECT 2047, '#FFB45309'
    UNION ALL SELECT 2048, '#FFFCD34D'
    UNION ALL SELECT 2049, '#FFFEE2E2'
    UNION ALL SELECT 2050, '#FFB91C1C'
    UNION ALL SELECT 2051, '#FFFCA5A5'
) k
WHERE t.Scope = 1 AND t.id IN (3, 5, 6, 7, 12, 13);

-- ========================================== --
-- Command id: 1161
-- Description: داشبورد - کارت‌های معنایی در تم‌های تیره Scope 1 (بقیه)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2040 AS BrushId, '#FF26475E' AS Color
    UNION ALL SELECT 2041, '#FF8DBFE2'
    UNION ALL SELECT 2042, '#FF2E5876'
    UNION ALL SELECT 2043, '#FF204630'
    UNION ALL SELECT 2044, '#FF59C084'
    UNION ALL SELECT 2045, '#FF3C865B'
    UNION ALL SELECT 2046, '#FF503E21'
    UNION ALL SELECT 2047, '#FFD6AD66'
    UNION ALL SELECT 2048, '#FF98773E'
    UNION ALL SELECT 2049, '#FF502124'
    UNION ALL SELECT 2050, '#FFD36972'
    UNION ALL SELECT 2051, '#FF983E46'
) k
WHERE t.Scope = 1 AND t.id NOT IN (3, 5, 6, 7, 12, 13);

-- ========================================== --
-- Command id: 1162
-- Description: داشبورد - رنگ نمودار (2060-2067) تم‌های روشن Scope 1
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2060 AS BrushId, '#FF3B82F6' AS Color
    UNION ALL SELECT 2061, '#FF10B981'
    UNION ALL SELECT 2062, '#FFF59E0B'
    UNION ALL SELECT 2063, '#FF8B5CF6'
    UNION ALL SELECT 2064, '#FF14B8A6'
    UNION ALL SELECT 2065, '#FFEC4899'
    UNION ALL SELECT 2066, '#FF6366F1'
    UNION ALL SELECT 2067, '#FF9CA3AF'
) k
WHERE t.Scope = 1 AND t.id IN (3, 5, 6, 7, 12, 13);

-- ========================================== --
-- Command id: 1163
-- Description: داشبورد - رنگ نمودار (2060-2067) تم‌های تیره Scope 1 (پالت روشن‌تر)
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT t.id, k.BrushId, k.Color
FROM UserBrushThem t
CROSS JOIN (
    SELECT 2060 AS BrushId, '#FF60A5FA' AS Color
    UNION ALL SELECT 2061, '#FF34D399'
    UNION ALL SELECT 2062, '#FFFBBF24'
    UNION ALL SELECT 2063, '#FFA78BFA'
    UNION ALL SELECT 2064, '#FF2DD4BF'
    UNION ALL SELECT 2065, '#FFF472B6'
    UNION ALL SELECT 2066, '#FF818CF8'
    UNION ALL SELECT 2067, '#FFD1D5DB'
) k
WHERE t.Scope = 1 AND t.id NOT IN (3, 5, 6, 7, 12, 13);

-- ========================================== --
-- Command id: 1164
-- Description: ForegDashCanvasText (2009) - متن روی بوم (2007 شفاف) بر اساس روشنایی زمینه‌ی صفحه (برش 2) همان تم
-- زمینه روشن -> متن تیره | زمینه تیره -> متن روشن
-- ========================================== --
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT y.BrushThemid, 2009,
       CASE WHEN (0.299 * y.R + 0.587 * y.G + 0.114 * y.B) > 140
            THEN '#FF1F2937'
            ELSE '#FFF3F4F6'
       END
FROM (
    SELECT s.BrushThemid AS BrushThemid,
           (instr('0123456789ABCDEF', substr(s.C, s.O,     1)) - 1) * 16 + (instr('0123456789ABCDEF', substr(s.C, s.O + 1, 1)) - 1) AS R,
           (instr('0123456789ABCDEF', substr(s.C, s.O + 2, 1)) - 1) * 16 + (instr('0123456789ABCDEF', substr(s.C, s.O + 3, 1)) - 1) AS G,
           (instr('0123456789ABCDEF', substr(s.C, s.O + 4, 1)) - 1) * 16 + (instr('0123456789ABCDEF', substr(s.C, s.O + 5, 1)) - 1) AS B
    FROM (
        SELECT d.BrushThemid AS BrushThemid,
               UPPER(d.Color) AS C,
               CASE WHEN length(d.Color) = 9 THEN 4 ELSE 2 END AS O
        FROM UserBrushThemDe d
        INNER JOIN UserBrushThem t ON t.id = d.BrushThemid AND t.Scope = 1
        WHERE d.Brushid = 2
    ) s
) y;

-- ========================================== --
-- Command id: 1165
-- Description: بازسازی جدول Kala (۱/۴): ساخت جدول جدید Kala_new همراه با ستون ShowSubUnitInInvoice
-- ========================================== --
DROP TABLE IF EXISTS "Kala_new";
CREATE TABLE "Kala_new" (
	"id"	INTEGER NOT NULL,
	"SalesKalaid"	INTEGER,
	"Code"	TEXT NOT NULL,
	"Code2"	TEXT,
	"Title"	TEXT NOT NULL,
	"LFid"	INTEGER,
	"KalaTypeid"	INTEGER NOT NULL,
	"Technicalid"	TEXT,
	"DefultTax"	TEXT,
	"IsActive"	INTEGER NOT NULL,
	"IsShowInInvoice"	INTEGER,
	"IsShowInStorage"	INTEGER,
	"IsQualityControl"	INTEGER NOT NULL,
	"QualityType"	INTEGER,
	"PurchaseLTid"	INTEGER,
	"SaleLTid"	INTEGER,
	"KalaGroupid"	INTEGER,
	"Unitid"	INTEGER NOT NULL,
	"SubUnitid"	INTEGER,
	"ConversionFactor"	REAL,
	"ShowSubUnitInInvoice"	INTEGER NOT NULL DEFAULT 0,
	CONSTRAINT "PK_Kala" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_Kala_LF" FOREIGN KEY("LFid") REFERENCES "LF"("id"),
	CONSTRAINT "FK_Kala_LT1" FOREIGN KEY("SaleLTid") REFERENCES "LT"("id"),
	CONSTRAINT "FK_Kala_BatchDe" FOREIGN KEY("KalaTypeid") REFERENCES "BatchDe"("id"),
	CONSTRAINT "FK_Kala_SubUnit" FOREIGN KEY("SubUnitid") REFERENCES "Unit"("id"),
	FOREIGN KEY("KalaGroupid") REFERENCES "BatchDe"("id"),
	CONSTRAINT "FK_Kala_Kala" FOREIGN KEY("SalesKalaid") REFERENCES "Kala"("id"),
	CONSTRAINT "FK_Kala_LT" FOREIGN KEY("PurchaseLTid") REFERENCES "LT"("id"),
	CONSTRAINT "FK_Kala_Unit" FOREIGN KEY("Unitid") REFERENCES "Unit"("id")
);
-- ========================================== --
-- Command id: 1166
-- Description: بازسازی جدول Kala (۲/۴): کپی داده‌ها؛ مقدار ShowSubUnitInInvoice برای همه 0 است
-- ========================================== --
INSERT INTO "Kala_new" ("id", "SalesKalaid", "Code", "Code2", "Title", "LFid", "KalaTypeid", "Technicalid", "DefultTax", "IsActive", "IsShowInInvoice", "IsShowInStorage", "IsQualityControl", "QualityType", "PurchaseLTid", "SaleLTid", "KalaGroupid", "Unitid", "SubUnitid", "ConversionFactor", "ShowSubUnitInInvoice")
SELECT "id", "SalesKalaid", "Code", "Code2", "Title", "LFid", "KalaTypeid", "Technicalid", "DefultTax", "IsActive", "IsShowInInvoice", "IsShowInStorage", "IsQualityControl", "QualityType", "PurchaseLTid", "SaleLTid", "KalaGroupid", "Unitid", "SubUnitid", "ConversionFactor", 0 FROM "Kala";
-- ========================================== --
-- Command id: 1167
-- Description: بازسازی جدول Kala (۳/۴): حفظ شمارنده AUTOINCREMENT و حذف جدول قدیم Kala
-- ========================================== --
UPDATE sqlite_sequence
SET seq = (SELECT MAX(seq) FROM sqlite_sequence WHERE name = 'Kala')
WHERE name = 'Kala_new'
  AND EXISTS (SELECT 1 FROM sqlite_sequence WHERE name = 'Kala');
DROP TABLE "Kala";
-- ========================================== --
-- Command id: 1168
-- Description: بازسازی جدول Kala (۴/۴): تغییر نام Kala_new به Kala
-- ========================================== --
ALTER TABLE "Kala_new" RENAME TO "Kala";
