﻿-- ========================================== --
-- Command id: 1065
-- Description: 
-- ========================================== --
UPDATE aOperation
SET ModelView = 'TrialBalanseReport', IsActive = 1
WHERE id = 60;
-- ========================================== --
-- Command id: 1066
-- Description: 
-- ========================================== --
UPDATE aOperation
SET Salary = 1, Sales = 1, ARAP=1, Store=1, Asset=1
WHERE id = 73;
-- ========================================== --
-- Command id: 1067
-- Description: 
-- ========================================== --
UPDATE aOperation
SET ARAP=1, Store=0
WHERE id = 2;

-- ========================================== --
-- Command id: 1069
-- Description: 
-- ========================================== --
CREATE TABLE AccountComparisonReport
(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    RowNumber INTEGER NOT NULL,
    Title TEXT NOT NULL    
);

-- ========================================== --
-- Command id: 1070
-- Description: 
-- ========================================== --
CREATE INDEX IX_AccountComparisonReport_RowNumber
ON AccountComparisonReport (RowNumber);

-- ========================================== --
-- Command id: 1071
-- Description: 
-- ========================================== --
CREATE TABLE AccountComparisonReportDe
(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    AccountComparisonReportid INTEGER NOT NULL,
    RowNumber INTEGER NOT NULL,
    GLid INTEGER NULL,
    LTid INTEGER NULL,
    LFid INTEGER NULL,
    LFiveid INTEGER NULL,
    LSixid INTEGER NULL,
    ComparisonFactor INTEGER NOT NULL DEFAULT 1,
	Caption TEXT ,
    CONSTRAINT FK_AccountComparisonReportDe_Main
        FOREIGN KEY (AccountComparisonReportid)
        REFERENCES AccountComparisonReport(id)
        ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 1072
-- Description: 
-- ========================================== --
CREATE INDEX IX_AccountComparisonReportDe_RowNumber
ON AccountComparisonReportDe
(
    AccountComparisonReportid,
    RowNumber
);

-- ========================================== --
-- Command id: 1073
-- Description: 
-- ========================================== --
INSERT INTO aOperation (
    id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, 
    IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, 
    Accounting, Salary, Sales, ARAP, Store, Asset, 
    IsPermissionToOther, IsActive
)
SELECT 
    5088, 'گزارش های مقایسه ای', 'AccountComparisonReport', 9, 1, 0, 
    0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1
WHERE NOT EXISTS (SELECT 1 FROM aOperation WHERE id = 5088);

-- ========================================== --
-- Command id: 1074
-- Description: 
-- ========================================== --
INSERT INTO UserOperationPermission (
    Userid,
    Operationsid,
    IsFavorite,
    BackgroundColor,
    ForegroundColor,
    ButtonStyle,
    LeftLocation,
    TopLocation
)
SELECT 
    Userid,
    OP.Operationsid,
    0 AS IsFavorite,
    BackgroundColor,
    ForegroundColor,
    ButtonStyle,
    NULL AS LeftLocation,
    NULL AS TopLocation
FROM UserOperationPermission
CROSS JOIN (SELECT 5088 AS Operationsid UNION ALL SELECT 60) OP
WHERE UserOperationPermission.Operationsid = 31
  AND NOT EXISTS (
      SELECT 1 
      FROM UserOperationPermission UOP 
      WHERE UOP.Userid = UserOperationPermission.Userid 
        AND UOP.Operationsid = OP.Operationsid
  );