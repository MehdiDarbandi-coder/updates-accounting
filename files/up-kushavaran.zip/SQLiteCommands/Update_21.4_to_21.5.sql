﻿-- ========================================== --
-- Command id: 1112
-- Description: تغییر نام جدول قبلی Company به Company_Old
-- ========================================== --
ALTER TABLE "Company" RENAME TO "Company_Old";

-- ========================================== --
-- Command id: 1113
-- Description: ساخت جدول جدید Company (ادغام‌شده حسابداری + حقوق و دستمزد)
-- ========================================== --
CREATE TABLE "Company" (
	"id"	INTEGER NOT NULL,
	"CompanyName"	TEXT NOT NULL,
	"RealPerson"	INTEGER NOT NULL,
	"CompanyType"	TEXT,
	"AgentFullName"	TEXT,
	"idNumber"	TEXT,
	"EconomicalNumber"	TEXT,
	"Ostan"	TEXT,
	"City"	TEXT,
	"TaxId"	TEXT,
	"TaxCaseNum"	TEXT,
	"TaxUnitNum"	TEXT,
	"TaxOfficNam"	TEXT,
	"TaxBrnchNam"	TEXT,
	"TaxBrnchNum"	TEXT,
	"InsurWorkNam"	TEXT,
	"InsurBrnchNam"	TEXT,
	"InsurWorkNum"	TEXT,
	"InsurBrnchCode"	TEXT,
	"InsurContractRow"	TEXT,
	"InsurRate"	INTEGER,
	"HardshipInsurRate"	INTEGER,
	"PkeyAddress"	TEXT,
	"Address"	TEXT,
	"PostalCode"	TEXT,
	"TellNumber"	TEXT,
	"FaxNumber"	TEXT,
	"Logo"	TEXT,
	"FirstInvoiceNumber"	INTEGER,
	"WebSite"	TEXT,
	CONSTRAINT "PK_Company" PRIMARY KEY("id" AUTOINCREMENT)
);

-- ========================================== --
-- Command id: 1114
-- Description: انتقال داده‌ها از جدول قبلی Company_Old به جدول جدید Company
-- ========================================== --
INSERT INTO "Company" (
	"id", "CompanyName", "RealPerson", "idNumber", "EconomicalNumber",
	"Ostan", "City", "TaxId", "PkeyAddress", "Address", "PostalCode",
	"TellNumber", "FaxNumber", "Logo", "FirstInvoiceNumber", "WebSite"
)
SELECT
	"id", "CompanyName", "RealPerson", "idNumber", "EconomicalNumber",
	"Ostan", "City", "TaxId", "PkeyAddress", "Address", "PostalCode",
	"TellNumber", "FaxNumber", "Logo", "FirstInvoiceNumber", "WebSite"
FROM "Company_Old";

-- ========================================== --
-- Command id: 1115
-- Description: حذف جدول قبلی Company_Old
-- ========================================== --
DROP TABLE "Company_Old";

-- ========================================== --
-- Command id: 1116
-- Description: ساخت جدول EmployerBank با ارتباط به LF
-- ========================================== --
CREATE TABLE "EmployerBank" (
	"id"	INTEGER NOT NULL,
	"BankTypeid"	INTEGER,
	"AccountNumber"	TEXT NOT NULL,
	"ShebaNumber"	TEXT,
	"IsActive"	INTEGER NOT NULL,
	"LFid"	INTEGER,
	CONSTRAINT "FK_EmployerBank_LF" FOREIGN KEY("LFid") REFERENCES "LF"("id"),
	CONSTRAINT "PK_EmployerBank" PRIMARY KEY("id" AUTOINCREMENT)
);

-- ========================================== --
-- Command id: 1117
-- Description: ساخت جدول InsuranceJob
-- ========================================== --
CREATE TABLE "InsuranceJob" (
	"id"	INTEGER NOT NULL,
	"Code"	TEXT NOT NULL,
	"Title"	TEXT NOT NULL,
	"IsActive"	INTEGER NOT NULL DEFAULT 1,
	CONSTRAINT "PK_InsurJob" PRIMARY KEY("id" AUTOINCREMENT)
);


-- ========================================== --
-- Command id: 1119
-- Description: ساخت جدول TaxTable
-- ========================================== --
CREATE TABLE "TaxTable" (
	"id"	INTEGER NOT NULL,
	"Year"	INTEGER NOT NULL,
	"TaxableAmount0Percent"	INTEGER NOT NULL,
	"TaxableAmount10Percent"	INTEGER NOT NULL,
	"TaxableAmount15Percent"	INTEGER NOT NULL,
	"TaxableAmount20Percent"	INTEGER NOT NULL,
	"TaxableAmount25Percent"	INTEGER,
	CONSTRAINT "PK_TaxTable" PRIMARY KEY("id" AUTOINCREMENT)
);

-- ========================================== --
-- Command id: 1120
-- Description: ساخت جدول SalaryItemExecution
-- ========================================== --
CREATE TABLE "SalaryItemExecution" (
	"id"	INTEGER NOT NULL,
	"Description"	TEXT,
	"ExecutionDate"	INTEGER NOT NULL,
	CONSTRAINT "PK_SalaryItemExecution" PRIMARY KEY("id" AUTOINCREMENT)
);

-- ========================================== --
-- Command id: 1121
-- Description: ساخت جدول Personnel با ارتباط به LF
-- ========================================== --
CREATE TABLE "Personnel" (
	"id"	INTEGER NOT NULL,
	"Code"	TEXT NOT NULL,
	"ClockCode"	TEXT,
	"LastName"	TEXT NOT NULL,
	"FirstName"	TEXT NOT NULL,
	"FathrName"	TEXT,
	"MelliNumber"	TEXT,
	"Gender"	INTEGER NOT NULL,
	"Nationality"	INTEGER NOT NULL,
	"BirthCertificateNumber"	TEXT,
	"BrthDate"	INTEGER,
	"BrthPlace"	TEXT,
	"RegstPlace"	TEXT,
	"BirthCertificateIssueDate"	INTEGER,
	"CitizenshipCountryCode"	TEXT,
	"ResidenceCountryCode"	TEXT,
	"EmploymentStartDate"	INTEGER,
	"EmploymentEndDate"	INTEGER,
	"RetirementDate"	INTEGER,
	"IsActive"	INTEGER NOT NULL,
	"PayIsActive"	INTEGER NOT NULL,
	"LFid"	INTEGER,
	CONSTRAINT "FK_Personnel_LF" FOREIGN KEY("LFid") REFERENCES "LF"("id"),
	CONSTRAINT "PK_Personnel" PRIMARY KEY("id" AUTOINCREMENT)
);

-- ========================================== --
-- Command id: 1122
-- Description: ساخت جدول PersonnelBank
-- ========================================== --
CREATE TABLE "PersonnelBank" (
	"id"	INTEGER NOT NULL,
	"Personnelid"	INTEGER NOT NULL,
	"BankTypeid"	INTEGER NOT NULL,
	"AccountNumber"	TEXT NOT NULL,
	"ShebaNumber"	TEXT,
	"Notes"	TEXT,
	"IsActive"	INTEGER NOT NULL,
	CONSTRAINT "PK_PersonnelBank" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_PersonnelBank_Personnel" FOREIGN KEY("Personnelid") REFERENCES "Personnel"("id") ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 1123
-- Description: ساخت جدول Contract
-- ========================================== --
CREATE TABLE "Contract" (
	"id"	INTEGER NOT NULL,
	"Personnelid"	INTEGER NOT NULL,
	"ContractType"	INTEGER NOT NULL,
	"Bankid"	INTEGER,
	"ContractNumber"	INTEGER NOT NULL,
	"CreationDate"	INTEGER NOT NULL,
	"StartDate"	INTEGER NOT NULL,
	"EndDate"	INTEGER,
	"TerminationDate"	INTEGER,
	"DailyBaseAmount"	INTEGER NOT NULL,
	"DailySanavatBaseAmount"	INTEGER NOT NULL,
	"MobileNumber"	TEXT,
	"Address"	TEXT,
	"PostalCode"	TEXT,
	"InnerJobTitle"	TEXT,
	"WorkPlace"	TEXT,
	"Notes"	TEXT,
	"InsurType"	INTEGER,
	"InsurName"	TEXT,
	"InsurNumber"	TEXT,
	"InsuranceJobid"	INTEGER,
	"FreeTaxType"	INTEGER,
	"JobCategory"	INTEGER,
	"WorkPlaceStatus"	INTEGER,
	"LastEducation"	INTEGER,
	"BudgetLawException1403"	INTEGER,
	"EmploymentType"	INTEGER,
	"IsMarried"	INTEGER NOT NULL,
	"NumberOfChildren"	INTEGER NOT NULL,
	"BaseChildAmount"	INTEGER NOT NULL,
	"BaseHousAmount"	INTEGER NOT NULL,
	"BaseMarryAmount"	INTEGER NOT NULL,
	"BaseFoodAmount"	INTEGER NOT NULL,
	"BaseWorkerBenAmount"	INTEGER NOT NULL,
	"IsTaxable"	INTEGER NOT NULL DEFAULT 0,
	"IsInsurable"	INTEGER NOT NULL DEFAULT 0,
	"IsBimeShodeAsli"	INTEGER NOT NULL DEFAULT 0,
	"IsUnempInsured"	INTEGER NOT NULL DEFAULT 0,
	"IsHardshipInsurable"	INTEGER NOT NULL DEFAULT 0,
	CONSTRAINT "PK_Contract" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_Contract_Personnel" FOREIGN KEY("Personnelid") REFERENCES "Personnel"("id") ON DELETE CASCADE,
	CONSTRAINT "FK_Contract_PersonnelBank" FOREIGN KEY("Bankid") REFERENCES "PersonnelBank"("id"),
	CONSTRAINT "FK_Contract_InsuranceJob" FOREIGN KEY("InsuranceJobid") REFERENCES "InsuranceJob"("id")
);

-- ========================================== --
-- Command id: 1124
-- Description: ساخت جدول Loan
-- ========================================== --
CREATE TABLE "Loan" (
	"id"	INTEGER NOT NULL,
	"Personnelid"	INTEGER NOT NULL,
	"Title"	TEXT NOT NULL,
	"LoanNumber"	INTEGER NOT NULL,
	"InitialLoanBalanceAmount"	INTEGER NOT NULL,
	"InstallmentAmount"	INTEGER NOT NULL,
	"StartPeriod"	INTEGER NOT NULL,
	"TotslInstallmentPaidAmount"	INTEGER NOT NULL,
	"Description"	TEXT,
	"AdjustmentStartPeriod"	INTEGER,
	"AdjustmentEndPeriod"	INTEGER,
	"AdjustmentAmount"	INTEGER,
	"FinalRepaymentPeriod"	INTEGER,
	CONSTRAINT "PK_Loan" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_Loan_Personnel" FOREIGN KEY("Personnelid") REFERENCES "Personnel"("id")
);

-- ========================================== --
-- Command id: 1125
-- Description: ساخت جدول Period
-- ========================================== --
CREATE TABLE "Period" (
	"id"	INTEGER NOT NULL,
	"ManagementMessageTitle"	TEXT,
	"ManagementMessage"	TEXT,
	"IsFinalized"	INTEGER NOT NULL,
	CONSTRAINT "PK_Period" PRIMARY KEY("id")
);

-- ========================================== --
-- Command id: 1126
-- Description: ساخت جدول LoanRepayment
-- ========================================== --
CREATE TABLE "LoanRepayment" (
	"id"	INTEGER NOT NULL,
	"Loanid"	INTEGER NOT NULL,
	"Periodid"	INTEGER NOT NULL,
	"Personnelid"	INTEGER NOT NULL,
	"InstallmentAmount"	INTEGER NOT NULL,	
	CONSTRAINT "PK_LoanRepayment" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_LoanRepayments_Loan" FOREIGN KEY("Loanid") REFERENCES "Loan"("id"),
	CONSTRAINT "FK_LoanRepayment_Period" FOREIGN KEY("Periodid") REFERENCES "Period"("id") ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 1127
-- Description: ساخت جدول Payment
-- ========================================== --
CREATE TABLE "Payment" (
	"id"	INTEGER NOT NULL,
	"Periodid"	INTEGER NOT NULL,
	"PaymentType"	INTEGER NOT NULL,
	"PaymentDate"	INTEGER,
	"PaymentNumber"	INTEGER NOT NULL,
	"EmployerBankid"	INTEGER NOT NULL,
	"Description"	TEXT,
	"IsFinalized"	INTEGER NOT NULL,
	CONSTRAINT "PK_Payment" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_Payment_EmployerBank" FOREIGN KEY("EmployerBankid") REFERENCES "EmployerBank"("id"),
	CONSTRAINT "FK_Payment_Period" FOREIGN KEY("Periodid") REFERENCES "Period"("id") ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 1128
-- Description: ساخت جدول PaymentDe
-- ========================================== --
CREATE TABLE "PaymentDe" (
	"id"	INTEGER NOT NULL,
	"Paymentid"	INTEGER NOT NULL,
	"Personnelid"	INTEGER,
	"PersonnelBankid"	INTEGER,
	"Amount"	INTEGER,
	CONSTRAINT "PK_PaymentDe" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_PaymentDe_Payment" FOREIGN KEY("Paymentid") REFERENCES "Payment"("id") ON DELETE CASCADE,
	CONSTRAINT "FK_PaymentDe_Personnel" FOREIGN KEY("Personnelid") REFERENCES "Personnel"("id"),
	CONSTRAINT "FK_PaymentDe_PersonnelBank" FOREIGN KEY("PersonnelBankid") REFERENCES "PersonnelBank"("id")
);

-- ========================================== --
-- Command id: 1129
-- Description: ساخت جدول SalaryItem
-- ========================================== --
CREATE TABLE "SalaryItem" (
	"id"	INTEGER NOT NULL,
	"SalaryItemExecutionid"	INTEGER NOT NULL,
	"Itemid"	INTEGER NOT NULL,
	"RowNumber"	INTEGER NOT NULL,
	"AllowSetIsActive"	INTEGER NOT NULL,
	"IsActive"	INTEGER NOT NULL,
	"IsAdding"	INTEGER NOT NULL,
	"AllowSetTitle"	INTEGER NOT NULL,
	"Title"	TEXT NOT NULL,
	"AllowSetFixed"	INTEGER NOT NULL,
	"IsFixed"	INTEGER NOT NULL,
	"AllowSetIsOnLegalList"	INTEGER NOT NULL,
	"IsOnLegalList"	INTEGER NOT NULL,
	"AllowSetIsTaxableOrIsInsurable"	INTEGER NOT NULL,
	"IsInsurable"	INTEGER NOT NULL,
	"TaxItemTypeid"	INTEGER,
	"IsTenPercentTaxable"	INTEGER,
	"AllowSetRedemptionable"	INTEGER NOT NULL,
	"IsLeavable"	INTEGER NOT NULL,
	"IsEidiable"	INTEGER NOT NULL,
	"IsSanavatable"	INTEGER NOT NULL,
	"AllowSetIsCopyOfPrevious"	INTEGER NOT NULL,
	"IsCopyOfPrevious"	INTEGER NOT NULL,
	"Description"	TEXT,
	CONSTRAINT "PK_SalaryItem" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_SalaryItem_SalaryItemExecution" FOREIGN KEY("SalaryItemExecutionid") REFERENCES "SalaryItemExecution"("id") ON DELETE CASCADE
);

-- ========================================== --
-- Command id: 1130
-- Description: ساخت جدول WorkPeriodic
-- ========================================== --
CREATE TABLE "WorkPeriodic" (
	"id"	INTEGER NOT NULL,
	"Periodid"	INTEGER NOT NULL,
	"Personnelid"	INTEGER,
	"Contractid"	INTEGER NOT NULL,
	"IsTaxable"	INTEGER NOT NULL,
	"IsInsurable"	INTEGER NOT NULL,
	"IsBimeShodeAsli"	INTEGER NOT NULL,
	"IsUnempInsured"	INTEGER NOT NULL,
	"IsHardshipInsurable"	INTEGER NOT NULL,
	"DailyBaseAmount"	INTEGER NOT NULL,
	"DailySanavatBaseAmount"	INTEGER NOT NULL,
	"BaseHousAmount"	INTEGER NOT NULL,
	"BaseMarryAmount"	INTEGER NOT NULL,
	"BaseWorkerBenAmount"	INTEGER NOT NULL,
	"BaseFoodAmount"	INTEGER NOT NULL,
	"BaseChildAmount"	INTEGER NOT NULL,
	"CostCenterid"	INTEGER NOT NULL,
	"WorkDays"	INTEGER NOT NULL,
	"ShiftDays"	INTEGER NOT NULL,
	"ShiftPercentage"	INTEGER NOT NULL,
	"NightWorkByMinutes"	INTEGER NOT NULL,
	"OvertimeByMinutes"	INTEGER NOT NULL,
	"FridayOvertimeByMinutes"	INTEGER NOT NULL,
	"MissionDays"	REAL NOT NULL,
	"DeductedByMinutes"	INTEGER NOT NULL,
	"LeaveDays"	INTEGER NOT NULL,
	"LeaveByMinutes"	INTEGER NOT NULL,
	"LeaveBalanceByMinutes"	INTEGER NOT NULL,
	"AdjLeaveByMinutes"	INTEGER NOT NULL,
	"SickLeaveDays"	INTEGER NOT NULL,
	"RedemptionLeaveDailyBaseAmount"	INTEGER NOT NULL,
	"RedemptionEidiDailyBaseAmount"	INTEGER NOT NULL,
	"RedemptionSanavatDailyBaseAmount"	INTEGER NOT NULL,
	"MissionAmount"	INTEGER NOT NULL,
	"MissionExpenseAmount"	INTEGER NOT NULL,
	"BaseCustomAmount1"	INTEGER NOT NULL,
	"BaseCustomAmount2"	INTEGER NOT NULL,
	"BaseCustomAmount3"	INTEGER NOT NULL,
	"BaseCustomAmount4"	INTEGER NOT NULL,
	"BaseCustomAmount5"	INTEGER NOT NULL,
	"BaseCustomAmount6"	INTEGER NOT NULL,
	"BaseCustomAmount7"	INTEGER NOT NULL,
	"BaseCustomAmount8"	INTEGER NOT NULL,
	"BaseCustomAmount9"	INTEGER NOT NULL,
	"BaseCustomAmount10"	INTEGER NOT NULL,
	"OtherAmount"	INTEGER NOT NULL,
	"NonCashBenAmount"	INTEGER NOT NULL,
	"SalaryAdvanceAmount"	INTEGER NOT NULL,
	"ExtraInsAmount"	INTEGER NOT NULL,
	"CustomAdjAmount1"	INTEGER NOT NULL,
	"CustomAdjAmount2"	INTEGER NOT NULL,
	"CustomAdjAmount3"	INTEGER NOT NULL,
	"CustomAdjAmount4"	INTEGER NOT NULL,
	"CustomAdjAmount5"	INTEGER NOT NULL,
	"CustomAdjAmount6"	INTEGER NOT NULL,
	"CustomAdjAmount7"	INTEGER NOT NULL,
	"CustomAdjAmount8"	INTEGER NOT NULL,
	"LoanInstallAmount"	INTEGER NOT NULL,
	"TaxAmount"	INTEGER NOT NULL,
	"CustomTaxAmount"	INTEGER,
	"RedemptionTaxAmount"	INTEGER NOT NULL,
	"PreviousDebtAmount"	INTEGER NOT NULL,
	"OtherAdjAmount"	INTEGER NOT NULL,
	"InsurableSalaryAndBenefitsAmount"	INTEGER NOT NULL,
	"TaxableSalaryAmount"	INTEGER NOT NULL,
	"SanavatBalanceByDays"	REAL NOT NULL,
	"AdjSanavatByDays"	REAL NOT NULL,
	"RedemptionSanavatByDays"	REAL NOT NULL,
	"EidiBalanceByDays"	REAL NOT NULL,
	"RedemptionEidiByDays"	REAL NOT NULL,
	"RedemptionCustomAmount1"	INTEGER NOT NULL,
	"RedemptionCustomAmount2"	INTEGER NOT NULL,
	"RedemptionCustomAdjAmount1"	INTEGER NOT NULL,
	"RedemptionLeaveByMinutes"	INTEGER NOT NULL,
	"AdjEidiByDays"	REAL NOT NULL,
	"CustomAmount1"	INTEGER NOT NULL DEFAULT 0,
	"CustomAmount2"	INTEGER NOT NULL DEFAULT 0,
	"CustomAmount3"	INTEGER NOT NULL DEFAULT 0,
	"CustomAmount4"	INTEGER NOT NULL DEFAULT 0,
	"CustomAmount5"	INTEGER NOT NULL DEFAULT 0,
	"CustomAmount6"	INTEGER NOT NULL DEFAULT 0,
	"CustomAmount7"	INTEGER NOT NULL DEFAULT 0,
	"CustomAmount8"	INTEGER NOT NULL DEFAULT 0,
	"CustomAmount9"	INTEGER NOT NULL DEFAULT 0,
	"CustomAmount10"	INTEGER NOT NULL DEFAULT 0,
	CONSTRAINT "PK_WorkPeriodic" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_WorkPeriodic_Period" FOREIGN KEY("Periodid") REFERENCES "Period"("id") ON DELETE CASCADE,
	CONSTRAINT "FK_WorkPeriodic_CostCenter" FOREIGN KEY("CostCenterid") REFERENCES "CostCenter"("id"),
	CONSTRAINT "FK_WorkPeriodic_Contract" FOREIGN KEY("Contractid") REFERENCES "Contract"("id"),
	CONSTRAINT "FK_WorkPeriodic_Personnel" FOREIGN KEY("Personnelid") REFERENCES "Personnel"("id")
);
-- ========================================== --
-- Command id: 1131
-- Description: ایجاد اولین رکورد
-- ========================================== --
INSERT INTO "Period" ("id", "ManagementMessageTitle", "ManagementMessage", "IsFinalized")
VALUES (14050131, NULL, NULL, 0);
-- ========================================== --
-- Command id: 1132
-- Description: ایجاد اولین رکورد
-- ========================================== --
INSERT INTO "SalaryItemExecution" ("id", "Description", "ExecutionDate")
VALUES (1, 'تنظیمات اولیه', 14050131);
-- ========================================== --
-- Command id: 1133
-- Description: ایجاد اولین رکورد
-- ========================================== --
INSERT INTO "SalaryItem" ("id","SalaryItemExecutionid","Itemid","RowNumber","AllowSetIsActive","IsActive","IsAdding","AllowSetTitle","Title","AllowSetFixed","IsFixed","AllowSetIsOnLegalList","IsOnLegalList","AllowSetIsTaxableOrIsInsurable","IsInsurable","TaxItemTypeid","IsTenPercentTaxable","AllowSetRedemptionable","IsLeavable","IsEidiable","IsSanavatable","AllowSetIsCopyOfPrevious","IsCopyOfPrevious","Description") VALUES
(1,1,0,0,0,1,1,0,'حقوق پایه',0,0,0,1,0,1,7,0,1,1,1,1,0,0,'مبلغ آن در قرارداد پرسنلی بصورت روزانه تعیین می شود.'),
(2,1,1,1,0,1,1,0,'پایه سنواتی',0,0,0,1,0,1,7,0,1,1,1,1,0,0,'مبلغ آن در قرارداد پرسنلی بصورت روزانه تعیین می شود.'),
(3,1,2,2,1,1,1,0,'نوبت#کاری',0,0,1,1,0,1,7,1,0,0,0,0,0,0,'مبلغ نوبت‌کاری >>> (حقوق پایه روزانه + پایه سنواتی) × تعداد روزهای نوبت‌کاری × درصد نوبت‌کاری'),
(4,1,3,3,1,0,1,0,'شب#کاری',0,0,1,0,0,1,7,0,0,0,0,0,0,0,'مبلغ شب‌کاری >>> (حقوق پایه روزانه + پایه سنواتی) ÷ 440 × مجموع دقایق شب کاری × 1.35'),
(5,1,4,4,1,1,1,0,'حق#ماموریت',0,0,1,1,0,0,19,1,0,0,0,0,0,0,'مبلغ ماموریت >>> (حقوق پایه روزانه + پایه سنواتی) × تعداد روزهای ماموریت'),
(6,1,5,5,1,0,1,0,'هزینه#سفر',0,1,1,1,0,0,18,1,0,0,0,0,0,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(7,1,6,6,1,1,1,0,'اضافه کار#عادی',0,0,1,1,0,1,17,1,0,0,0,0,0,0,'مبلغ اضافه کار عادی >>> (حقوق پایه روزانه + پایه سنواتی) ÷ 440 × مجموع دقایق اضافه کار عادی × 1.4'),
(8,1,7,7,1,1,1,0,'اضافه کار#جمعه',0,0,1,1,0,1,17,1,0,0,0,0,0,0,'مبلغ اضافه کار جمعه >>> (((حقوق پایه روزانه + پایه سنواتی) ÷ 440 ) × مجموع دقایق اضافه کار عادی) × ( 1 + (0.4 + 0.4 ))'),
(9,1,8,8,0,1,1,0,'بن#کارگری',0,0,1,1,0,1,38,1,1,0,0,0,0,0,'مبلغ بن کارگری>>> ( مبلغ بن کارگری در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
(10,1,9,9,0,1,1,0,'حق#مسکن',0,0,1,1,0,1,38,1,1,0,0,0,0,0,'مبلغ حق مسکن>>> ( مبلغ  حق مسکن در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
(11,1,10,10,0,1,1,0,'حق#تاهل',0,0,1,1,0,1,38,1,1,0,0,0,0,0,'مبلغ حق تاهل>>> ( مبلغ  حق تاهل در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
(12,1,11,11,0,1,1,0,'حق#اولاد',0,0,1,1,0,0,38,1,1,0,0,0,0,0,'مبلغ حق اولاد>>> ( مبلغ  حق اولاد در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
(13,1,12,12,0,1,1,0,'حق#خواروبار',0,0,1,1,0,1,38,1,1,0,0,0,0,0,'مبلغ حق خواروبار>>> ( مبلغ  حق خواروبار در قرارداد ÷ تعداد روزهای ماه )  × تعداد روزهای کارکرد'),
(14,1,13,13,1,0,1,1,'حق 1',1,0,1,0,1,0,38,1,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(15,1,14,14,1,0,1,1,'حق 2',1,0,1,0,1,0,38,0,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(16,1,15,15,1,0,1,1,'حق 3',1,0,1,0,1,0,38,1,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(17,1,16,16,1,0,1,1,'حق 4',1,0,1,0,1,0,38,1,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(18,1,17,17,1,0,1,1,'حق 5',1,0,1,0,1,0,38,1,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(19,1,18,18,1,0,1,1,'حق 6',1,0,1,0,1,0,38,1,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(20,1,19,19,1,0,1,1,'حق 7',1,0,1,0,1,0,38,1,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(21,1,20,20,1,0,1,1,'حق 8',1,0,1,0,1,0,38,1,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(22,1,21,21,1,0,1,1,'حق 9',1,0,1,0,1,0,38,1,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(23,1,22,22,1,0,1,1,'حق10',1,0,1,0,1,0,38,1,1,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(24,1,23,23,1,1,1,0,'بن غیر نقدی',0,1,1,1,0,0,31,0,0,0,0,0,0,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(25,1,24,24,1,1,1,0,'سایر اضافات',0,1,1,1,1,0,38,0,0,0,0,0,0,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(26,1,25,25,0,1,0,0,'مالیات#حقوق',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,'مبلغ آن در کارکرد ماهیانه با توجه به جدول مالیاتی  و مالیات پذیری آیتمهای حقوقی ، توسط برنامه محاسبه می شود.'),
(27,1,26,26,0,1,0,0,'بیمه#سهم کارگر',0,1,0,0,0,1,33,0,0,0,0,0,0,0,'مبلغ آن در کارکرد ماهیانه با توجه به بیمه پذیری آیتمهای حقوقی ، توسط برنامه محاسبه می شود.'),
(28,1,27,27,1,1,0,0,'قسط وام',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,'مبلغ آن در کارکرد ماهیانه با توجه به جدول وام های پرسنلی ،توسط برنامه درج می گردد.'),
(29,1,28,28,1,1,0,0,'کسر کار',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,'مبلغ کسرکار >>> (حقوق پایه روزانه + پایه سنواتی) ÷ 480 × مجموع دقایق کسرکار'),
(30,1,29,29,1,1,0,0,'مساعده',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(31,1,30,30,1,0,0,0,'بیمه#تکمیلی',0,1,0,0,0,1,34,0,0,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(32,1,31,31,1,0,0,1,'کسور 1',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(33,1,32,32,1,0,0,1,'کسور 2',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(34,1,33,33,1,0,0,1,'کسور 3',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(35,1,34,34,1,0,0,1,'کسور 4',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(36,1,35,35,1,0,0,1,'کسور 5',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(37,1,36,36,1,0,0,1,'کسور 6',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(38,1,37,37,1,0,0,1,'کسور 7',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(39,1,38,38,1,0,0,1,'کسور 8',0,1,0,0,0,1,NULL,0,0,0,0,0,1,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(40,1,39,39,1,0,0,0,'سایر کسور',0,1,0,0,0,1,NULL,0,0,0,0,0,0,0,'مبلغ آن در کارکرد ماهیانه توسط کاربر تعیین می شود.'),
(41,1,40,40,0,1,1,0,'عیدی',0,0,1,1,0,0,23,0,0,0,0,0,0,0,'مقدار عیدی >>> (60 ÷ تعداد روزهای سال ) × (تعداد روزهای کارکرد + تعداد روزهای مرخصی استعلاجی)'),
(42,1,41,41,0,1,1,0,'بازخرید مرخصی',0,0,1,1,0,0,28,0,0,0,0,0,0,0,'مقدار مانده مرخصی بر حسب دقیقه >>> (1200 ÷ تعداد روزهای ماه  ) × (تعداد روزهای کارکرد + تعداد روزهای مرخصی استعلاجی) + مانده مرخصی از قبل - مرخصی مصرفی در ماه جاری'),
(43,1,42,42,0,1,1,0,'بازخرید سنوات',0,0,1,1,0,0,27,0,0,0,0,0,0,0,'مقدار سنوات >>> (30 ÷ تعداد روزهای سال) × (تعداد روزهای کارکرد + تعداد روزهای مرخصی استعلاجی) + مانده سنوات از قبل'),
(44,1,43,43,1,1,1,1,'سایر#اضافات#تسویه1',0,0,1,1,0,0,29,0,0,0,0,0,0,0,'مقدار این ستون در فیش تسویه و بازخرید نمایش داده می شود.'),
(45,1,44,44,1,1,1,1,'سایر#اضافات#تسویه2',0,0,1,1,0,0,29,0,0,0,0,0,0,0,'مقدار این ستون در فیش تسویه و بازخرید نمایش داده می شود.'),
(46,1,45,45,1,0,0,1,'سایر#کسورات#تسویه1',0,0,1,0,0,0,NULL,0,0,0,0,0,0,0,'مقدار این ستون در فیش تسویه و بازخرید نمایش داده می شود.');
-- ========================================== --
-- Command id: 1134
-- Description: ایجاد اولین رکورد
-- ========================================== --
INSERT INTO "TaxTable" ("id", "Year", "TaxableAmount0Percent", "TaxableAmount10Percent", "TaxableAmount15Percent", "TaxableAmount20Percent", "TaxableAmount25Percent")
VALUES (1, 1405, 4800000000, 9600000000, 12000000000, 14400000000, 16800000000);