﻿-- ========================================== --
-- Command id: 1025
-- Description: بابت اضافه کردن DELETE SET NULL به جدول اسناد حسابداری
-- ========================================== --
-- غیرفعال کردن کلیدهای خارجی
PRAGMA foreign_keys = OFF;
CREATE TABLE "Storage_New" (
	"id"	INTEGER NOT NULL,
	"FiscalPeriodid"	INTEGER NOT NULL,
	"StorageRefid"	INTEGER,
	"Status"	INTEGER,
	"StorageType"	INTEGER NOT NULL,
	"StorageType2"	INTEGER NOT NULL,
	"FinancialConfirmation"	INTEGER NOT NULL,
	"StorageDate"	INTEGER,
	"StorageTime"	TEXT,
	"StorageNumber"	INTEGER,
	"Storeid"	INTEGER NOT NULL,
	"Store2id"	INTEGER,
	"Customerid"	INTEGER,
	"CostCenterid"	INTEGER,
	"Description"	TEXT,
	"Userid"	INTEGER NOT NULL,
	"RowVersion"	BLOB,
	"GournalEntryid"	INTEGER,
	CONSTRAINT "FK_Storage_GournalEntry" FOREIGN KEY("GournalEntryid") REFERENCES "GournalEntry"("id") ON DELETE SET NULL,
	CONSTRAINT "FK_Storage_FiscalPeriod" FOREIGN KEY("FiscalPeriodid") REFERENCES "FiscalPeriod"("id"),
	CONSTRAINT "FK_Storage_Store" FOREIGN KEY("Storeid") REFERENCES "Store"("id"),
	CONSTRAINT "FK_Storage_Store1" FOREIGN KEY("Store2id") REFERENCES "Store"("id"),
	CONSTRAINT "FK_Storage_CostCenter" FOREIGN KEY("CostCenterid") REFERENCES "CostCenter"("id"),
	CONSTRAINT "FK_Storage_User" FOREIGN KEY("Userid") REFERENCES "User"("id"),
	CONSTRAINT "FK_Storage_Customer" FOREIGN KEY("Customerid") REFERENCES "Customer"("id"),
	CONSTRAINT "PK_Storage" PRIMARY KEY("id" AUTOINCREMENT)
);

INSERT INTO "Storage_New"
SELECT * FROM "Storage";

-- 3. حذف جدول قدیمی
DROP TABLE "Storage";

-- 4. تغییر نام جدول جدید به نام جدول اصلی
ALTER TABLE "Storage_New" RENAME TO "Storage";

-- فعال کردن مجدد کلیدهای خارجی
PRAGMA foreign_keys = ON;
-- ========================================== --
-- Command id: 1026
-- Description: 
-- ========================================== --
INSERT OR IGNORE INTO aOperation (
    id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, 
    IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, 
    Accounting, Salary, Sales, ARAP, Store, Asset, 
    IsPermissionToOther, IsActive
)
VALUES 
(
    75, 'سامانه دفاتر الکترونیکی', 'SendTransactionsToTaxSystem', 15, 8, 0, 
    0, 1, 0, 1, 
    1, 0, 0, 0, 0, 0, 
    0, 1
);
-- ========================================== --
-- Command id: 1027
-- Description: یوزرهایی که دسترسی به سند حسابداری دارن به سامانه دفاتر الکترونیکی هم دسترسی داشته باشن
-- ========================================== --
INSERT INTO UserOperationPermission (
    Userid, Operationsid, IsFavorite, BackgroundColor, ForegroundColor, 
    ButtonStyle, LeftLocation, TopLocation
)
SELECT 
    Userid, 
    75 AS Operationsid, 
    0 As IsFavorite, 
    BackgroundColor, 
    ForegroundColor, 
    ButtonStyle, 
    LeftLocation, 
    TopLocation
FROM UserOperationPermission
WHERE Operationsid = 22;

-- ========================================== --
-- Command id: 1028
-- Description: 
-- ========================================== --
CREATE TABLE TaxSystemTransactionHistory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    FiscalPeriodid INTEGER NOT NULL,
    FromDate INTEGER,
    ToDate INTEGER,
    TransactionBy INTEGER NOT NULL,
    Status INTEGER NOT NULL,
    Description TEXT,
    FOREIGN KEY (FiscalPeriodid) REFERENCES FiscalPeriod(id) 
);
