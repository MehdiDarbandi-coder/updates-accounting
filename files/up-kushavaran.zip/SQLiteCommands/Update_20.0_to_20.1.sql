﻿-- ========================================== --
-- Command id: 1001
-- Description: مدیریت دسترسی‌های کاربر ادمین
-- ========================================== --

ALTER TABLE StorageCanceled RENAME TO _StorageCanceledOld;

CREATE TABLE "StorageCanceled" (
	"id"	INTEGER NOT NULL,
	"StorageType"	INTEGER,
	"IsAll"	INTEGER NOT NULL,
	"Storageid"	INTEGER,
	"StorageDeid"	INTEGER,
	"CanceledDate"	INTEGER,
	"CanceledTime"	TEXT,
	"Description"	TEXT,
	"Userid"	INTEGER,
	CONSTRAINT "PK_StorageCancel" PRIMARY KEY("id" AUTOINCREMENT),
CONSTRAINT "FK_StorageCanceled_Storage" FOREIGN KEY("Storageid") REFERENCES "Storage"("id"),
	CONSTRAINT "FK_StorageCanceled_StorageDe" FOREIGN KEY("StorageDeid") REFERENCES "StorageDe"("id"),
	CONSTRAINT "FK_StorageCanceled_User" FOREIGN KEY("Userid") REFERENCES "User"("id")
);

INSERT INTO StorageCanceled SELECT * FROM _StorageCanceledOld;

DROP TABLE _StorageCanceledOld;
-- ========================================== --
-- Command id: 1002
-- Description: 
-- ========================================== --
ALTER TABLE StorageDe
ADD COLUMN UnitPrice INTEGER;
-- ========================================== --
-- Command id: 1003
-- Description: 
-- ========================================== --
UPDATE StorageDe
SET UnitPrice = 0
WHERE UnitPrice IS NULL;
-- ========================================== --
-- Command id: 1004
-- Description: 
-- ========================================== --
ALTER TABLE StorageRateDe RENAME TO _StorageRateDeOld;

CREATE TABLE "StorageRateDe" (
	"id"	INTEGER NOT NULL,
	"StorageDeid"	INTEGER NOT NULL,
	"StorageRateid"	INTEGER,
	"LTid"	INTEGER,
	"RowNumber"	INTEGER,
	"Rate"	INTEGER,
	"Amount"	INTEGER,
	"DescriptionDe"	TEXT,
	"HandlingCostAmount"	INTEGER,
	"IsHandlingCost"	INTEGER,
	CONSTRAINT "PK_StorageRate" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_StorageRateDe_StorageRate" FOREIGN KEY("StorageRateid") REFERENCES "StorageRate"("id") ON DELETE CASCADE,
	CONSTRAINT "FK_StorageRateDe_LT" FOREIGN KEY("LTid") REFERENCES "LT"("id"),
	CONSTRAINT "FK_StorageRateDe_StorageDe" FOREIGN KEY("StorageDeid") REFERENCES "StorageDe"("id")
);

INSERT INTO StorageRateDe SELECT * FROM _StorageRateDeOld;

DROP TABLE _StorageRateDeOld;
-- ========================================== --
-- Command id: 1005
-- Description: 
-- ========================================== --
DELETE FROM EntryType
WHERE (id = 13 OR id = 14) AND Parentid = 7;

INSERT INTO [EntryType] ([id], [Parentid], [RowNumber], [Title], [IsActive])
SELECT 15, 7, 3, 'فروش داخلی', 1
WHERE NOT EXISTS (SELECT 1 FROM [EntryType] WHERE id = 15);

INSERT INTO [EntryTypeDe] ([EntryTypeid], [Description], [Side], [ChoiceCriteriaLT], [ChoiceCriteriaLF], [ChoiceCriteriaLFive], [LTid], [LFid], [LFiveid])
SELECT 15, 'فروش داخلی', 'InvoiceCustomer', 'Fixed', 'CustomerLF', 'NotRel', NULL, NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM [EntryTypeDe] WHERE EntryTypeid = 15)
UNION ALL
SELECT 15, 'فروش داخلی', 'InvoiceItem', 'SaleLTInKala', 'Fixed', 'NotRel', NULL, NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM [EntryTypeDe] WHERE EntryTypeid = 15)
UNION ALL
SELECT 15, 'فروش داخلی', 'InvoiceTax', 'Fixed', 'Fixed', 'CustomerLF', NULL, NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM [EntryTypeDe] WHERE EntryTypeid = 15);
-- ========================================== --
-- Command id: 1006
-- Description: 
-- ========================================== --

ALTER TABLE Invoice RENAME TO _InvoiceOld;
ALTER TABLE InvoiceDe RENAME TO _InvoiceDeOld;

CREATE TABLE "Invoice" (
	"id"	INTEGER NOT NULL,
	"FiscalPeriodid"	INTEGER NOT NULL,
	"Storageid"	INTEGER,
	"GournalEntryid"	INTEGER,
	"InnerInvoiceTypeid"	INTEGER NOT NULL,
	"Customerid"	INTEGER NOT NULL,
	"CustomerTitle"	TEXT,
	"IsCreditTaxCustomer"	INTEGER,
	"Contractid"	INTEGER,
	"Status"	INTEGER,
	"InvoiceDate"	INTEGER,
	"InvoiceTime"	TEXT,
	"Paymentid"	INTEGER,
	"InvoiceNumber"	INTEGER,
	"Tracing"	TEXT,
	"Description"	TEXT,
	"Mablag"	INTEGER NOT NULL,
	"Discount"	INTEGER NOT NULL,
	"TaxAmount"	INTEGER NOT NULL,
	"Userid"	INTEGER NOT NULL,
	"SendStatus"	INTEGER,
	"SendDate"	INTEGER,
	"Templateid"	INTEGER,
	"InvoiceTypeid"	INTEGER,
	"InvoiceNumber2"	TEXT,
	"ReferenceNumber"	TEXT,
	"Subjectid"	INTEGER,
	"Uid"	TEXT,
	"Note"	TEXT,
	"RowVersion"	BLOB,
	CONSTRAINT "FK_Invoice_FiscalPeriod" FOREIGN KEY("FiscalPeriodid") REFERENCES "FiscalPeriod"("id"),
	CONSTRAINT "FK_Invoice_Customer" FOREIGN KEY("Customerid") REFERENCES "Customer"("id"),
	CONSTRAINT "FK_Invoice_User" FOREIGN KEY("Userid") REFERENCES "User"("id"),
	CONSTRAINT "FK_Invoice_SaleContract" FOREIGN KEY("Contractid") REFERENCES "SaleContract"("id"),
	CONSTRAINT "FK_Invoice_EntryType" FOREIGN KEY("InnerInvoiceTypeid") REFERENCES "EntryType"("id"),
	CONSTRAINT "FK_Invoice_GournalEntry" FOREIGN KEY("GournalEntryid") REFERENCES "GournalEntry"("id") ON DELETE SET NULL,
	CONSTRAINT "FK_Invoice_Storage" FOREIGN KEY("Storageid") REFERENCES "Storage"("id"),
	CONSTRAINT "PK_Invoice" PRIMARY KEY("id" AUTOINCREMENT)
);

CREATE TABLE "InvoiceDe" (
	"id"	INTEGER NOT NULL,
	"Invoiceid"	INTEGER NOT NULL,
	"HasStorage"	INTEGER,
	"RowNumber"	INTEGER NOT NULL,
	"KalaPriceid"	INTEGER,
	"SaleContractDeid"	INTEGER,
	"Kalaid"	INTEGER,
	"KalaTitle"	TEXT,
	"Quantity"	REAL NOT NULL,
	"Unit"	TEXT,
	"UnitNumber"	REAL NOT NULL,
	"UnitPrice"	INTEGER NOT NULL,
	"Amount"	INTEGER NOT NULL,
	"Discount"	INTEGER NOT NULL,
	"DiscountPercent"	REAL NOT NULL,
	"TaxPercent"	REAL NOT NULL,
	"DescriptionDe"	TEXT,
	"RowVersionDe"	BLOB,
	"Technicalid"	TEXT,
	CONSTRAINT "PK_InvoiceDe" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_InvoiceDe_SaleContractDe" FOREIGN KEY("SaleContractDeid") REFERENCES "SaleContractDe"("id"),
	CONSTRAINT "FK_InvoiceDe_Kala" FOREIGN KEY("Kalaid") REFERENCES "Kala"("id"),
	CONSTRAINT "FK_InvoiceDe_KalaPrice" FOREIGN KEY("KalaPriceid") REFERENCES "KalaPrice"("id"),
	CONSTRAINT "FK_InvoiceDe_Invoice" FOREIGN KEY("Invoiceid") REFERENCES "Invoice"("id") ON DELETE CASCADE
);

INSERT INTO Invoice SELECT * FROM _InvoiceOld;
INSERT INTO InvoiceDe SELECT * FROM _InvoiceDeOld;

DROP TABLE _InvoiceOld;
DROP TABLE _InvoiceDeOld;

DROP TABLE IF EXISTS InvoiceType;

UPDATE Invoice
SET InnerInvoiceTypeid = 15;
-- ========================================== --
-- Command id: 1007
-- Description: 
-- ========================================== --
ALTER TABLE Company  ADD COLUMN WebSite TEXT;
-- ========================================== --
-- Command id: 1008
-- Description: 
-- ========================================== --
ALTER TABLE EntryType  ADD COLUMN IsMerge INTEGER;
-- ========================================== --
-- Command id: 1009
-- Description: 
-- ========================================== --
ALTER TABLE Storage  ADD COLUMN GournalEntryid INTEGER;
-- ========================================== --
-- Command id: 1010
-- Description: 
-- ========================================== --
UPDATE aOperation SET ModelView = 'CheckStatusType' WHERE ModelView = 'ApArSettingView';
-- ========================================== --
-- Command id: 1011
-- Description: 
-- ========================================== --
ALTER TABLE StorageDe  ADD COLUMN Amount INTEGER;
-- ========================================== --
-- Command id: 1012
-- Description: 
-- ========================================== --
ALTER TABLE StorageDe  ADD COLUMN GournalEntryDate INTEGER;
-- ========================================== --
-- Command id: 1013
-- Description: 
-- ========================================== --
ALTER TABLE StorageDe DROP COLUMN SalesUnitPrice;
-- ========================================== --
-- Command id: 1014
-- Description: 
-- ========================================== --
ALTER TABLE CostCenter ADD COLUMN LFid INTEGER;
-- ========================================== --
-- Command id: 1015
-- Description: 
-- ========================================== --
ALTER TABLE Customer ADD COLUMN AccountNumber TEXT;
-- ========================================== --
-- Command id: 1016
-- Description: 
-- ========================================== --
INSERT OR IGNORE INTO aOperation (id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, Accounting, Salary, Sales, ARAP, Store, Asset, IsPermissionToOther, IsActive)
VALUES 
(74, 'تنظیمات سند اتوماتیک', 'AutoIssuanceGournalEntrySetting', 1, 6, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1),
(3078, 'دریافت از اکسل', 'ImportExcel', 2, 20, 0, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1),
(3079, 'تغییر گروهی آرتیکل اسناد', 'GournalEntryGroupUpdate', 6, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1);
-- ========================================== --
-- Command id: 1017
-- Description: 
-- ========================================== --

DELETE FROM aOperation
WHERE ModelView IN ('AutoIssuePurchaseInvoice', 'StorageRateConfirmation');
-- ========================================== --
-- Command id: 1018
-- Description: 
-- ========================================== --
CREATE TABLE "CostCenterNew" (
	"id"	INTEGER NOT NULL,
	"Code"	TEXT NOT NULL,
	"Title"	TEXT NOT NULL,	
	"CostCenterType"	TEXT,
	"IsActive"	INTEGER NOT NULL,
        "LFid"	INTEGER,
        CONSTRAINT "FK_CostCenter_LF" FOREIGN KEY("LFid") REFERENCES "LF"("id"),       
	CONSTRAINT "PK_CostCenter" PRIMARY KEY("id" AUTOINCREMENT)
);

INSERT INTO CostCenterNew (id, Code, Title, CostCenterType, IsActive, LFid)
SELECT id, Code, Title, CostCenterType, IsActive, LFid FROM CostCenter;

DROP TABLE CostCenter;

ALTER TABLE CostCenterNew RENAME TO CostCenter;
-- ========================================== --
-- Command id: 1019
-- Description: 
-- ========================================== --
UPDATE BatchDe 
SET Itemid = 10 
WHERE Itemid = 2;
-- ========================================== --
-- Command id: 1020
-- Description: CREATE TABLE BillOfLading
-- ========================================== --
ALTER TABLE BillOfLading RENAME TO BillOfLading_Old;

CREATE TABLE "BillOfLading" (
	"id"	INTEGER NOT NULL,
	"Trackingid"	TEXT,
	"BillOfLadingDate"	INTEGER,
	"BillOfLadingNumber"	INTEGER,
	"Customerid"	INTEGER NOT NULL,
	"Kalaid"	BLOB,	
	"CommissionAmount"	INTEGER NOT NULL,
	"Note"	TEXT,
	"SendStatus"	TEXT,
	"SendDate"	INTEGER,
	"Templateid"	INTEGER,
	"InvoiceTypeid"	INTEGER,
	"InvoiceNumber2"	TEXT,
	"InvoiceReferenceNumber"	TEXT,
	"Subjectid"	INTEGER,
	"Uid"	TEXT,
	CONSTRAINT "FK_BillOfLading_Kala" FOREIGN KEY("Kalaid") REFERENCES "Kala"("id"),
	CONSTRAINT "FK_BillOfLading_Customer" FOREIGN KEY("Customerid") REFERENCES "Customer"("id") ON DELETE CASCADE,
	CONSTRAINT "PK_BillOfLading" PRIMARY KEY("id" AUTOINCREMENT)
);

INSERT INTO BillOfLading (
    id, 
    Trackingid, 
    BillOfLadingDate, 
    BillOfLadingNumber, 
    Customerid, 
    Kalaid,    
    CommissionAmount, 
    Note, 
    SendStatus, 
    SendDate, 
    Templateid, 
    InvoiceTypeid, 
    InvoiceNumber2, 
    InvoiceReferenceNumber, 
    Subjectid, 
    Uid
)
SELECT 
    id, 
    Trackingid, 
    BillOfLadingDate, 
    BillOfLadingNumber, 
    Customerid, 
    Kalaid,    
    CommissionAmount, 
    Note, 
    SendStatus, 
    SendDate, 
    Templateid, 
    InvoiceTypeid, 
    InvoiceNumber2, 
    InvoiceReferenceNumber, 
    Subjectid, 
    Uid
FROM BillOfLading_Old;

DROP TABLE BillOfLading_Old;

CREATE INDEX "IX_BillOfLading" ON "BillOfLading" (
    "BillOfLadingDate" DESC,
    "BillOfLadingNumber"
);

CREATE INDEX "IX_BillOfLading_Customerid" ON "BillOfLading" (
    "Customerid"
);

CREATE INDEX "IX_BillOfLading_Kalaid" ON "BillOfLading" (
    "Kalaid"
);

CREATE UNIQUE INDEX "IX_BillOfLading_Trackingid" ON "BillOfLading" (
    "Trackingid"
);

-- ========================================== --
-- Command id: 1021
-- Description:از اینجا مال آبان 1403 است 
-- ========================================== --
CREATE TABLE "FinancialReportSettings" (
	"id" INTEGER PRIMARY KEY,
	"ReportType" INTEGER NOT NULL,
	"ItemType" INTEGER NOT NULL,
	"Title" TEXT NOT NULL,
	"NoteNumber" TEXT,
	"RowNumber" INTEGER NOT NULL
);

-- ساخت جدول جزییات با کلید خارجی به جدول اصلی و تنظیم حذف خودکار
CREATE TABLE "FinancialReportSettingsDe" (
	"id"	INTEGER,
	"FinancialReportSettingsid"	INTEGER NOT NULL,
	"RowNumber"	INTEGER,
	"LTid"	INTEGER,
	"GLid"	INTEGER,
	FOREIGN KEY("FinancialReportSettingsid") REFERENCES "FinancialReportSettings"("id") ON DELETE CASCADE,
	FOREIGN KEY("GLid") REFERENCES "GL"("id") ON DELETE CASCADE,
	FOREIGN KEY("LTid") REFERENCES "LT"("id") ON DELETE CASCADE,
	PRIMARY KEY("id" AUTOINCREMENT)
);

INSERT INTO FinancialReportSettings (id, ReportType, ItemType, Title, NoteNumber, RowNumber)
SELECT id, ReportType, ItemType, Title, NoteNumber, RowNumber
FROM (
    SELECT 1 AS id, 0 AS ReportType, 0 AS ItemType, 'عملیات در حال تداوم' AS Title, NULL AS NoteNumber, 1 AS RowNumber UNION ALL
    SELECT 2, 0, 1, 'درآمدهای عملیاتی', 5, 2 UNION ALL
    SELECT 3, 0, 1, 'بهای تمام شده درآمدهای عملیاتی', 7, 3 UNION ALL
    SELECT 4, 0, 2, 'سود ناخالص', NULL, 4 UNION ALL
    SELECT 5, 0, 1, 'هزینه‌های فروش، اداری و عمومی', 8, 5 UNION ALL
    SELECT 6, 0, 1, 'زیان کاهش ارزش دریافتنی ها', 9, 6 UNION ALL
    SELECT 7, 0, 1, 'سایر درآمدها', 10, 7 UNION ALL
    SELECT 8, 0, 1, 'سایر هزینه‌ها', 11, 8 UNION ALL
    SELECT 9, 0, 2, 'سود عملیاتی', NULL, 9 UNION ALL
    SELECT 10, 0, 1, 'هزینه‌های مالی', 12, 10 UNION ALL
    SELECT 11, 0, 1, 'سایر درآمدها و هزینه‌های غیرعملیاتی', 13, 11 UNION ALL
    SELECT 12, 0, 2, 'سود عملیات در حال تداوم قبل از مالیات', NULL, 12 UNION ALL
    SELECT 13, 0, 1, 'هزینه مالیات بر درآمد', NULL, 13 UNION ALL
    SELECT 14, 0, 2, 'سود خالص عملیات در حال تداوم', NULL, 14 UNION ALL
    SELECT 15, 0, 0, 'عملیات متوقف شده', NULL, 15 UNION ALL
    SELECT 16, 0, 1, 'سود (زیان) خالص عملیات متوقف شده', 14, 16 UNION ALL
    SELECT 17, 0, 2, 'سود خالص', NULL, 17 UNION ALL
    SELECT 18, 0, 0, 'سود هر سهم', NULL, 18 UNION ALL
    SELECT 19, 0, 0, ':سود پایه هر سهم', NULL, 19 UNION ALL
    SELECT 20, 0, 3, 'عملیاتی (ریال)', NULL, 20 UNION ALL
    SELECT 21, 0, 3, 'غیر عملیاتی (ریال)', NULL, 21 UNION ALL
    SELECT 22, 0, 3, 'ناشی از عملیات در حال تداوم (ریال)', NULL, 22 UNION ALL
    SELECT 23, 0, 3, 'ناشی از عملیات متوقف شده (ریال)', NULL, 23 UNION ALL
    SELECT 24, 0, 2, 'سود پایه هر سهم (ریال)', 15, 24 UNION ALL
    SELECT 50, 1, 0, 'دارایی ها', NULL, 1 UNION ALL
    SELECT 51, 1, 0, 'دارایی های غیر جاری', NULL, 2 UNION ALL
    SELECT 52, 1, 1, 'دارایی های ثابت مشهود', 16, 3 UNION ALL
    SELECT 53, 1, 1, 'سرمایه گذاری در املاک', 17, 4 UNION ALL
    SELECT 54, 1, 1, 'دارایی های نامشهود', 18, 5 UNION ALL
    SELECT 55, 1, 1, 'سرمایه گذاری های بلندمدت', 19, 6 UNION ALL
    SELECT 56, 1, 1, 'دریافتنی های بلندمدت', 20, 7 UNION ALL
    SELECT 57, 1, 1, 'دارایی مالیات انتقالی', 35, 8 UNION ALL
    SELECT 58, 1, 1, 'سایر دارایی ها', 21, 9 UNION ALL
    SELECT 59, 1, 2, 'جمع دارایی های غیرجاری', NULL, 10 UNION ALL
    SELECT 60, 1, 0, 'دارایی های جاری', NULL, 11 UNION ALL
    SELECT 61, 1, 1, 'پیش پرداخت ها', 22, 12 UNION ALL
    SELECT 62, 1, 1, 'موجودی مواد و کالا', 23, 13 UNION ALL
    SELECT 63, 1, 1, 'دریافتنی های تجاری و سایر دریافتنی ها', 20, 14 UNION ALL
    SELECT 64, 1, 1, 'سرمایه گذاری های کوتاه مدت', 24, 15 UNION ALL
    SELECT 65, 1, 1, 'موجودی نقد', 25, 16 UNION ALL
    SELECT 66, 1, 2, '', NULL, 17 UNION ALL
    SELECT 67, 1, 1, 'دارایی هی غیر جاری نگهداری شده برای فروش', 26, 18 UNION ALL
    SELECT 68, 1, 2, 'جمع دارایی های جاری', NULL, 19 UNION ALL
    SELECT 69, 1, 2, 'جمع دارایی ها', NULL, 20 UNION ALL
    SELECT 70, 1, 0, 'حقوق مالکانه و بدهی ها', NULL, 21 UNION ALL
    SELECT 71, 1, 0, 'حقوق مالکانه', NULL, 22 UNION ALL
    SELECT 72, 1, 1, 'سرمایه', 27, 23 UNION ALL
    SELECT 73, 1, 1, 'افزایش سرمایه در جریان', 28, 24 UNION ALL
    SELECT 74, 1, 1, 'صرف سهام', 29, 25 UNION ALL
    SELECT 75, 1, 1, 'صرف سهام خزانه', NULL, 26 UNION ALL
    SELECT 76, 1, 1, 'اندوخته قانونی', 30, 27 UNION ALL
    SELECT 77, 1, 1, 'سایر اندوخته ها', 31, 28 UNION ALL
    SELECT 78, 1, 1, 'مازاد تجدید ارزیابی دارایی ها', NULL, 29 UNION ALL
    SELECT 79, 1, 1, 'سود انباشته', NULL, 30 UNION ALL
    SELECT 80, 1, 1, 'سهام خزانه', 32, 31 UNION ALL
    SELECT 81, 1, 2, 'جمع حقوق مالکانه', NULL, 32 UNION ALL
    SELECT 82, 1, 0, 'بدهی ها', NULL, 33 UNION ALL
    SELECT 83, 1, 0, 'بدهی های غیر جاری', NULL, 34 UNION ALL
    SELECT 84, 1, 1, 'پرداختنی های بلند مدت', 33, 35 UNION ALL
    SELECT 85, 1, 1, 'تسهیلات مالی بلند مدت', 34, 36 UNION ALL
    SELECT 86, 1, 1, 'بدهی مالیات انتقالی', 35, 37 UNION ALL
    SELECT 87, 1, 1, 'ذخیره مزایای پایان خدمت کارکنان', 36, 38 UNION ALL
    SELECT 88, 1, 2, 'جمع بدهی های غیر جاری', NULL, 39 UNION ALL
    SELECT 89, 1, 0, 'بدهی های جاری', NULL, 40 UNION ALL
    SELECT 90, 1, 1, 'پرداختنی های تجاری و سایر پرداختنی ها', 33, 41 UNION ALL
    SELECT 91, 1, 1, 'مالیات پرداختنی ', 35, 42 UNION ALL
    SELECT 92, 1, 1, 'سود سهام پرداختنی', 37, 43 UNION ALL
    SELECT 93, 1, 1, 'تسهیلات مالی', 34, 44 UNION ALL
    SELECT 94, 1, 1, 'دخایر', 38, 45 UNION ALL
    SELECT 95, 1, 1, 'پیش دریافت ها', 39, 46 UNION ALL
    SELECT 96, 1, 2, '', NULL, 47 UNION ALL
    SELECT 97, 1, 1, 'بدهی های مرتبط با دارایی هاز غیر جاری نگهداری شده برای فروش', 26, 48 UNION ALL
    SELECT 98, 1, 2, 'جمع بدهی های جاری', NULL, 49 UNION ALL
    SELECT 99, 1, 2, 'جمع بدهی ها', NULL, 50 UNION ALL
    SELECT 100, 1, 2, 'جمع بدهی ها و حقوق مالکانه', NULL, 51
) AS NewData
WHERE NOT EXISTS (
    SELECT 1
    FROM FinancialReportSettings AS ExistingData
    WHERE ExistingData.id = NewData.id
);

-- در ابتدا سطرها را وارد کنید، فقط در صورتی که موجود نباشند
INSERT INTO aOperation (id, Title, ModelView, HederDeid, RowNumber, OnlyAdmin, IsDuplicate, IsShowMainView, IsShowDialog, IsUserCtrl, Accounting, Salary, Sales, ARAP, Store, Asset, IsPermissionToOther, IsActive)
SELECT 5086, 'تعیین اقلام صورت سود و زیان', 'IncomeStatementSettings', 1, 7, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1
WHERE NOT EXISTS (SELECT 1 FROM aOperation WHERE id = 5086)
UNION ALL
SELECT 5087, 'تعیین اقلام صورت وضعیت مالی', 'BalanceSheetSettings', 1, 8, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1
WHERE NOT EXISTS (SELECT 1 FROM aOperation WHERE id = 5087);

-- سپس عملیات بروزرسانی را انجام دهید
UPDATE aOperation 
SET Title = 'سایر تنظیمات' 
WHERE ModelView = 'SettingView';

UPDATE aOperation 
SET ModelView = 'IncomeStatementReport', IsActive = 1 
WHERE id = 50;

UPDATE aOperation 
SET ModelView = 'BalanceSheetReport', IsActive = 1 
WHERE id = 51;
-- ========================================== --
-- Command id: 1022
-- Description: مدیریت دسترسی‌های کاربر ادمین
-- ========================================== --
UPDATE aOperation
SET RowNumber = CASE id
    WHEN 1 THEN 1
    WHEN 3 THEN 2
    WHEN 5 THEN 3
    WHEN 6 THEN 4
    WHEN 4 THEN 5
    WHEN 2 THEN 6
    WHEN 5086 THEN 7
    WHEN 5087 THEN 8
    WHEN 74 THEN 9
    WHEN 73 THEN 10
    ELSE RowNumber -- نگه داشتن مقدار قبلی برای مقادیر غیرمشخص
END
WHERE id IN (1, 3, 5, 6, 4, 2, 5086, 5087, 74, 73);

-- ایجاد دسترسی برای ادمین در صورت نبود و همچنین حذف سطرهای تکراری 
INSERT INTO UserOperationPermission (
Userid, Operationsid, IsFavorite, BackgroundColor, ForegroundColor,
ButtonStyle, LeftLocation, TopLocation
)

SELECT 1 AS Userid,
   A.id AS Operationsid,
   0 AS IsFavorite,
   NULL AS BackgroundColor,
   NULL AS ForegroundColor,
   NULL AS ButtonStyle,
   NULL AS LeftLocation,
   NULL AS TopLocation
FROM aOperation A
LEFT OUTER JOIN UserOperationPermission UOP 
   ON A.id = UOP.Operationsid AND UOP.Userid = 1
WHERE A.OnlyAdmin = 1
AND UOP.Operationsid IS NULL;

-- ایجاد یک جدول موقت برای ذخیره شناسه‌های رکوردهای تکراری
CREATE TEMPORARY TABLE DuplicateRows (id INTEGER);

-- پر کردن جدول موقت با شناسه‌های رکوردهای تکراری
INSERT INTO DuplicateRows (id)
SELECT id
FROM (
    SELECT
	    id,
        ROW_NUMBER() OVER (PARTITION BY Userid, Operationsid ORDER BY id) AS RowNum
    FROM UserOperationPermission
)
WHERE RowNum > 1;

-- حذف رکوردهای تکراری از جدول اصلی
DELETE FROM UserOperationPermission
WHERE id IN (SELECT id FROM DuplicateRows);

-- حذف جدول موقت
DROP TABLE DuplicateRows;
