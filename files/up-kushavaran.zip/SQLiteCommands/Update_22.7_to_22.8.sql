﻿-- ========================================= --
-- Command id: 1205
-- Description: 
-- ========================================= --
UPDATE UserBrushThemDe
SET Color = CASE BrushThemid
    WHEN 1  THEN '#D6E2EF'
    WHEN 2  THEN '#F5EBDD'
    WHEN 3  THEN '#2F4654'
    WHEN 4  THEN '#F2F8F6'
    WHEN 5  THEN '#FFFFFFFF'
    WHEN 6  THEN '#FFFFFFFF'
    WHEN 7  THEN '#FFFFFFFF'
    WHEN 8  THEN '#FFFFFFFF'
    WHEN 9  THEN '#FFFFFFFF'
    WHEN 10 THEN '#FFFFFFFF'
    WHEN 11 THEN '#FFFFFFFF'
    WHEN 12 THEN '#2A2718'
    WHEN 13 THEN '#FFFFFFFF'
END
WHERE Brushid = 39
  AND BrushThemid IN (1,2,3,4,5,6,7,8,9,10,11,12,13);
-- ========================================= --
-- Command id: 1206
-- Description: 
-- ========================================= --
WITH v(BrushThemid, Brushid, Color) AS (
    VALUES
    (1,  2072, '#0D1A2D'),   (1,  2073, '#1D3857'),
    (2,  2072, '#1A110C'),   (2,  2073, '#3A2A1F'),
    (3,  2072, '#D5E3EA'),   (3,  2073, '#B2C8D5'),
    (4,  2072, '#09262A'),   (4,  2073, '#1A4A50'),
    (5,  2072, '#FFD6E8DD'), (5,  2073, '#FF9FC4AE'),
    (6,  2072, '#FFDFD3E7'), (6,  2073, '#FFBBA4CC'),
    (7,  2072, '#FFE9DCD3'), (7,  2073, '#FFCDB3A3'),
    (8,  2072, '#FF161E24'), (8,  2073, '#FF27363F'),
    (9,  2072, '#FF15201A'), (9,  2073, '#FF2A3F34'),
    (10, 2072, '#FF1D1521'), (10, 2073, '#FF3A2B44'),
    (11, 2072, '#FF151922'), (11, 2073, '#FF2A3345'),
    (12, 2072, '#A9A896'),   (12, 2073, '#94937F'),
    (13, 2072, '#FFD3E1EC'), (13, 2073, '#FFAFC6D9')
)
INSERT INTO UserBrushThemDe (BrushThemid, Brushid, Color)
SELECT v.BrushThemid, v.Brushid, v.Color
FROM v
WHERE NOT EXISTS (
    SELECT 1
    FROM UserBrushThemDe AS d
    WHERE d.BrushThemid = v.BrushThemid
      AND d.Brushid = v.Brushid
);
-- ========================================= --
-- Command id: 1207
-- Description: 
-- ========================================= --
ALTER TABLE UserMessage ADD COLUMN IsEdited INTEGER NOT NULL DEFAULT 0;