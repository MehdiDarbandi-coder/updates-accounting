﻿-- ========================================== --
-- Command id: 1083
-- Description: ایجاد جدول واحد سنجش
-- ========================================== --
CREATE TABLE "Unit" (
	"id"	INTEGER NOT NULL,
	"Title"	TEXT NOT NULL,
	"TaxCode"	TEXT,
	"DecimalCount"	INTEGER NOT NULL DEFAULT 0,
	CONSTRAINT "PK_Unit" PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE UNIQUE INDEX "UX_Unit_Title" ON "Unit"("Title");

-- ========================================== --
-- Command id: 1084
-- Description: پر کردن جدول واحد از کالا
-- ========================================== --
INSERT INTO "Unit" ("Title", "TaxCode")
SELECT
	TRIM("UnitMain") AS "Title",
	MAX(NULLIF(TRIM("UnitMainid"), '')) AS "TaxCode"
FROM "Kala"
WHERE "UnitMain" IS NOT NULL AND TRIM("UnitMain") <> ''
GROUP BY TRIM("UnitMain");

-- ========================================== --
-- Command id: 1085
-- Description: اضافه کردن ستون های جدید
-- ========================================== --
ALTER TABLE "Kala" ADD COLUMN "Unitid" INTEGER;
ALTER TABLE "Kala" ADD COLUMN "SubUnitid" INTEGER;
ALTER TABLE "Kala" ADD COLUMN "ConversionFactor" REAL;

-- ========================================== --
-- Command id: 1086
-- Description: ست کردن Unitid بر اساس عنوان قبلی
-- ========================================== --
UPDATE "Kala"
SET "Unitid" = (
	SELECT "u"."id"
	FROM "Unit" "u"
	WHERE TRIM("Kala"."UnitMain") = "u"."Title"
)
WHERE EXISTS (
	SELECT 1
	FROM "Unit" "u"
	WHERE TRIM("Kala"."UnitMain") = "u"."Title"
);

-- ========================================== --
-- Command id: 1086
-- Description: ایجاد واحد نامشخص برای کالای بدون واحد
-- ========================================== --
INSERT INTO "Unit" ("Title", "TaxCode")
SELECT 'نامشخص', NULL
WHERE NOT EXISTS (SELECT 1 FROM "Unit" WHERE "Title" = 'نامشخص');

UPDATE "Kala"
SET "Unitid" = (SELECT "id" FROM "Unit" WHERE "Title" = 'نامشخص')
WHERE "Unitid" IS NULL;

-- ========================================== --
-- Command id: 1087
-- Description: بازسازی جدول کالا با NOT NULL و کلید خارجی
-- ========================================== --

CREATE TABLE "Kala_new" (
	"id"	INTEGER NOT NULL,
	"SalesKalaid"	INTEGER,
	"Code"	TEXT NOT NULL,
	"Code2"	TEXT,
	"Title"	TEXT NOT NULL,
	"LFid"	INTEGER,
	"KalaTypeid"	INTEGER NOT NULL,
	"Technicalid"	TEXT,
	"DefultTax"	TEXT,
	"IsActive"	INTEGER NOT NULL,
	"IsShowInInvoice"	INTEGER,
	"IsShowInStorage"	INTEGER,
	"IsQualityControl"	INTEGER NOT NULL,
	"QualityType"	INTEGER,
	"PurchaseLTid"	INTEGER,
	"SaleLTid"	INTEGER,
	"KalaGroupid"	INTEGER,
	"Unitid"	INTEGER NOT NULL,
	"SubUnitid"	INTEGER,
	"ConversionFactor"	REAL,
	CONSTRAINT "PK_Kala" PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("KalaGroupid") REFERENCES "BatchDe"("id"),
	CONSTRAINT "FK_Kala_LF" FOREIGN KEY("LFid") REFERENCES "LF"("id"),
	CONSTRAINT "FK_Kala_BatchDe" FOREIGN KEY("KalaTypeid") REFERENCES "BatchDe"("id"),
	CONSTRAINT "FK_Kala_LT" FOREIGN KEY("PurchaseLTid") REFERENCES "LT"("id"),
	CONSTRAINT "FK_Kala_Kala" FOREIGN KEY("SalesKalaid") REFERENCES "Kala"("id"),
	CONSTRAINT "FK_Kala_LT1" FOREIGN KEY("SaleLTid") REFERENCES "LT"("id"),
	CONSTRAINT "FK_Kala_Unit" FOREIGN KEY("Unitid") REFERENCES "Unit"("id"),
	CONSTRAINT "FK_Kala_SubUnit" FOREIGN KEY("SubUnitid") REFERENCES "Unit"("id")
);

INSERT INTO "Kala_new" (
	"id", "SalesKalaid", "Code", "Code2", "Title", "LFid", "KalaTypeid",
	"Technicalid", "DefultTax", "IsActive", "IsShowInInvoice", "IsShowInStorage",
	"IsQualityControl", "QualityType", "PurchaseLTid", "SaleLTid",
	"Unitid", "SubUnitid", "ConversionFactor"
)
SELECT
	"id", "SalesKalaid", "Code", "Code2", "Title", "LFid", "KalaTypeid",
	"Technicalid", "DefultTax", "IsActive", "IsShowInInvoice", "IsShowInStorage",
	"IsQualityControl", "QualityType", "PurchaseLTid", "SaleLTid",
	"Unitid", "SubUnitid", "ConversionFactor"
FROM "Kala";

DROP TABLE "Kala";

ALTER TABLE "Kala_new" RENAME TO "Kala";

PRAGMA foreign_key_check;

PRAGMA foreign_keys = ON;

-- ========================================== --
-- Command id: 1090
-- Description: افزودن ستون Scope به UserBrushThem
-- ========================================== --
ALTER TABLE "UserBrushThem" ADD COLUMN "Scope" INTEGER NOT NULL DEFAULT 2;

-- ========================================== --
-- Command id: 1091
-- Description: افزودن ستون موقت MigrationSourceId
-- ========================================== --
ALTER TABLE "UserBrushThem" ADD COLUMN "MigrationSourceId" INTEGER;

-- ========================================== --
-- Command id: 1092
-- Description: ساخت تم های جدید Shell از روی تم های قدیمی
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope", "MigrationSourceId")
SELECT "t"."Userid", "t"."Title" || ' (صفحه اول)', 1, "t"."id"
FROM "UserBrushThem" "t"
WHERE "t"."MigrationSourceId" IS NULL
  AND EXISTS (
        SELECT 1
        FROM "UserBrushThemDe" "de"
        JOIN "aBrush" "b" ON "b"."id" = "de"."Brushid"
        JOIN "aBrushHeader" "h" ON "h"."id" = "b"."Headerid"
        WHERE "de"."BrushThemid" = "t"."id" AND "h"."IsMainView" = 1
  );

-- ========================================== --
-- Command id: 1093
-- Description: انتقال رکوردهای Shell به تم جدید
-- ========================================== --
UPDATE "UserBrushThemDe"
SET "BrushThemid" = (
	SELECT "nt"."id"
	FROM "UserBrushThem" "nt"
	WHERE "nt"."MigrationSourceId" = "UserBrushThemDe"."BrushThemid"
)
WHERE EXISTS (
	SELECT 1
	FROM "UserBrushThem" "nt"
	JOIN "aBrush" "b" ON "b"."id" = "UserBrushThemDe"."Brushid"
	JOIN "aBrushHeader" "h" ON "h"."id" = "b"."Headerid"
	WHERE "nt"."MigrationSourceId" = "UserBrushThemDe"."BrushThemid"
	  AND "h"."IsMainView" = 1
);

-- ========================================== --
-- Command id: 1094
-- Description: حذف ستون موقت MigrationSourceId
-- ========================================== --
ALTER TABLE "UserBrushThem" DROP COLUMN "MigrationSourceId";
-- ========================================== --
-- Command id: 1095
-- Description: حذف کليد خارجي وابسته به aBrush
-- ========================================== --
PRAGMA foreign_keys = OFF;

CREATE TABLE "UserBrushThemDe_new" (
	"id"	INTEGER NOT NULL,
	"BrushThemid"	INTEGER NOT NULL,
	"Brushid"	INTEGER NOT NULL,
	"Color"	TEXT NOT NULL,
	CONSTRAINT "PK_UserBrushThemDe" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_UserBrushThemDe_UserBrushThem" FOREIGN KEY("BrushThemid") REFERENCES "UserBrushThem"("id") ON DELETE CASCADE
);

INSERT INTO "UserBrushThemDe_new" ("id", "BrushThemid", "Brushid", "Color")
SELECT "id", "BrushThemid", "Brushid", "Color"
FROM "UserBrushThemDe";

DROP TABLE "UserBrushThemDe";

ALTER TABLE "UserBrushThemDe_new" RENAME TO "UserBrushThemDe";

PRAGMA foreign_key_check;

PRAGMA foreign_keys = ON;

-- ========================================== --
-- Command id: 1096
-- Description: حذف جدول aBrush
-- ========================================== --
DROP TABLE "aBrush";

-- ========================================== --
-- Command id: 1097
-- Description: حذف جدول aBrushHeader
-- ========================================== --
DROP TABLE "aBrushHeader";

-- ========================================== --
-- Command id: 1098
-- Description: 
-- ========================================== --
DELETE FROM "UserBrushThem"
WHERE "Userid" = 1;
-- ========================================== --
-- Command id: 1099
-- Description: تمهای رنگی 
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'ذغالی مینیمال و پلاتین', 1);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 154, '#15191F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 155, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 156, 'Red'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 157, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 158, '#FFF86060'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 159, '#FFADDE2A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 160, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 161, '#FFE7F019'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 162, '#1D2430'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 163, '#1B2029'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 164, '#8A96A3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 165, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 169, '#222933'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 172, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 173, '#A7B2BE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 174, '#FF4CDCBC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 175, '#FF526C7B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 176, '#323B4C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 220, 'Gray'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 189, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 190, '#FF979899'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 191, '#FFB7BBBF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 194, '#FF666464'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 195, '#FF8E8AC7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 196, '#15191F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 197, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 198, '#9E3B3B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 199, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 200, '#C3CCD6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 201, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 205, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 206, '#C3CCD6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 209, '#2A3140'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 211, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 212, '#15191F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 213, '#15191F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 214, '#9E3B3B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 215, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 216, '#762B2B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 218, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 219, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 221, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 224, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 236, '#B7C0CA'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 237, '#2A3140'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 238, '#E7EBEF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 239, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 240, '#15191F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 166, '#76828F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 202, '#E7EBEF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 226, '#15191F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 228, '#313A47'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 227, '#E7EBEF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 231, '#9AA7B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 233, '#C3CCD6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 229, '#8A96A3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 230, '#8A96A3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 234, '#A7B2BE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 235, '#FFCDD9E9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 177, '#E7EBEF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 208, '#E7EBEF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'ذغالی مینیمال و پلاتین' AND "Userid" = 1), 210, '#F8F9FA');
-- ========================================== --
-- Command id: 10100
-- Description:  
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'زیتونی خاکستری و برنز مات', 1);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 154, '#B7B6A6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 155, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 162, '#B0AF9D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 175, '#FF526C7B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 225, 'White'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 189, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 191, '#FFB7BBBF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 220, 'Gray'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 218, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 194, '#FF666464'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 219, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 195, '#FF8E8AC7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 190, '#FF979899'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 224, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 163, '#A9A897'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 164, '#4A4636'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 165, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 166, '#5C4630'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 205, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 206, '#97754F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 236, '#2E2A1F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 237, '#9E9C89'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 238, '#1A170F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 239, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 240, '#F5F1E8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 169, '#C4C3B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 172, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 173, '#2E2A1F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 174, '#B4B3A1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 176, '#B4B3A1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 177, '#1A170F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 226, '#B7B6A6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 227, '#1A170F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 228, '#93927F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 229, '#4A4636'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 232, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 233, '#97754F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 234, '#2E2A1F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 235, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 196, '#B7B6A6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 197, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 198, '#8C2E28'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 199, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 200, '#97754F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 201, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 202, '#1A170F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 208, '#4A4636'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 209, '#9E9C89'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 210, '#1A170F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 211, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 212, '#F5F1E8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 221, '#7A5C3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 213, '#F5F1E8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 214, '#8C2E28'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 215, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 216, '#6B211C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 156, '#8C2E28'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 157, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 158, '#6B211C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 159, '#9E9C89'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 160, '#1A170F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زیتونی خاکستری و برنز مات' AND "Userid" = 1), 161, '#B0AF9D');
-- ========================================== --
-- Command id: 1101
-- Description:  
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'سرمه‌ای و طلایی', 1);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 154, '#0F1E33'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 155, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 162, '#16314F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 174, '#FF4CDCBC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 175, '#FF526C7B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 220, 'Gray'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 189, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 190, '#FF979899'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 191, '#FFB7BBBF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 194, '#FF666464'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 195, '#FF8E8AC7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 218, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 219, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 224, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 163, '#122840'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 164, '#9FB3C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 165, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 166, '#B8901F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 205, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 206, '#E8C468'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 236, '#C7CED8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 237, '#1E3B5C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 238, '#F0E6C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 239, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 240, '#0F1E33'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 156, '#B3282D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 157, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 158, '#8C1F22'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 159, '#1E3B5C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 160, '#F0E6C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 161, '#16314F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 169, '#1B3A5C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 172, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 173, '#B8C4D4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 176, '#284D73'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 177, '#F0E6C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 196, '#0F1E33'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 197, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 198, '#B3282D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 199, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 200, '#E8C468'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 201, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 202, '#F0E6C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 208, '#9FB3C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 209, '#1E3B5C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 210, '#F0E6C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 211, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 212, '#0F1E33'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 213, '#0F1E33'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 214, '#B3282D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 215, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 216, '#8C1F22'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 221, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 226, '#0F1E33'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 228, '#2C4A6E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 227, '#F0E6C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 229, '#9FB3C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 230, '#9FB3C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 231, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 234, '#C7CED8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی' AND "Userid" = 1), 235, '#D4AF37');

-- ========================================== --
-- Command id: 1102
-- Description:  
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'اسپرسو و مسی', 1);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 154, '#231712'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 155, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 156, '#A6392E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 157, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 158, '#7C2A21'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 159, '#FFADDE2A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 160, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 161, '#FFE7F019'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 162, '#140C08'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 163, '#2B1D16'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 164, '#B08D77'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 165, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 166, '#A15E33'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 169, '#34241B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 172, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 173, '#C7AE9C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 174, '#FF4CDCBC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 175, '#FF526C7B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 176, '#4A3427'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 177, '#EEDFC9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 220, 'Gray'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 189, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 190, '#FF979899'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 191, '#FFB7BBBF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 194, '#FF666464'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 195, '#FF8E8AC7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 196, '#231712'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 197, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 198, '#A6392E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 199, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 200, '#E0A272'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 201, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 202, '#EEDFC9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 205, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 206, '#E0A272'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 209, '#3E2B20'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 211, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 212, '#231712'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 213, '#231712'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 214, '#A6392E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 215, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 216, '#7C2A21'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 218, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 219, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 221, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 224, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 236, '#D9C6B8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 237, '#3E2B20'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 238, '#EEDFC9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 239, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 240, '#231712'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 226, '#231712'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 228, '#4A3425'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 227, '#EEDFC9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 233, '#E0A272'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 234, '#C7AE9C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 235, '#C97A4A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 229, '#B08D77'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 230, '#B08D77'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 208, '#EEDFC9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'اسپرسو و مسی' AND "Userid" = 1), 210, '#FAF5EF');

-- ========================================== --
-- Command id: 1103
-- Description:  
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'آبی آسمانی و نقره‌ای', 1);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 154, '#E3EBF0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 155, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 163, '#D3E0E8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 174, '#FF4CDCBC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 175, '#FF526C7B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 177, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 225, 'White'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 189, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 191, '#FFB7BBBF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 220, 'Gray'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 218, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 194, '#FF666464'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 219, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 195, '#FF8E8AC7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 190, '#FF979899'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 224, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 202, '#FF62115D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 205, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 206, '#5A8CAE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 236, '#2E4756'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 237, '#C4D8E2'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 238, '#13232B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 239, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 240, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 162, '#DCE7EC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 169, '#EAF1F5'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 172, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 173, '#284350'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 176, '#DCE8ED'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 156, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 157, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 158, '#7C2320'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 159, '#C4D8E2'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 160, '#13232B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 161, '#DCE7EC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 164, '#5A7280'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 165, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 166, '#2B4E68'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 196, '#E3EBF0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 197, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 198, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 199, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 200, '#5A8CAE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 201, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 208, '#5A7280'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 209, '#C4D8E2'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 210, '#13232B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 211, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 212, '#F5FAFC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 221, '#F5FAFC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 213, '#F5FAFC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 214, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 215, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 216, '#7C2320'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 226, '#E3EBF0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 227, '#13232B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 229, '#5A7280'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 228, '#B9CBD6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 233, '#5A8CAE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 231, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 232, '#3E6D8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 234, '#2E4756'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'آبی آسمانی و نقره‌ای' AND "Userid" = 1), 235, '#3E6D8E');

-- ========================================== --
-- Command id: 1104
-- Description:  
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'یشمی و نقره ای پلاتینی', 1);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 154, '#0B2A2E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 155, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 162, '#123C40'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 163, '#0E3438'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 174, '#FF4CDCBC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 175, '#FF526C7B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 225, 'White'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 189, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 191, '#FFB7BBBF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 220, 'Gray'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 218, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 194, '#FF666464'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 219, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 195, '#FF8E8AC7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 190, '#FF979899'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 224, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 205, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 236, '#BFD3D2'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 237, '#1B4E53'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 238, '#E9F1EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 239, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 240, '#0B2A2E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 164, '#86ADA9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 165, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 166, '#A9B4B7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 169, '#134045'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 196, '#0B2A2E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 197, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 199, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 200, '#EDF2F3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 201, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 202, '#E9F1EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 209, '#1B4E53'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 211, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 212, '#0B2A2E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 221, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 214, '#B1403C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 172, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 173, '#A8C4C1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 176, '#235F64'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 177, '#E9F1EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 198, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 206, '#1B4E53'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 232, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 226, '#0B2A2E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 228, '#1F565C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 233, '#EDF2F3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 231, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 229, '#86ADA9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 227, '#E9F1EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 234, '#A8C4C1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 235, '#D6DEE0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 230, '#86ADA9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 156, '#B1403C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 157, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 158, '#8A2E2B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 159, '#1B4E53'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 160, '#E9F1EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 161, '#123C40'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 216, '#8A2E2B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 208, '#E9F1EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 210, '#F8FBFA'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 213, '#0B2A2E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'یشمی و نقره ای پلاتینی' AND "Userid" = 1), 215, '#FFFFFF');

-- ========================================== --
-- Command id: 1105
-- Description:  
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'بژ صورتی و رزگلد کمرنگ', 1);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 154, '#F3E9E4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 155, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 156, 'Red'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 157, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 158, '#FFF86060'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 159, '#FFADDE2A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 160, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 161, '#FFE7F019'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 162, '#EFE1D9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 163, '#EDDBD3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 164, '#9C7A70'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 165, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 166, '#8F584F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 169, '#F7EEE9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 172, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 173, '#5C3F38'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 174, '#F0DED4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 175, '#FF526C7B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 176, '#F0DED4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 177, '#3D2620'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 225, 'White'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 189, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 191, '#FFB7BBBF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 220, 'Gray'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 218, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 194, '#FF666464'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 219, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 195, '#FF8E8AC7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 190, '#FF979899'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 224, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 205, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 206, '#D29B8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 236, '#6B4B44'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 237, '#E6CCC0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 238, '#3D2620'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 239, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 240, '#FBF3EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 226, '#F3E9E4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 227, '#3D2620'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 228, '#DFC3B8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 229, '#9C7A70'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 231, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 232, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 234, '#6B4B44'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 235, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 233, '#D29B8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 196, '#F3E9E4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 197, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 198, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 199, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 200, '#D29B8E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 201, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 202, '#3D2620'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 208, '#9C7A70'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 209, '#E6CCC0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 210, '#3D2620'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 211, '#B8756A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 212, '#FBF3EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 221, '#FBF3EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 213, '#FBF3EF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 214, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 215, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'بژ صورتی و رزگلد کمرنگ' AND "Userid" = 1), 216, '#7C2320');

-- ========================================== --
-- Command id: 1106
-- Description:  
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'کرم طلایی روشن', 1);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 154, '#F5F1E6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 155, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 156, 'Red'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 157, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 158, '#FFF86060'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 159, '#FFADDE2A'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 160, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 161, '#FFE7F019'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 162, '#F0E9D5'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 163, '#EFE8D6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 164, '#8A7550'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 165, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 166, '#8C6A08'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 169, '#F8F4EA'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 172, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 173, '#5A4B2E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 174, '#EFE2BE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 175, '#FF526C7B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 176, '#EFE2BE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 177, '#3A2F1D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 225, 'White'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 189, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 191, '#FFB7BBBF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 220, 'Gray'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 218, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 194, '#FF666464'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 219, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 195, '#FF8E8AC7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 190, '#FF979899'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 224, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 205, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 206, '#9C92A5'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 236, '#6B5D3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 237, '#E6DAB8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 238, '#3A2F1D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 239, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 240, '#FDFBF3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 208, '#8A7550'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 209, '#E6DAB8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 210, '#3A2F1D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 211, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 212, '#FDFBF3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 221, '#FDFBF3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 213, '#FDFBF3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 214, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 215, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 216, '#7C2320'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 196, '#F5F1E6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 197, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 198, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 199, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 200, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 201, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 202, '#3A2F1D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 226, '#F5F1E6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 227, '#3A2F1D'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 228, '#DCCE9E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 229, '#8A7550'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 231, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 233, '#D4AF37'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 232, '#B8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 234, '#6B5D3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'کرم طلایی روشن' AND "Userid" = 1), 235, '#B8860B');

-- ========================================== --
-- Command id: 1107
-- Description:  
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'زمردی و برنز', 1);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 154, '#0D2B24'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 155, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 162, '#154A3C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 174, '#FF4CDCBC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 175, '#FF526C7B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 220, 'Gray'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 189, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 190, '#FF979899'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 191, '#FFB7BBBF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 194, '#FF666464'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 195, '#FF8E8AC7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 218, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 219, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 224, '#FFFF0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 163, '#0F3A30'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 164, '#8FB3A5'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 165, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 166, '#9C6B27'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 205, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 206, '#D9AE6B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 236, '#C9D9D1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 237, '#1C5645'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 238, '#EDE0C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 239, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 240, '#0D2B24'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 169, '#15493C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 172, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 173, '#A9C7BA'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 176, '#296B55'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 177, '#EDE0C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 196, '#0D2B24'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 197, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 198, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 199, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 200, '#D9AE6B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 201, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 202, '#EDE0C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 226, '#0D2B24'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 227, '#EDE0C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 229, '#8FB3A5'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 228, '#24604F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 231, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 232, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 230, '#8FB3A5'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 234, '#C9D9D1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 235, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 233, '#D9AE6B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 208, '#8FB3A5'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 209, '#1C5645'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 210, '#EDE0C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 211, '#C08A3E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 212, '#0D2B24'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 213, '#0D2B24'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 214, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 215, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 216, '#7C2320'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 221, '#0D2B24'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 156, '#A6332E'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 157, '#FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 158, '#7C2320'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 159, '#1C5645'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 160, '#EDE0C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'زمردی و برنز' AND "Userid" = 1), 161, '#154A3C');

-- ========================================== --
-- Command id: 1108
-- Description: تم پیش فرض
-- ========================================== --
INSERT INTO "UserBrushThem" ("Userid", "Title", "Scope") VALUES (1, 'تم پیش فرض روشن', 2);

INSERT INTO "UserBrushThemDe" ("BrushThemid", "Brushid", "Color") VALUES
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 1, '#FFF3F3F3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 2, '#FFE0D9D9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 3, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 4, '#FFF8FAFE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 5, '#FF333333'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 6, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 7, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 8, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 9, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 10, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 11, '#FF4169E1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 12, '#FFB8860B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 13, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 14, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 15, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 16, '#FFDD2C2C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 17, '#FFDD2C2C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 18, '#FFE1A07F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 19, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 20, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 21, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 22, '#FF399A39'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 23, '#FFD7ECF7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 24, '#FFC71585'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 25, '#FFC4E6F7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 26, '#FF0000FF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 27, '#FFEFEFF2'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 28, '#444'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 29, 'LightGreen'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 30, '#FFF8EFB3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 31, '#FF343738'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 32, '#FFFFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 33, '#FF07078C'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 34, '#97a8ac'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 35, '#FF13BEBE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 36, '#FFE9F4FB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 37, '#FF0000FF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 217, 'Red'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 38, '#EEE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 39, '#ddeaff'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 40, '#FF0000FF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 41, '#FFF4F4F4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 42, 'Blue'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 43, '#97a8ac'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 44, '#FFD7E9C1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 45, '#444'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 46, '#FFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 47, '#97a8ac'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 48, 'Blue'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 49, '#FFC8E0AE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 50, '#FFE4EED7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 51, '#ACACAC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 52, '#FFDFE3E9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 53, '#FFC1D6DB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 54, '#FF464242'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 55, '#FFFDD1FF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 56, '#FF80397B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 57, '#FF666666'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 58, '#FFC1C1C1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 59, '#FF8B008B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 60, '#FFFFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 61, '#FFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 62, '#FFB0C4DE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 63, '#FF0000FF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 64, '#FFE5F3F7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 65, '#FFE4EED7'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 66, '#ACACAC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 67, '#FFDFE3E9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 68, '#FF0000FF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 69, '#FFD8D5D5'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 70, '#FFACACAC'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 71, '#FF257F8F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 72, 'White'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 73, '#FF4F4F4F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 74, '#FF3FAEC2'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 75, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 76, '#FF808080'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 77, '#FF69A2DE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 78, '#FFDFE3E9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 79, '#FFFF8C00'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 80, '#FF00008B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 81, '#FF4169E1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 82, '#FFF9F9F9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 83, '#FF4682B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 84, '#FFA0CBDE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 85, '#FFA0CBDE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 86, '#FFC8E2EA'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 87, '#FF00008B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 88, '#FFA0CBDE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 89, '#FF000080'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 90, '#FF81C8DE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 91, '#FFC8E2EA'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 92, '#FF00008B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 93, '#FFA0CBDE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 94, '#FFFCEEE9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 95, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 96, '#FFFFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 97, '#FFF2FBFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 98, '#FFE8E0B4'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 99, '#FFAFEEEE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 100, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 101, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 102, '#FF0000FF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 103, 'White'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 104, '#FFFFFFE1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 105, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 106, '#FF8E8E90'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 107, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 108, '#FFE8ECEE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 109, '#FFA0CBDE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 110, '#00FFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 111, '#FFA0CBDE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 112, '#FFFFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 113, '#FFF2FBFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 114, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 115, '#FFAFEEEE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 116, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 117, '#FF0000CB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 118, '#FF8D0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 119, '#FF0000CB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 120, '#FF8D0000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 121, '#FF416384'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 122, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 123, '#FF0000FF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 124, '#FFA9CBD6'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 125, '#FFD94242'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 126, '#F0F0F0'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 127, '#FFACC2C8'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 128, '#FF5F6B6F'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 129, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 130, '#FFF0FFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 131, '#FF000000'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 132, '#FFCEDDE1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 133, '#FFCEDDE1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 134, 'White'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 135, '#FFDBE2E5'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 136, '#FF8B008B'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 137, '#FFFFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 138, '#FFFFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 139, 'Black'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 140, '#FFFF00FF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 141, '#FFD884D3'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 142, 'White'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 143, '#FFFFD700'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 144, '#FFE8BFF9'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 145, '#FFB24EAB'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 146, '#FFFFFFFF'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 147, '#EEE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 148, '#888'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 149, '#FFBAC6DA'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 150, '#888'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 151, '#EEE'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 152, '#FFA1A1A1'),
((SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن' AND "Userid" = 1), 153, '#AAA');
-- ========================================== --
-- Command id: 1109
-- Description:  
-- ========================================== --
INSERT INTO "UserSetting" ("Userid", "Settingid", "KeyValue", "Value")
SELECT
    u."id",
    'CurrentFormTheme',
    NULL,
    COALESCE(
        (SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'تم پیش فرض روشن'),
        (SELECT MAX("id") FROM "UserBrushThem" WHERE "Scope" = 2)
    )
FROM "User" u;

-- ========================================== --
-- Command id: 1110
-- Description:  
-- ========================================== --
INSERT INTO "UserSetting" ("Userid", "Settingid", "KeyValue", "Value")
SELECT
    u."id",
    'CurrentShellTheme',
    NULL,
    COALESCE(
        (SELECT "id" FROM "UserBrushThem" WHERE "Title" = 'سرمه‌ای و طلایی'),
        (SELECT MAX("id") FROM "UserBrushThem" WHERE "Scope" = 1)
    )
FROM "User" u;

-- ========================================== --
-- Command id: 1111
-- Description:  
-- ========================================== --
DELETE FROM "UserSetting"
WHERE "Settingid" = 'CurrentBrushThem';
UPDATE KalaReceipt
SET Status = (
    CASE
        WHEN EXISTS (
            SELECT 1 FROM KalaReceiptDe d
            WHERE d.Receiptid = KalaReceipt.id AND d.StatusDe = 0
        ) THEN 0
        WHEN NOT EXISTS (
            SELECT 1 FROM KalaReceiptDe d
            WHERE d.Receiptid = KalaReceipt.id AND d.StatusDe <> 2
        ) THEN 2
        ELSE 1
    END
)
WHERE EXISTS (SELECT 1 FROM KalaReceiptDe d WHERE d.Receiptid = KalaReceipt.id);