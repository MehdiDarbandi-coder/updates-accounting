﻿-- ========================================== --
-- Command id: 1138
-- Description: ساخت جدول جدید Contract_new با ON DELETE CASCADE روی FK_Contract_Personnel
-- ========================================== --
PRAGMA foreign_keys=off;
CREATE TABLE "Contract_new" (
	"id"	INTEGER NOT NULL,
	"Personnelid"	INTEGER NOT NULL,
	"ContractType"	INTEGER NOT NULL,
	"Bankid"	INTEGER,
	"ContractNumber"	INTEGER NOT NULL,
	"CreationDate"	INTEGER NOT NULL,
	"StartDate"	INTEGER NOT NULL,
	"EndDate"	INTEGER,
	"TerminationDate"	INTEGER,
	"DailyBaseAmount"	INTEGER NOT NULL,
	"DailySanavatBaseAmount"	INTEGER NOT NULL,
	"MobileNumber"	TEXT,
	"Address"	TEXT,
	"PostalCode"	TEXT,
	"InnerJobTitle"	TEXT,
	"WorkPlace"	TEXT,
	"Notes"	TEXT,
	"InsurType"	INTEGER,
	"InsurName"	TEXT,
	"InsurNumber"	TEXT,
	"InsuranceJobid"	INTEGER,
	"FreeTaxType"	INTEGER,
	"JobCategory"	INTEGER,
	"WorkPlaceStatus"	INTEGER,
	"LastEducation"	INTEGER,
	"BudgetLawException1403"	INTEGER,
	"EmploymentType"	INTEGER,
	"IsMarried"	INTEGER NOT NULL,
	"NumberOfChildren"	INTEGER NOT NULL,
	"BaseChildAmount"	INTEGER NOT NULL,
	"BaseHousAmount"	INTEGER NOT NULL,
	"BaseMarryAmount"	INTEGER NOT NULL,
	"BaseFoodAmount"	INTEGER NOT NULL,
	"BaseWorkerBenAmount"	INTEGER NOT NULL,
	"IsTaxable"	INTEGER NOT NULL DEFAULT 0,
	"IsInsurable"	INTEGER NOT NULL DEFAULT 0,
	"IsBimeShodeAsli"	INTEGER NOT NULL DEFAULT 0,
	"IsUnempInsured"	INTEGER NOT NULL DEFAULT 0,
	"IsHardshipInsurable"	INTEGER NOT NULL DEFAULT 0,
	CONSTRAINT "PK_Contract" PRIMARY KEY("id" AUTOINCREMENT),
	CONSTRAINT "FK_Contract_Personnel" FOREIGN KEY("Personnelid") REFERENCES "Personnel"("id") ON DELETE CASCADE,
	CONSTRAINT "FK_Contract_PersonnelBank" FOREIGN KEY("Bankid") REFERENCES "PersonnelBank"("id"),
	CONSTRAINT "FK_Contract_InsuranceJob" FOREIGN KEY("InsuranceJobid") REFERENCES "InsuranceJob"("id")
);

-- ========================================== --
-- Command id: 1139
-- Description: کپی کامل داده‌های جدول قدیم Contract به جدول جدید Contract_new
-- ========================================== --
INSERT INTO "Contract_new" SELECT * FROM "Contract";
-- ========================================== --
-- Command id: 1140
-- Description: حذف جدول قدیم Contract پس از اطمینان از کپی موفق داده‌ها
-- ========================================== --
DROP TABLE "Contract";
-- ========================================== --
-- Command id: 1141
-- Description: تغییر نام جدول جدید به Contract
-- ========================================== --
ALTER TABLE "Contract_new" RENAME TO "Contract";
PRAGMA foreign_keys=on;
-- ========================================== --
-- Command id: 1138
-- Description: ایجاد اولین رکورد TaxTable
-- ========================================== --
UPDATE Unit
SET TaxCode = CASE
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'لنگه' THEN '1611'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'عدل' THEN '1612'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'جعبه' THEN '1613'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'توپ' THEN '1618'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ست' THEN '1619'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دست' THEN '1620'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کارتن' THEN '1624'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'عدد' THEN '1627'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بسته' THEN '1628'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'پاکت' THEN '1629'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دستگاه' THEN '1631'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تخته' THEN '1640'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'رول' THEN '1641'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'طاقه' THEN '1642'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'جفت' THEN '1643'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'متر مربع' THEN '1645'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'پالت' THEN '1649'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دوجین' THEN '1661'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'حلقه(رینگ)' THEN '1668'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قراص' THEN '1673'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قراصه(bundle)' THEN '1694'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'لیتر' THEN '1637'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ساشه' THEN '1650'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کپسول' THEN '1683'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بندیل' THEN '1656'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'حلقه(رول)' THEN '1630'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قالب' THEN '163'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'شانه' THEN '1660'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'متر مکعب' THEN '1647'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ثوب' THEN '1689'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نیم دوجین' THEN '1690'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قرقره' THEN '1635'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کیلوگرم' THEN '164'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بطری' THEN '1638'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'برگ' THEN '161'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سطل' THEN '1625'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ورق' THEN '1654'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'شاخه' THEN '1646'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قوطی' THEN '1644'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'جلد' THEN '1617'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تیوب' THEN '162'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'متر' THEN '165'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کلاف' THEN '1610'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کیسه' THEN '1615'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'طغرا' THEN '1680'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بشکه' THEN '1639'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'گالن' THEN '1614'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'فاقد بسته بندی' THEN '1687'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کارتن(master case)' THEN '1693'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'صفحه' THEN '166'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'مخزن' THEN '1666'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تانکر' THEN '1626'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دبه' THEN '1648'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سبد' THEN '1684'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تن' THEN '169'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بانکه' THEN '1651'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سیلندر' THEN '1633'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'فوت مربع' THEN '1679'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'حلب' THEN '168'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'شیت' THEN '1665'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'چلیک' THEN '1659'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'جام' THEN '1636'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'گرم' THEN '1622'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نخ' THEN '1616'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'شعله' THEN '1652'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قیراط' THEN '1678'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'میلی لیتر' THEN '16100'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'میلی متر' THEN '16101'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'میلی گرم' THEN '16102'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ساعت' THEN '16103'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'روز' THEN '16104'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تن کیلومتر' THEN '16105'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کیلووات ساعت' THEN '1669'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نفر' THEN '1676'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ثانیه' THEN '16110'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دقیقه' THEN '16111'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ماه' THEN '16112'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سال' THEN '16113'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قطعه' THEN '16114'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سانتی متر' THEN '16115'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سانتی متر مربع' THEN '16116'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'فروند' THEN '1632'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'واحد' THEN '1653'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'لیوان' THEN '16108'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نوبت' THEN '16117'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'مگا وات ساعت' THEN '16118'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'گیگا بایت بر ثانیه' THEN '16119'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ویال' THEN '1681'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'حلقه(دیسک)' THEN '1667'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نسخه(جلد)' THEN '16120'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نفر-ساعت' THEN '16121'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کیلومتر' THEN '16122'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'آمپر' THEN '16125'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'میلی آمپر' THEN '16126'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'مثقال' THEN '16127'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سیر' THEN '16128'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دفعه(time)' THEN '16129'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'مگا یونیت' THEN '16130'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کادر' THEN '16131'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'پرس' THEN '16132'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بلوک' THEN '16133'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نفر-ماه' THEN '16134'
    ELSE TaxCode
END
WHERE IFNULL(TaxCode, '') <> CASE
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'لنگه' THEN '1611'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'عدل' THEN '1612'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'جعبه' THEN '1613'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'توپ' THEN '1618'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ست' THEN '1619'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دست' THEN '1620'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کارتن' THEN '1624'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'عدد' THEN '1627'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بسته' THEN '1628'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'پاکت' THEN '1629'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دستگاه' THEN '1631'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تخته' THEN '1640'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'رول' THEN '1641'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'طاقه' THEN '1642'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'جفت' THEN '1643'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'متر مربع' THEN '1645'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'پالت' THEN '1649'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دوجین' THEN '1661'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'حلقه(رینگ)' THEN '1668'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قراص' THEN '1673'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قراصه(bundle)' THEN '1694'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'لیتر' THEN '1637'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ساشه' THEN '1650'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کپسول' THEN '1683'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بندیل' THEN '1656'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'حلقه(رول)' THEN '1630'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قالب' THEN '163'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'شانه' THEN '1660'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'متر مکعب' THEN '1647'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ثوب' THEN '1689'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نیم دوجین' THEN '1690'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قرقره' THEN '1635'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کیلوگرم' THEN '164'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بطری' THEN '1638'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'برگ' THEN '161'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سطل' THEN '1625'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ورق' THEN '1654'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'شاخه' THEN '1646'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قوطی' THEN '1644'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'جلد' THEN '1617'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تیوب' THEN '162'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'متر' THEN '165'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کلاف' THEN '1610'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کیسه' THEN '1615'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'طغرا' THEN '1680'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بشکه' THEN '1639'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'گالن' THEN '1614'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'فاقد بسته بندی' THEN '1687'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کارتن(master case)' THEN '1693'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'صفحه' THEN '166'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'مخزن' THEN '1666'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تانکر' THEN '1626'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دبه' THEN '1648'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سبد' THEN '1684'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تن' THEN '169'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بانکه' THEN '1651'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سیلندر' THEN '1633'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'فوت مربع' THEN '1679'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'حلب' THEN '168'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'شیت' THEN '1665'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'چلیک' THEN '1659'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'جام' THEN '1636'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'گرم' THEN '1622'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نخ' THEN '1616'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'شعله' THEN '1652'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قیراط' THEN '1678'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'میلی لیتر' THEN '16100'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'میلی متر' THEN '16101'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'میلی گرم' THEN '16102'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ساعت' THEN '16103'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'روز' THEN '16104'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'تن کیلومتر' THEN '16105'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کیلووات ساعت' THEN '1669'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نفر' THEN '1676'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ثانیه' THEN '16110'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دقیقه' THEN '16111'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ماه' THEN '16112'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سال' THEN '16113'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'قطعه' THEN '16114'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سانتی متر' THEN '16115'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سانتی متر مربع' THEN '16116'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'فروند' THEN '1632'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'واحد' THEN '1653'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'لیوان' THEN '16108'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نوبت' THEN '16117'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'مگا وات ساعت' THEN '16118'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'گیگا بایت بر ثانیه' THEN '16119'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'ویال' THEN '1681'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'حلقه(دیسک)' THEN '1667'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نسخه(جلد)' THEN '16120'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نفر-ساعت' THEN '16121'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کیلومتر' THEN '16122'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'آمپر' THEN '16125'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'میلی آمپر' THEN '16126'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'مثقال' THEN '16127'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'سیر' THEN '16128'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'دفعه(time)' THEN '16129'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'مگا یونیت' THEN '16130'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'کادر' THEN '16131'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'پرس' THEN '16132'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'بلوک' THEN '16133'
    WHEN REPLACE(REPLACE(REPLACE(Title, 'ك', 'ک'), 'ي', 'ی'), 'ى', 'ی') = 'نفر-ماه' THEN '16134'
    ELSE TaxCode
END;
-- ========================================== --
-- Command id: 1139
-- Description: 
-- ========================================== --
ALTER TABLE Kala ADD COLUMN ShowSubUnitInInvoice INTEGER NOT NULL DEFAULT 0;
