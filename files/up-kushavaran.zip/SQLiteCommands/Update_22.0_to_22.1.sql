-- ========================================== --
-- Command id: 1169
-- Description: 
-- ========================================== --
DELETE FROM UserBrushThemDe
WHERE id NOT IN (
    SELECT MIN(id)
    FROM UserBrushThemDe
    GROUP BY BrushThemid, Brushid
);