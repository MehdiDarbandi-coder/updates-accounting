-- ========================================== --
-- Command id: 1170
-- Description: 
-- ========================================== --
ALTER TABLE [Storage] ADD COLUMN IsOnHold INTEGER NOT NULL DEFAULT 0;